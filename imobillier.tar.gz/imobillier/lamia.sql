-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Jeu 28 Août 2014 à 14:03
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `lamia`
--

-- --------------------------------------------------------

--
-- Structure de la table `appartement`
--

CREATE TABLE IF NOT EXISTS `appartement` (
  `id_bien` int(11) NOT NULL,
  `type_appar` varchar(20) NOT NULL,
  `num_etage` int(20) NOT NULL,
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `appartement`
--

INSERT INTO `appartement` (`id_bien`, `type_appar`, `num_etage`) VALUES
(205, 'F3', 4),
(206, 'F4', 5),
(207, 'F2', 3),
(208, 'F5', 3);

-- --------------------------------------------------------

--
-- Structure de la table `bien`
--

CREATE TABLE IF NOT EXISTS `bien` (
  `id_bien` int(11) NOT NULL AUTO_INCREMENT,
  `type_bien` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `lieu` varchar(30) NOT NULL,
  `prix` double NOT NULL,
  `superficie` double NOT NULL,
  `image1` varchar(1000) DEFAULT NULL,
  `image2` varchar(1000) DEFAULT NULL,
  `image3` varchar(1000) DEFAULT NULL,
  `image4` varchar(1000) DEFAULT NULL,
  `accord` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=213 ;

--
-- Contenu de la table `bien`
--

INSERT INTO `bien` (`id_bien`, `type_bien`, `description`, `lieu`, `prix`, `superficie`, `image1`, `image2`, `image3`, `image4`, `accord`) VALUES
(205, 'appartement', 'je ne sais rien', 'tazmalt', 76543893, 22345677, '', '', '', '', 1),
(206, 'appartement', '653789992', 'AKBOU', 667899221, 78890000, '', '', '', '', 1),
(207, 'appartement', 'huozujfildopjfviou', 'tinsouine ibahlal', 77668900, 56788999, '', '', '', '', 1),
(208, 'appartement', 'fhlfhlmefrmef', 'AKBOU', 43637828, 53657894, 'images (16).jpg', '', '', '', 1),
(209, 'villa', 'gleyzelukce', 'bejaia', 5865348990, 4645536787, '', '', '', '', 1),
(211, 'villa', 'slc sdkfvfkdev', 'akbou', 2334456, 2345671, '', '', '', '', 1),
(212, 'villa', 'nimporte quoi', 'tazmalt', 43637828, 53657894, '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `num_tel` int(20) NOT NULL,
  `adresse` varchar(20) NOT NULL,
  `adresse_mail` varchar(20) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `num_tel`, `adresse`, `adresse_mail`, `login`, `password`) VALUES
(1, 'Benamara', 'Ouarda', 458, 'akbou', 'warda@hotmail.fr', 'warda', '123456'),
(2, 'Ouazar', 'Ouezna', 74561541, 'Akbou', 'ouazarmila@gmail.com', 'ouazar', '789456'),
(3, 'redjedal', 'lamia', 1235, 'tazmelt', 'lamia@hotmail.fr', 'lamia', '456789'),
(4, 'bair', 'nariman', 7554879, 'bejaia', 'nariman@hotmail.fr', 'nariman', '789456'),
(5, 'redjedal', 'katia', 65958623, 'tazmelt', 'katia@hotmail.fr', 'katia', 'wawawawa'),
(8, 'Ouali', 'Massi', 791956832, 'Tazmelt', 'massi@hotmail.fr ', 'massi', 'massiazul'),
(17, 'aaaa', 'aaaa', 55555, 'aaaa', 'warda@hotmail.fr', 'qq', '123456'),
(20, 'AICHAOUI', 'fff', 458, 'akbou', 'warda@hotmail.fr', 'fff', '123456'),
(21, 'zz', 'zz', 458, 'zz', 'warda@hotmail.fr', 'aa', '123456'),
(22, 'aa', 'a', 55555, 'aaaa', 'warda@hotmail.fr', 'a', '123456'),
(23, 'benamara', 'chkir', 458, 'akbou', 'chakir@hotmail.fr', 'chakir', '123456');

-- --------------------------------------------------------

--
-- Structure de la table `entrepot`
--

CREATE TABLE IF NOT EXISTS `entrepot` (
  `id_bien` int(11) NOT NULL,
  `hauteur` int(20) NOT NULL,
  `largeur` int(20) NOT NULL,
  `longueur` int(20) NOT NULL,
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `terrain`
--

CREATE TABLE IF NOT EXISTS `terrain` (
  `id_bien` int(11) NOT NULL,
  `nbr_façade` int(2) NOT NULL,
  `categorie` varchar(20) NOT NULL,
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id_bien` int(11) NOT NULL,
  `type_transaction` varchar(20) NOT NULL,
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `transaction`
--

INSERT INTO `transaction` (`id_bien`, `type_transaction`) VALUES
(205, 'location'),
(206, 'echange'),
(207, 'vente'),
(208, 'vente'),
(209, 'vente'),
(211, 'achat'),
(212, 'echange');

-- --------------------------------------------------------

--
-- Structure de la table `villa`
--

CREATE TABLE IF NOT EXISTS `villa` (
  `id_bien` int(11) NOT NULL,
  `nbr_piece` int(20) NOT NULL,
  `nbr_etage` varchar(20) NOT NULL,
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `villa`
--

INSERT INTO `villa` (`id_bien`, `nbr_piece`, `nbr_etage`) VALUES
(209, 344, '3_étages'),
(211, 12, '4_étages'),
(212, 34, '3_étages');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `appartement`
--
ALTER TABLE `appartement`
  ADD CONSTRAINT `appartement_ibfk_1` FOREIGN KEY (`id_bien`) REFERENCES `bien` (`id_bien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `entrepot`
--
ALTER TABLE `entrepot`
  ADD CONSTRAINT `entrepot_ibfk_1` FOREIGN KEY (`id_bien`) REFERENCES `bien` (`id_bien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `terrain`
--
ALTER TABLE `terrain`
  ADD CONSTRAINT `terrain_ibfk_1` FOREIGN KEY (`id_bien`) REFERENCES `bien` (`id_bien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`id_bien`) REFERENCES `bien` (`id_bien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `villa`
--
ALTER TABLE `villa`
  ADD CONSTRAINT `villa_ibfk_1` FOREIGN KEY (`id_bien`) REFERENCES `bien` (`id_bien`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
