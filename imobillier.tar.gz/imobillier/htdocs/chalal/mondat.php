<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
 <link rel="stylesheet"  href="calendrier/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="calendrier/calendar.js"></script>
<script type="text/javascript" src="calendrier/FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<script>
var imgs=new Array();
imgs[0]="images/8321_20090110051149img_1150.jpg";
imgs[1]="images/maison-positive.jpg";
imgs[2]="images/img-8222-pour-le-web-7266.jpg";
imgs[3]="images/trisor-interieur-appartement-03.jpg";
imgs[4]="images/images (11).jpg";

var cpt=0;
function changeimages()
{
	document.getElementById("ima").src=imgs[cpt];
	cpt++;
	if(cpt>=imgs.length) cpt=0;
	setTimeout("changeimages()",2500);
}
</script>


<style>
body {
	background-color: #FFFFFF;
	background-image:url(images/bg.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}

#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}


#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:550px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:550px;
	border-left: 1px solid black;
	}	

	
.Style1 {color: #000000}
</style>

</head>

<body onLoad="changeimages()" >
<div id="conteneur">
<div id="header">
		
			<div id="slogon" align="center"><img src="images/Capture.JPG" width="149" height="151" /><img src="images/naima3.jpg" width="960" height="150" />			</div>
			<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili&eacute;re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
			</div>
			
		
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
		
		</li>
	<li><a href="apropos.php">A propos</a>
		
	</li>
		
		
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	
	</ul>
  </div>
		<div id="corps">
		
		<div id="droite">
		<p>&nbsp;</P>
		
		<p><div id="updates" class="boxed">
			<div class="title">
			<div id="sidebar">
			<div id="div2" class="boxed">
			<div class="title">
				<h2>Calendrier</h2>
			</div>
			<div class="content">
			<div id="div3"></div>
			</div>
			</div>
			</div>
			</div>
			<div class="content">
		<div id="cal1Container" ></div>
	
			</div>
		</div></P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</p>
		
		</P>
		<p>&nbsp;</P>
		<P><img src="images/fnai.jpg" width="180" height="116" /></P>
		<P>&nbsp;</P>
		</div>
		<div id="gauche">
		

          	
	
	  

		</div>
		<div id="milieu">
	      <center><h1>&nbsp;</h1>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
	        <p>&nbsp;</p>
          </center>
		   <center>
		     <p>&nbsp;</p>
		   </center>
		</div>
	
		</div>
	
  <div id="footer" >
	  <table width="1218" height="138" border="0" align="center" bordercolor="#FFFFFF">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#cccccc" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#cccccc" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9"> 05-51-57-24-99</p>
    <p align="center" class="Style9">E-mail: chalal.immobilier@hotmail.fr</p>
    </th>
    <th width="418" align="center" valign="top" bgcolor="#cccccc" scope="col"><p align="center" class="Style9"><span class="Style1"><a href="index.php">acceuil</a></span></p>
      <p align="center" class="Style9 Style1"><a href="recherche.php">recherche</a></p>
      <p align="center" class="Style9 Style1"><a href="proposer1.php">proposer</a></p>
      <p align="center" class="Style9 Style1"><a href="inscription3.php">inscreption</a></p>
      <p align="center" class="Style9 Style1"><a href="mondat.php">mondat</a></p>
      <p align="center" class="Style9 Style1"><a href="contact.php">contactez-nous</a></p>
      <p align="center" class="Style9"><span class="Style1"><a href="apropos.php">A propos</a></span> </p></th>
  </tr>
</table>
  </div>
	
</div>
</body>
</html>

