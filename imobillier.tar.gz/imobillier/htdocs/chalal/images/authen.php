<?php
require_once('config.php' );



// Definition des constantes et variables

$errorMessage = '';
// Test de l'envoi du formulaire
if(!empty($_POST))
{
// Les identifiants sont transmis ?
if(!empty($_POST['mat']) && !empty($_POST['pass']))
{
if($st==1){ 
$conten=etudiant::getEtudiantMatricule($_POST['mat'],$_POST['pass']);
$login="";
if($row = mysqli_fetch_array($conten)){
$login=$row['MatriculeEtudiant'];
$Nom=$row['NomEtudiant'];
$Prenom=$row['PrenomEtudiant'];
define('PASSWORD',$row['DateNaissEtudiant']);}

}else{
if($st==2){ //espace enseignent
$conten=etudiant::getens($_POST['mat'],$_POST['pass']);
$login="";
if($row = mysqli_fetch_array($conten)){
$login=$row['MatriculeEtudiant'];
$Nom=$row['NomEtudiant'];
$Prenom=$row['PrenomEtudiant'];
define('PASSWORD',$row['DateNaissAdmin']);}
}

else{
//espace administrateur
$conten=etudiant::getAdministrateurLogin($_POST['mat'],$_POST['pass']);
$login="";
if($row = mysqli_fetch_array($conten)){
$login=$row['LoginAdmin'];
$Nom=$row['NomAdmin'];
$Prenom=$row['PrenomAdmin'];

define('PASSWORD',$row['DateNaissAdmin']);}

}
}

define('LOGIN',$login);
// Sont-ils les m�mes que les constantes ?
if($_POST['mat'] !== LOGIN)
{
$errorMessage = "Le nom d'utilisateur ne correspond pas au mot de passe, ou vous n'avez pas encore de compte.";
}
elseif($_POST['pass'] !== PASSWORD)
{ 
$errorMessage = "Le nom d'utilisateur ne correspond pas au mot de passe, ou vous n'avez pas encore de compte.";


}
else
{// On ouvre la session

session_start();
setcookie('mat' ,'pass', time() +1800);
if (empty($_COOKIE['mat'])){
header('Location: deconecter.php');
exit();}
$_SESSION['login'] = LOGIN;
$_SESSION['password'] = PASSWORD;
$_SESSION['Nom'] = $Nom;
$_SESSION['Prenom'] = $Prenom;
$_SESSION['Statut'] = $st;

}
}
else
{
$errorMessage = "Le nom d'utilisateur ne correspond pas au mot de passe, ou vous n'avez pas encore de compte.";

}
}

 

?>