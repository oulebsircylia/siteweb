<?php

  $cnx = mysql_connect( "localhost", "root", "mimia" );
  //s�lection de la base de donn�es:
 

  $db  = mysql_select_db("memoire");
	$requete = mysql_query("SELECT * FROM appartement", $cnx) or die( mysql_error()) ;
		
		  while($rows = mysqli_fetch_array($requete)){
		 echo $rows['id_bien']; 
		  }
?>
