<?php
session_start();
$_SESSION = array();
session_destroy();

unset($_SESSION);
 ?>
						<script type="text/javascript">
						window.alert("Vous �tes deconnecter ");
						 window.location.replace("http://localhost/agence_immobiliere/index.php");
						
						</script>
						<?php 

exit;

?>

