<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_conn_memoire = "localhost";
$database_conn_memoire = "memoire";
$username_conn_memoire = "root";
$password_conn_memoire = "mimia";
$conn_memoire = mysql_pconnect($hostname_conn_memoire, $username_conn_memoire, $password_conn_memoire) or trigger_error(mysql_error(),E_USER_ERROR); 
?>