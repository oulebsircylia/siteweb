 <?php
 require_once('config.php' );
 if(isset($_POST['submit'])){
if(isset($_POST['t']))	$t=  $_POST['t'];  else $t="";
 if(isset($_POST['type']))$type_tran=  $_POST['type'];
     if(isset($_POST['lieu']))	$lieu=  $_POST['lieu'];else $lieu="";
	 if($_POST['prix_min']!=''){	$prixinf=  $_POST['prix_min'];
	 }else $prixinf="0";
	if($_POST['prix_max']){$prixsup=  $_POST['prix_max'];}else $prixsup="9999999999"; 
	
	
	
//La recherche a partir de prix
	 
	 if ($_POST['prix_min'] || $_POST['prix_max'])
	 {
	 $sql="SELECT * FROM bien WHERE ( prix > '$prixinf' and prix < '$prixsup' )";
	 echo $sql;
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
     }
	 
	 //La recherche a partir de lieu

     if ($_POST['lieu']){
	 $sql="SELECT * FROM bien WHERE (lieu='$lieu')";
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");

	}
	 // La recherche a partir de  type de transaction
	
     if ($_POST['type']){
	 $sql="SELECT * FROM bien, transaction WHERE type_transaction='$t'AND bien.id_bien=transaction.id_bien ";
	 echo $sql;
	 $conn =config::connectDB();
      $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	  } 	
	
	
	
	//prix+ lieu + type 
	if ($_POST['lieu'] && $_POST['prix_min'] &&   $_POST['prix_max']  && $_POST['type']){
	
	
	 $sql="SELECT  * FROM  bien,  transaction WHERE (accord=1 AND transaction.id_bien=bien.id_bien  AND type_transaction='$type_tran' AND lieu='$lieu' AND (prix > '$prixinf' AND prix < '$prixsup')  )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
	
	}
	//prix+ t+ type 
	if ($_POST['t'] && $_POST['prix_min'] &&   $_POST['prix_max']  && $_POST['type']){
	
	
	 $sql="SELECT  * FROM  bien,  transaction, $t  WHERE (accord=1 AND  transaction.id_bien=bien.id_bien  AND $t.id_bien=bien.id_bien AND  type_transaction='$type_tran' AND  type_bien='$t' AND (prix > '$prixinf' AND prix < '$prixsup'  )  )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
	
	
	}
	//Type + Lieu
	if ($_POST['lieu'] && $_POST['type']){
	
	
	 $sql="SELECT  * FROM  bien,  transaction WHERE (accord=1 AND  transaction.id_bien=bien.id_bien   AND  type_transaction='$type_tran' 	AND lieu='$lieu'  )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
	
	
	}
	 //type + prix 
	  
	if ( $_POST['prix_min'] &&   $_POST['prix_max'] && $_POST['type']){
	
	
	 $sql="SELECT  * FROM  bien,  transaction WHERE (accord=1 AND  transaction.id_bien=bien.id_bien   AND  type_transaction='$type_tran' AND (prix > '$prixinf' AND prix < '$prixsup' ) )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
	
	
	}
//t

if ( $_POST['t']){
	
	
	 $sql="SELECT  * FROM  bien,  transaction ,$t WHERE (accord=1 AND  transaction.id_bien=bien.id_bien   AND $t.id_bien=bien.id_bien AND  type_transaction='$type_tran' AND type_bien='$t' )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
	
	
	}

	

//t + lieu
if($_POST['t'] && $_POST['lieu'] ){
	
	
	 $sql="SELECT  * FROM  bien,  $t, transaction WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND  bien.id_bien=$t.id_bien AND type_bien='$t' AND lieu='$lieu' )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
     }
	// prix+t;
	
if($_POST['t'] && $_POST['prix_min'] &&   $_POST['prix_max']  ){
	
	
	 $sql="SELECT  * FROM  bien,  $t, transaction WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND  bien.id_bien=$t.id_bien AND type_bien='$t' AND prix > '$prixinf' AND prix < '$prixsup'  )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
     }
	 //  prix+ t + lieu
	 
if($_POST['lieu'] && $_POST['prix_min'] &&   $_POST['prix_max'] && $_POST['t']  ){
	
	
	 $sql="SELECT  * FROM  bien,  $t, transaction WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND  bien.id_bien=$t.id_bien AND lieu='$lieu' AND prix > '$prixinf' AND prix < '$prixsup' AND  type_bien='$t' )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
     }
	 //  prix + lieu
	if ( $_POST['lieu'] && $_POST['prix_min'] && $_POST['prix_max']){
	
	
	 $sql="SELECT  * FROM  bien, transaction WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND prix > '$prixinf' AND prix < '$prixsup' )";
	
	 echo $sql;
	 $conn = config::connectDB();
     $oRow = mysqli_query($conn, $sql) or die("Erreur de lecture de la table: ");
     }
	
	
	
	
	//t+type+lieu+prix
	if ($_POST['t'] && $_POST['type'] &&$_POST['lieu'] && $_POST['prix_min'] && $_POST['prix_max']){
	 $sql="SELECT  * FROM  bien,  $t, transaction
     WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND  bien.id_bien=$t.id_bien AND type_bien='$t'AND type_transaction='$type_tran' AND lieu='$lieu' AND prix > '$prixinf' AND prix < '$prixsup')";
     $conn =config::connectDB();
    $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	}
	//t+type+lieu
	if ($_POST['t'] && $_POST['type'] &&$_POST['lieu'] ){
	 $sql="SELECT  * FROM  bien,  $t, transaction
     WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND  bien.id_bien=$t.id_bien AND type_bien='$t'AND type_transaction='$type_tran' AND lieu='$lieu' )";
     $conn =config::connectDB();
    $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	}
	
	
	//t+type
	if ($_POST['t'] && $_POST['type'] ){
	 $sql="SELECT  * FROM  bien,  $t, transaction
     WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND  bien.id_bien=$t.id_bien AND type_bien='$t'AND type_transaction='$type_tran')";
     $conn =config::connectDB();
    $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	}
	
	
	
	
	 }
	?>
	<form method="POST"  name="bien" action="z.php">
						<center>
						  <table width="448" height="215" border="0" align="center">
                            <tr>
                              <td width="120" height="24"><input type="hidden" name="id_bien" />
                                  <label for="bien"><span class="Style40">Bien: </span></label>                              </td>
                              <td width="318"><select id="t" name="t" >
                                  <option value="vide"></option>
                                  <option value="appartement">&nbsp;&nbsp;Appartement&nbsp;&nbsp;</option>
                                  <option value="villa">&nbsp;&nbsp;Villa&nbsp;&nbsp;</option>
                                  <option value="terrain">&nbsp;&nbsp;Terrain&nbsp;&nbsp;</option>
                                  <option value="entrepot">&nbsp;&nbsp;Entrepot&nbsp;&nbsp;</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td height="46"><label for="cat&eacute;gorie" class="Style40">Type transaction: </label>                              </td>
                              <td><select name="type" id="type" placeholder="Type de bien">
                                  <option value="vide"></option>
                                  <option value="achat">&nbsp;&nbsp;&nbsp;&nbsp;Achat&nbsp;&nbsp&nbsp;</option>
                                  <option value="location">&nbsp;&nbsp;&nbsp;&nbsp;Location&nbsp;&nbsp;&nbsp;</option>
                                  <option value="Echange">&nbsp;&nbsp;&nbsp;&nbsp;Echange&nbsp;&nbsp;&nbsp;</option>
                                </select>                              </td>
                            </tr>
                            <tr>
                              <td height="37"><label for="lieu" class="Style40">Lieu: </label></td>
                              <td><input type="text" name="lieu" id="lieu" /></td>
                            </tr>
                            <tr>
                              <td height="40"><label for="prix" class="Style40">Prix (DA): </label>                              </td>
                              <td><input type="text" name="prix_min" id="pri_min" placeholder="prix min"/> <input type="text" name="prix_max" id="pri_max" placeholder="prix max"/>                              </td>
                            </tr>
                            <tr>
                              <td height="56"></td>
                              <td><input name="submit" type="submit" value="Lancer la recherche"/>                              </td>
                            </tr>
                        </table>
						</center>
            </form>
	 
	  
	  
	 
	 
	    <table width="726" border="0">
			
		<?php if(!empty($oRow)){ ?>
		 <span class="Style1">Les r�sultats de la recherche		  </span>
  <?php  while($rows = mysqli_fetch_array($oRow)){?>
  <center>
		 
		</center>
  <tr>
    <td width="250" height="204"><img src="./images/<?php echo $rows['image1'] ;?>"  name="image" width="250px" height="200px"/></td>
    <td width="460"> 
	<strong>Type de bien:</strong>	<?php echo $rows['type_bien'] ;?><strong>.</strong>	<br>
	<strong>Prix:</strong>	<?php echo $rows['prix'] ;?> <strong>DA.</strong>	<br>
	<strong>Superficie:</strong>	<?php echo $rows['superficie']  ;?> <strong>m�.</strong>	<br />
	<br /><br /><br />
	 <?php }}?>