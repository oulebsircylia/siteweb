<?php
//connection au serveur
  $cnx = mysql_connect( "localhost", "root", "mimia" );
  //s�lection de la base de donn�es:
  $db  = mysql_select_db("memoire");
 //r�cup�ration de la variable d'URL,
  //qui va nous permettre de savoir quel enregistrement modifier
  $id_bien= $_GET['id_bien'] ;
   //requ�te SQL:
  $sql = "SELECT * FROM bien, appartement  , transaction, villa , terrain ,entrepot WHERE   ( bien.id_bien = terrain.id_bien OR bien.id_bien = transaction.id_bien OR bien.id_bien= entrepot.id_bien OR bien.id_bien= appartement.id_bien OR bien.id_bien = villa.id_bien ) AND bien.id_bien = ".$id_bien ;
  echo $sql;
   //ex�cution de la requ�te:
  $requete = mysql_query( $sql, $cnx ) ;
 
  //affichage des donn�es:
  if( $result = mysql_fetch_object( $requete ) )
  {
  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('t').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('t_a').style.display= 'inline';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'inline';
	    document.getElementById('n_e').style.display= 'inline';
         document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		  document.getElementById('ca').style.display= 'none';
		  document.getElementById('n_f').style.display= 'none';
		  document.getElementById('n_�').style.display= 'none';
        } 
		  if (a == "terrain"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'inline';
			document.getElementById('n_f').style.display= 'inline';
			document.getElementById('n_�').style.display= 'none';
        } 
	if (a == "entrepot"){ 
		document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'inline';
		  document.getElementById('lo').style.display= 'inline';
		   document.getElementById('la').style.display= 'inline';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'none';
        } 
	
	
		
		   }
</script>

<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
.Style40 {color: #000000; font-size: 14px; }
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><div align="right"><img src="../images/logopaint.jpg" width="198" height="90" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/entete2.jpg" width="940" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>







<table width="1211" height="611" border="0">
  <tr>
    <th width="367" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
              <ul id ="menu-accordeon">
                <li><a href ="#">Gestion des client </a>
                    <ul>
                      <li> <a href="ajouter client.php"> Ajouter</a></li>
                      <li><a href="modifie un client.php">Modifie</a> </li>
                      <li><a href="supprimer un client .php">Supprimer</a> </li>
                    </ul>
                </li>
                <li><a href ="#">Gestion des bien </a>
                    <ul>
                     <li> <a href="ajouter_un_bien.php">Ajouter</a></li>
                     <li><a href="modifie_un_bien.php">Modifie</a></li>
					<li><a href="supprimer_bien.php">Supprimer</a></li>
                    </ul>
                </li>
                <li><a href="modifier le mot de passe.php">Modifie login et mot de passe </a> </li>
                <li><a href="consulter.php">consulter les biens </a>
                    <ul>
                    </ul>
                </li>
              </ul></th>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
    <th width="834" align="center" valign="top" class="Style37" scope="col"><p class="Style38">Modifier un bien </p>
	
       <form method="POST"  name="bien" action="modifier_un_bien2.php" enctype="multipart/form-data">
	   <table align="center" border="0">
	   <tr>
									<td>
										<label for="lieu" class="Style40"> </label></td>
									<td>
										<input type="hidden" name="id_bien"  value="<?php echo($result->id_bien) ;?>"/>	</td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40"> accord</label></td>
									<td>
										<input type="text" name="accord"value="<?php echo($result->accord) ;?>" />	</td>
								</tr>
						
								<tr>
									<td width="143">
									
								  <label for="bien"><span class="Style40">Bien:    </span></label>									</td>
    							  <td width="681"><select name="t" id="t" onchange="Changer()">
                                    <option value="vide"></option>
                                    <option value="appartement">Appartement</option>
                                    <option value="villa">Villa</option>
                                    <option value="terrain">Terrain</option>
                                    <option value="entrepot">Entrepot</option>
                                  </select>
    							    <select name="t_a" id="t_a" style="display:none">
                                      <option value="vide">Type</option>
                                      <option value="F1">F1</option>
                                      <option value="F2">F2</option>
                                      <option value="F3">F3</option>
                                      <option value="F4">F4</option>
                                      <option value="F5">F5</option>
                                      <option value="F5">F5+</option>
                                    </select>
    							    <select name="n_e" id="n_e" style="display:none">
                                      <option value="vide">Nombre d'�tage</option>
                                      <option value="1_�tage">1 �tage</option>
                                      <option value="2_�tages">2 �tages</option>
                                      <option value="3_�tages">3 �tages</option>
                                      <option value="4_�tages">4 �tages</option>
                                      <option value="5_�tages">5 �tage</option>
                                      <option value="+_de_5">+ de5 �tages </option>
                                    </select>
   
                                   <select name="ca" id="ca" >
                                      <option value="vide">cat�gorie</option>
                                      <option value="Terrain urbanisable">Terrain urbanisable</option>
                                      <option value="Terrain agricol">Terrain agricol</option>
                                      <option value="Terrain industr">Terrain industriel</option>
                                    </select>							      </td>
								</tr>
								<tr>
									<td>
										<label class="Style40">Type transaction: </label>	</td>
									<td>
										<select name="bi" id="bi" placeholder="Type de bien">
	 										<option value="vide"></option> 
											<option value="achat">Achat</option>
											<option value="location">Location</option>
											<option value="location">Echange</option>
									  </select>	</td>
								</tr>
									<td width="143">
									
								  <label for="bien"><span class="Style40">Bien:    </span></label>									</td>
    							  <td width="681">
	
								  
	
	
    <input name="p" type="text"  value = "<?php echo ($result->ndr_piece); ?>" id="p" style="display:none"/>
   <input name="h" type="text"  value = "<?php echo ($result->hauteur); ?>" id="h" style="display:none"/>
	<input name="lo" type="text"  value = "<?php echo ($result->longueur); ?>" id="lo"  style="display:none"/>
	<input name="la" type="text"  value = "<?php echo ($result->largeur); ?>" id="la"  style="display:none"/>
	<input name="n_f" type="text"  value = "<?php echo ($result->nbr_fa�ade); ?>" id="n_f"  style="display:none"/>
	<input name="n_�" type="text"  value = "<?php echo($result->num_etage); ?>" id="n_�"  style="display:none"/>
	
	
 
							      </td>
								</tr>
								
								<tr>
									<td>
										<label  class="Style40">description: </label></td>
									<td>
										<textarea name="description" id="description" > <?php  echo ($result->description);?></textarea>	</td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">Lieu: </label></td>
									<td>
										<input type="text" name="lieu" id="lieu"  value = "<?php echo  ($result->lieu); ?>"/>	</td>
								</tr>
								<tr>
									<td>
										<label for="superficie" class="Style40">Superficie: </label>	</td>
								  <td>
										<input type="number" name="superficie" id="Superficie"  value = "<?php echo ($result->superficie); ?>"/>
										<span class="Style40">m�</span> </td>
								</tr>
								<tr>
									<td>
										<label for="prix" class="Style40">Prix: </label>									</td>
								  <td>
										<input type="number" name="prix" id="prix"  value = "<?php echo ($result->prix); ?>"/>
										<span class="Style40">DA</span> </td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 1: </label>									    </td>
									<td><label>
									  <input type="file" name="image1"  value = "<?php echo ($result->image1); ?>"/>
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 2: </label>									    </td>
									<td><label>
									  <input type="file" name="image2"  value = "<?php echo ($result->image2); ?>"/>
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 3: </label>									    </td>
									<td><label>
									  <input type="file" name="image3"  value = "<?php echo ($result->image3); ?>"/>
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 4: </label>									    </td>
									<td><label>
									  <input type="file" name="image4" value = "<?php echo($result->image4); ?>"/>
									</label></td>
								</tr>
								
								<tr>
									<td>									</td>
									<td>
										<input type="submit" value="Valider" name="valider"/>									</td>
								</tr>
		 </table>
	                        
 <script language="javascript">
from1.t.value='<?php  echo $result['type_bien'];?>';
from1.t_a.value='<?php  echo $result['type_appar'];?>';
from1.n_e.value='<?php  echo $result['nbr_etage'];?>';
from1.ca.value='<?php  echo $result['categorie'];?>';
from1.bi.value='<?php  echo $result['type_transaction'];?>';
</script>                  
       </form>
	   <?php 
	   }
	   ?>
    <p>&nbsp;</p></th>
  </tr>
</table>
<p>&nbsp;</p>
<table width="1218" height="138" border="0" align="center" bordercolor="#000000" bgcolor="#006666">
  <tr bgcolor="#666666"> <th width="391" height="132" align="center" valign="top" bgcolor="#006699" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#003333" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>

</body>
</html>