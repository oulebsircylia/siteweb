<?php

require_once('config.php' );
function mailByzimbra(){
		$sSQL = "SELECT * FROM appartement  ";

		$conn =config::connectDB();
		$oRow  = mysqli_query($conn, $sSQL) or die("Erreur de lecture de la table table: ");
if($rows = mysqli_fetch_array($oRow)){

echo $rows['id_bien'];
}
		//return $oRow; 

}

echo mailByzimbra();

?>