<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('operation').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('nbr_piece').style.display= 'inline';
	  document.getElementById('piece').style.display= 'none';
	    document.getElementById('nbr_etage').style.display= 'none';
		 document.getElementById('nbr_fa�ade').style.display= 'none';
		 document.getElementById('hauteur').style.display= 'none';
		 document.getElementById('largeur').style.display= 'none';
		 document.getElementById('longueur').style.display= 'none';
		 		 document.getElementById('Num�er d�tage').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('nbr_piece').style.display= 'none';
	  document.getElementById('piece').style.display= 'inline';
	    document.getElementById('nbr_etage').style.display= 'inline';
		 document.getElementById('nbr_fa�ade').style.display= 'none';
		 document.getElementById('hauteur').style.display= 'none';
		 document.getElementById('largeur').style.display= 'none';
		 document.getElementById('longueur').style.display= 'none';
		  document.getElementById('Num�er d�tage').style.display= 'none';
		
		
		
		}
		  if (a == "terrain"){
	 document.getElementById('nbr_piece').style.display= 'none';
	  document.getElementById('piece').style.display= 'none';
	    document.getElementById('nbr_etage').style.display= 'none';
	 document.getElementById('nbr_fa�ade').style.display= 'inline';
	 document.getElementById('hauteur').style.display= 'none';
	 document.getElementById('largeur').style.display= 'none';
	 document.getElementById('longueur').style.display= 'none';
	  document.getElementById('Num�er d�tage').style.display= 'none';
		}if (a == "entrepot"){ 
		document.getElementById('nbr_piece').style.display= 'none';
	  document.getElementById('piece').style.display= 'none';
	    document.getElementById('nbr_etage').style.display= 'none';
	 document.getElementById('nbr_fa�ade').style.display= 'none';
	 document.getElementById('hauteur').style.display= 'inline';
	 document.getElementById('largeur').style.display= 'inline';
	 document.getElementById('longueur').style.display= 'inline';
	  document.getElementById('Num�er d�tage').style.display= 'none';
	
		}
		   }
</script>
</head>

<?php
include("Connections/agence_connexion.php");


 if ((!empty($_POST['id_bien'])) AND (!empty($_POST['num_�tage'])) AND (!empty($_POST['type'])))
{
$req= $bdd->prepare('INSERT INTO bien( id_bien, localisation, superficie, prix, image1, image2, image3, image4,lieu) values(?,?,?,?,?,?,?,?,?)');
$req->execute(array($_POST['id_bien'],$_POST['localisation'],$_POST['superficie'],$_POST['prix'],$_POST['image1'],$_POST['image2'],$_POST['image3'],$_POST['image4'],$_POST['lieu']));unset($req);
$idclt=0;
$idclt=$bdd->lastInsertId();
$req2= $bdd->prepare('INSERT INTO apparetement (id_bien, num_�tage, type ) values(?,?,?)');
$req2->execute(array($_POST['cin_client'],$_POST['prenom_client'],$idclt));
if ($req2)
{
?><form action="" method="post" enctype="multipart/form-data">
							<table align="center" border="0">
								<tr>
									<td width="141">
										<label for="bien">Bien:    </label>									</td>
    							  <td width="560"><select id="operation" name="operation" onchange="Changer()">
                                    <option value="vide"></option>
                                    <option value="appartement">Appartement</option>
                                   
                                  </select>
    							    <select name="select2" id="nbr_piece" style="display:none">
                                      <option value="vide">Nombre de piece</option>
                                      <option value="f1">F1</option>
                                      <option value="f2">F2</option>
                                      <option value="f3">F3</option>
                                      <option value="f4">F4</option>
                                      <option value="f5">F5</option>
                                      <option value="f5">F5+</option>
                                    </select>
									<select name="select3" id="num_etage" style="display:none">
                                      <option value="vide">Nombre d'�tage</option>
                                      <option value="f1">1 �tage</option>
                                      <option value="f2">2 �tages</option>
                                      <option value="f3">3 �tages</option>
                                      <option value="f4">4 �tages</option>
                                      <option value="f5">5 �tage</option>
                                      <option value="f5">+ de5 �tages </option>
                                    </select>
								<input type="number" name="num_etage" id="num_etage" placeholder="Num�er d�tage" style="display:none" />
    							    
   						 <input name="piece" type="text" value="" id="piece" placeholder="nombre de piece" style="display:none"/>	
						  
						
						   							 	  </td>
								</tr>
								<tr>
									<td>
										<label for="cat�gorie">Type transaction: </label>	</td>
									<td><select name="bien" id="bien" placeholder="Type de bien">
                                      <option value="vide"></option>
                                      <option value="achat">Achat</option>
                                      <option value="location">Location</option>
                                      <option value="location">Echange</option>
                                    </select></td>
								</tr>
								<tr>
									<td>
										<label for="lieu">Lieu: </label></td>
									<td>
										<input type="text" name="lieu" id="lieu" />	</td>
								</tr>
								<tr>
									<td>
										<label for="superficie">Superficie: </label>	</td>
									<td>
										<input type="number" name="superficie" id="superficie" />m�									</td>
								</tr>
								<tr>
									<td>
										<label for="prix">Prix: </label>									</td>
									<td>
										<input type="number" name="prix" id="prix" />DA									</td>
								</tr>
								<tr>
									<td>
										<label for="description">Ajouter des images: </label>									    </td>
								  <td><input type="file" name="file" /></td>
								</tr>
								<tr>
									<td>									</td>
									<td>
										<input type="submit" value="Valider"/>									</td>
								</tr>
						</table>
		  </form>
		  <?php
echo "ajout fait";
}
else {
echo "Ajout non effectu�";}
}
else
{
echo "SVP saisir les donn�es";
}

?>



<body>
</body>
</html>
