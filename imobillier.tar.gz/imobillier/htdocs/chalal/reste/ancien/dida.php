<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<style>
body {
	background-color: #CCCCCC;
	background-image:url(images/BACKGROUND.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
</style>
</head>
<body onLoad="changeimages()" >
<div id="conteneur">
<div id="header">
		
			<div id="slogon" align="center">
				<img src="images/logopaint.jpg" width="160" height="150" />
				<img src="images/naima3.jpg" width="960" height="150" />
			</div>
			<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
			</div>
			
		
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a><ul>
	    <li><a href="mondat.php">Mondat</a></li>
		<li><a href="mondat.php">Mondat</a></li>
		<li><a href="mondat.php">Mondat</a></li>
		</ul>
	</li>
	<li><a href="inscription.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		<ul>
		
		<li><a href="mondat.php">Mondat</a></li>
		<li><a href="mondat.php">Mondat</a></li>
		<li><a href="mondat.php">Mondat</a></li>
		<li><a href="mondat.php">Mondat</a></li>
		</ul>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
  </div>
		
		<div id="droite"></div>
		 // fonctions utiles, $valeur 
 repr�sente une date au format AAAA-MM-JJ
 function getSecond($valeur) {
 return substr($valeur, 17, 2);
   }

   function getMinute($valeur) {
       return substr($valeur, 14, 2);
   }

  function getHour($valeur) {

      return substr($valeur, 11, 2);
  }

  function getDay($valeur)     {
     return substr($valeur, 8, 2);
  }

  function getMonth($valeur)     {
     return substr($valeur, 5, 2);
  }

  function getYear($valeur) {
     return substr($valeur, 0, 4);
 }

  function monthNumToName($mois) {
    $tableau = Array("", "Janvier", "F�vrier", 
    "Mars", "Avril", "Mai", "Juin", "Juillet", 
    "A�ut", "Septembre", "Octobre", "Novembre", "D�cembre");

    return (intval($mois) > 0 && intval($mois) 
    < 13) ? $tableau[intval($mois)] : "Ind�fini";
}

		
		<style>
		
 // Fonction pour afficher le calendrier
 function showCalendar($periode) {
    $leCalendrier = "";
    // Tableau des valeurs possibles pour un num�ro 
    de jour dans la semaine
    $tableau = Array("0", "1", "2", "3", "4", "5", "6", "0");

    $nb_jour = Date("t", mktime(0, 0, 0, getMonth($periode), 
    1, getYear($periode)));
    $pas = 0;
    $indexe = 1;

    // Affichage du mois et de l'ann�e
    $leCalendrier .= "\n\t<h2>&raquo; " . monthNumToName
    (getMonth($periode)) . " " . getYear($periode) . "</h2>";

    // Affichage des ent�tes
    $leCalendrier .= "
    <ul id=\"libelle\">
        \t<li>L</li>
        \t<li>M</li>
        \t<li>M</li>
        \t<li>J</li>
        \t<li>V</li>
        \t<li>S</li>

        \t<li>D</li>
    </ul>";
    // Tant que l'on n'a pas affect� tous les jours du mois
    trait� while ($pas < $nb_jour) {
        if ($indexe == 1) $leCalendrier .= 
        "\n\t<ul class=\"ligne\">";

        // Si le jour calendrier == jour de la semaine en cours
        if (Date("w", mktime(0, 0, 0, getMonth($periode), 
        1 + $pas, getYear($periode))) == $tableau[$indexe]) {
          // Si jour calendrier == aujourd'hui
          $afficheJour = Date("j", mktime(0, 0, 0, 
          getMonth($periode), 1 + $pas, getYear($periode)));
          if (Date("Y-m-d", mktime(0, 0, 0, getMonth($periode),
          1 + $pas, getYear($periode))) == Date("Y-m-d")) {
                $class = " class=\"itemCurrentItem\"";

          }
          else {
                // 1 est toujours vrai => on affiche 
                un lien � chaque fois
                // A vous de faire les tests 
                n�cessaire si vous g�rer un agenda par exemple
                if (1) {
                    $class = " class=\"itemExistingItem\"";
                    $afficheJour = "<a href=\"\">" . Date("j",
                    mktime(0, 0, 0, getMonth($periode), 1 + 
                    $pas, getYear($periode))) . "</a>";

                     }
                     else {
                          $class = "";
                          }
                     }
                     // Ajout de la case avec la date
                     $leCalendrier .= "\n\t\t<li$class>
                     $afficheJour</li>";
                     $pas++;
             }
             //
             else {

                    // Ajout d'une case vide
                    $leCalendrier .= "\n\t\t<li>&nbsp;</li>";
             }
             if ($indexe == 7 && $pas < $nb_jour) 
             { $leCalendrier 
             .= "\n\t</ul>"; $indexe = 1;} else {$indexe++;}
          }

          // Ajustement du tableau
          for ($i = $indexe; $i <= 7; $i++) {
               $leCalendrier .= "\n\t\t<li>&nbsp;</li>";
          }
          $leCalendrier .= "\n\t</ul>\n";

          // Retour de la chaine contenant le Calendrier
          return $leCalendrier;

     }
	 </style>

		</body></html>
		