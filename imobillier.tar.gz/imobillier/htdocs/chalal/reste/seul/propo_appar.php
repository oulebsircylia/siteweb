<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="ges/images/index.css" />
<link rel="stylesheet" href="ges/images/index3.css" />
<title>Document sans titre</title>

<style>
body {
	background-color: #FFFFFF;
	background-image:url();
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
</style>
</head>

<body>
<div id="conteneur">
	<div id="header">
		<div id="slogon" align="center">
				<img src="ges/images/images/slogan.jpg" width="160" height="150" />
				<img src="ges/images/images/naima3.jpg" width="960" height="150" />
		</div>
		<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
		</div>
			
		
			<ul id="menu" >
	<li><a href="ges/images/index2.php">Acceuil</a>
		
	</li>
	<li><a href="ges/images/recherche2.php">Recherche</a>
		
	</li>
	<li><a href="ges/images/proposer2.php">Proposer</a>
		
	</li>
	<li><a href="ges/images/inscription.php">Inscription</a>
		
	</li>	
		<li><a href="ges/images/mondat.php">Mondat</a>
		
	</li>	
			<li><a href="ges/images/apropos.php"> A propos</a>
		
	</li>	
		
		<li><a href="ges/images/contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
	<div id="corps">
		
		<div id="droite">
		</div>
		<div id="gauche">
		
		</div>
		<div id="milieu" align="center">
			<h1 align="center">Proposer une apparetement: </h1>
						<center>
						   <form action="<?php echo $editFormAction; ?>" method="POST"  name="bien">
							<table align="center" border="0">
							
							<tr>
							<td>
							</td>
							<td>
							<input type="hidden" name="id_apparetment" id="id_apparetment" />
							</td>
							</tr>
								<tr>
									<td width="143">
									
								  <label for="bien"><span class="Style40">Bien:    </span></label>									</td>
    							  <td width="681">
    							    <select name="t_a" id="t_a" style="display:inline">
                                      <option value="vide">Type</option>
                                      <option value="F1">F1</option>
                                      <option value="F2">F2</option>
                                      <option value="F3">F3</option>
                                      <option value="F4">F4</option>
                                      <option value="F5">F5</option>
                                      <option value="F5">F5+</option>
                                    </select>
    							    <select name="n_e" id="n_e" style="display:inline">
                                      <option value="vide">numero d'�tage</option>
                                      <option value="1_�tage">1 �tage</option>
                                      <option value="2_�tages">2 �tages</option>
                                      <option value="3_�tages">3 �tages</option>
                                      <option value="4_�tages">4 �tages</option>
                                      <option value="5_�tages">5 �tage</option>
                                      <option value="+_de_5">+ de5 �tages </option>
                                    </select>
   						
	
  
			
							      </td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">Description: </label></td>
									<td>
										<textarea name="msg" id="msg"></textarea>	</td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">Lieu: </label></td>
									<td>
										<input type="text" name="li" id="li" />	</td>
								</tr>
								<tr>
									<td>
										<label for="superficie" class="Style40">Superficie: </label>	</td>
								  <td>
										<input type="number" name="sup" id="sup" />
										<span class="Style40">m�</span> </td>
								</tr>
								<tr>
									<td>
										<label for="prix" class="Style40">Prix: </label>									</td>
								  <td>
										<input type="number" name="pri" id="pri" />
										<span class="Style40">DA</span> </td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 1: </label>									    </td>
									<td><label>
									  <input type="file" name="image1" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 2: </label>									    </td>
									<td><label>
									  <input type="file" name="image2" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 3: </label>									    </td>
									<td><label>
									  <input type="file" name="image3" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 4: </label>									    </td>
									<td><label>
									  <input type="file" name="image4" />
									</label></td>
								</tr>
								
								<tr>
									<td>									</td>
									<td>
										<input type="submit" value="Valider"/>									</td>
								</tr>
		</table>
	                        
                            
                            
                            <input type="hidden" name="MM_insert" value="bien">
      </form>
	  </center>
	    </div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9">05-51-57-24-99</p>    </th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">E-mail:</p>
    <p align="center" class="Style9">chalal.immobilier@hotmail.fr</p></th>
  </tr>
</table>
	</div>
</div>
</body>
</html>
