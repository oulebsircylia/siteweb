<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<?php
$date = date("d-m-Y");
$heure = date("H:i");
echo 'Nous sommes le '.$date.' et il est '.$heure;
?>

<?php
if (isset($_POST["valider"])) {
   
      /*IMPORTANT*/

include("connexion.php");

/*faut securiser*/
foreach($_POST as $k => $v){
$v=mysql_real_escape_string(strip_tags($v));
$_POST[$k]=$v;
}

/*faut securiser*/
foreach($_GET as $k => $v){
$v=mysql_real_escape_string(strip_tags($v));
$_POST[$k]=$v;
}
   $username=trim($_POST["username"]);
   $password=trim($_POST["password"]);
   
   
   
        // on regarde si l'url existe d�j�
  // on regarde si l'url existe d�j�
    $sql = "SELECT username FROM members WHERE username='$username'";
    $req = mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());  
     
    // on compte le nombre de r�sultats
    $res = mysql_num_rows($req);

      if($res!=0)  // l'url existe d�j�, on affiche un message d'erreur
        {
             $msg = 'D�sol�, mais ce nom  existe d�j� dans notre base.';
             echo '<script>alert(\' '.$msg.' \');</script>' ;
        }
     else  // L'url n'existe pas, on ins�re les informations du formulaire dans la table
        {

      $sql = "INSERT INTO members(id,username,password) VALUES('','".$username."','".$password."')";                                                                                                                                                                                                                                                                                                                                                   
      // on ins�re les informations du formulaire dans la table  
      mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());
      $msg =  'Les informations sur l inscription  ont �t� ajout�es dans la base de donn�es.</br>';
     
      ///echo '<font color="red">'.$msg.'</font>';
      echo '<script>alert(\' '.$msg.' \');</script>';
         
          session_start();
                                $_SESSION['username'] = $_POST['username'];
                                header('Location: login_success.php');
                                exit();
      }

}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style1 {       color: #FFFFFF;
        font-weight: bold;
}
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="524" border="0" align="center" bgcolor="#FF00FF">
    <tr>
      <td colspan="2"><div align="center" class="Style1">
          <h1>Inscription &agrave; l'espace membre :</h1>
      </div></td>
    </tr>
    <tr>
      <td width="228"><span class="Style1">Login : </span></td>
      <td width="286"><input type="text" name="username" value="" /></td>
    </tr>
    <tr>
      <td><span class="Style1">Mot de passe : </span></td>
      <td><input type="password" name="password" value="" /></td>
    </tr>
    <tr>
      <td colspan="2"><table width="83" border="0" align="center">
          <tr>
            <td width="77"><input type="submit" name="valider" value="Inscription" /></td>
          </tr>
      </table></td>
    </tr>
  </table>
</form>










*****
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Cr�ation d'un formulaire d'inscription en HTML</title>
</head>



<?php

// On met les variables utilis� dans le code PHP � FALSE (C'est-�-dire les d�sactiver pour le moment).
$error = FALSE;
$registerOK = FALSE;

    // On regarde si l'utilisateur est bien pass� par le module d'inscription
if(isset($_POST["register"])){
        
        // On regarde si tout les champs sont remplis, sinon, on affiche un message � l'utilisateur.
           if($_POST["nom_cl"] == NULL OR $_POST["prenom_cl"] == NULL OR $_POST["adresse_cl"] == NULL OR $_POST["adresse_mail_cl"] == NULL OR $_POST["num_tel"] == NULL OR $_POST["login_cl"] == NULL OR $_POST["mot_de_passe"] == NULL OR $_POST["mot_de_passe2"] == NULL){
            
            // On met la variable $error � TRUE pour que par la suite le navigateur sache qu'il y'a une erreur � afficher.
            $error = TRUE;
            
            // On �crit le message � afficher :
            $errorMSG = "Tout les champs doivent �tre remplis !";
                
        }
        
        // Sinon, si les deux mots de passes correspondent :
   elseif($_POST["mot_de_passe"] == $_POST["mot_de_passe2"]){
            
            // On regarde si le mot de passe et le nom de compte n'est pas le m�me
                 if($_POST["login_cl"] != $_POST["mot_de_passe"]){
                
                // Si c'est bon on regarde dans la base de donn�e si le nom de compte est d�j� utilis� :
                    $sql = "SELECT login_cl FROM client WHERE login_cl = '".$_POST["login_cl"]."' ";
                     $sql = mysql_query($sql);
            // On compte combien de valeur � pour nom de compte celui tap� par l'utilisateur.
                     $sql = mysql_num_rows($sql);
            
               // Si $sql est �gal � 0 (c'est-�-dire qu'il n'y a pas de nom de compte avec la valeur tap� par l'utilisateur
                        if($sql == 0){
               
                  // Si tout va bien on regarde si le mot de passe n'ex�de pas 60 caract�res.
                   if(strlen($_POST["mot_de_passe"] < 20)){
                  
                     // Si tout va bien on regarde si le nom de compte n'ex�de pas 60 caract�res.
                     if(strlen($_POST["login_cl"] < 20)){
                         
                        // Si le nom de compte et le mot de passe sont diff�rent :
                        if($_POST["login_cl"] != $_POST["mot_de_passe"]){
                     
                           // Si tout ce passe correctement, on peut maintenant l'inscrire dans la base de donn�es :
                           $sql = "INSERT INTO client (nom_cl,prenom_cl,adresse_cl,adresse_mail_cl,num_tel;login_cl,mot_de_passe) VALUES 
						   ( '".$_POST["nom_cl"]."','".$_POST["prenom_cl"]."','".$_POST["adresse_cl"]."','".$_POST["adresse_mail"]."','".$_POST["num_tel"]."','".$_POST["login_cl"]."','".$_POST["mot_de_passe"]."')";
                           $sql = mysql_query($sql);
                           
                           // Si la requ�te s'est bien effectu� :
                           if($sql){
                           
                              // On met la variable $registerOK � TRUE pour que l'inscription soit finalis�
                              $registerOK = TRUE;
                              // On l'affiche un message pour le dire que l'inscription c'est bien d�roul� :
                              $registerMSG = "Inscription r�ussie ! Vous �tes maintenant membre du site.";
                              
                              // On le met des variables de session pour stocker le nom de compte et le mot de passe :
                              $_SESSION["login_cl"] = $_POST["login_cl"];
                              $_SESSION["mot_de_passe"] = $_POST["mot_de_passe"];
                              
                              // Comme un utilisateur est diff�rent, on cr�e des variables de sessions pour "varier" l'utilisateur comme ceci :
                              // echo $_SESSION["login"]; (bien entendu avec les balises PHP, sinons cela ne marchera pas.
                           
                           }}
                           
                           // Sinon on l'affiche un message d'erreur (g�n�ralement pour vous quand vous testez vos scripts PHP)
                           else{
                           
                              $error = TRUE;
                              
                              $errorMSG = "Erreur dans la requ�te SQL<br/>".$sql."<br/>";
                           
                           }
                        
                        }
                        
                        // Sinon on fais savoir � l'utilisateur qu'il a mis un nom de compte trop long.
                        else{
                        
                           $error = TRUE;
                           
                           $errorMSG = "Votre nom compte ne doit pas d�passer <strong>10 caract�res</strong> !";
                           
                           $login_cl = NULL;
                           
                           $mot_de_passe = $_POST["mot_de_passe"];
                        
                        }
                     
                     }
                  
                  // Si le mot de passe d�passe 60 caract�res on le fait savoir
                  else{
                  
                     $error = TRUE;
                     
                     $errorMSG = "Votre mot de passe ne doit pas d�passer <strong>20 caract�res</strong> !";
                     
                     $login_cl = $_POST["login_cl"];
                     
                     $mot_de_passe = NULL;
                  
                  }
               
               }
               
               // Sinon on affiche un message d'erreur lui disant que ce nom de compte est d�j� utilis�.
               else{
               
                  $error = TRUE;
                  
                  $errorMSG = "Le nom de compte <strong>".$_POST["login_cl"]."</strong> est d�j� utilis� !";
                  
                  $login_cl = NULL;
                  
                  $mot_de_passe = $_POST["mot_de_passe"];
               
               }
            }
            
            // Sinon on fais savoir � l'utilisateur qu'il doit changer le mot de passe ou le nom de compte
            else{
                
                $error = TRUE;
                
                $errorMSG = "Le nom de compte et le mot de passe doivent �tres diff�rents !";
                
            }
            
       }
      
      // Sinon si les deux mots de passes sont diff�rents :      
      elseif($_POST["mot_de_passe"] != $_POST["mot_de_passe2"]){
      
         $error = TRUE;
         
         $errorMSG = "Les deux mots de passes sont diff�rents !";
         
         $login_cl = $_POST["login_cl"];
         
         $mot_de_passe = NULL;
      
      }
      
      // Sinon si le nom de compte et le mot de passe ont la m�me valeur :
      elseif($_POST["login_cl"] == $_POST["mot_de_passe"]){
      
         $error = TRUE;
         
         $errorMSG = "Le nom de compte et le mot de passe doivent �tre diff�rents !";
      
      }
        
    }

?>

<?php

   mysql_close($BDD);

?>


<?php // On affiche les erreurs :
 if($error == TRUE){ echo "<p align='center' style='color:red;'>".$errorMSG."</p>"; }
?>
<?php // Si l'inscription s'est bien d�roul�e on affiche le succ�s :
 if($registerOK == TRUE){ echo "<p align='center' style='color:green;'><strong>".$registerMSG."</strong></p>"; }
?>

<br />
<br />
    <body>
<form action="inscription.php" method="post" name="client">
<table align="center">
 <tr><td><label for="login"><strong>id_client</strong></label></td>
     <td><input type="hidden" name="id_client" /></td>
 </tr>
  <tr>
    <td><label for="login"><strong>Nom:</strong></label></td>
    <td><input  type="text" name="nom_cl" /></td>
  </tr>
  <tr>
    <td><label for="login"><strong>Pr�nom:</strong></label></td>
    <td><input type="text" name="prenom_cl" /> </td>
  </tr>
  <tr>
    <td> <label for="login"><strong>Adresse:</strong></label></td>
    <td> <input type="text" name="adresse_cl" /></td>
  </tr>
  <tr>
    <td><label for="login"><strong>Adresse_mail:</strong></label></td>
    <td><input type="text" name="adresse_mail_cl"  /></td>
  </tr>
  <tr>
    <td><label for="login"><strong>Numero_tel:</strong></label></td>
    <td><input type="int" name="num_tel" /></td>
  </tr>
    <tr>
            
     <td><label for="login"><strong>Nom de compte :</strong></label></td>
       <td><input type="text" name="login_cl" id="login_cl"/></td>
            
    </tr>
            
         <tr>
            
      <td><label for="pass"><strong>Mot de passe :</strong></label></td>
       <td><input type="password" name="mot_de_passe" id="mot_de_passe"/></td>
            
       </tr>
            
        <tr>
         
       <td><label for="pass2"><strong>Confirmez le mot de passe :</strong></label></td>
     <td><input type="password" name="mot_de_passe2" id="mot_de_passe2"/></td>
</tr>
          <tr><td></td><td> <input type="submit" name="register" value="          S'inscrire         "/></td></tr>
  </table>
        
  
        
  </form>
    
    </body>

</html>
*****
</body>
</html>


<body>
</body>
</html>
