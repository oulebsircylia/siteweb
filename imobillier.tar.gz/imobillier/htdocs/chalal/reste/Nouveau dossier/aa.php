<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!DOCTYPE html PUBLIC "" ""><HTML lang="fr"><HEAD><META content="IE=10.000" 
http-equiv="X-UA-Compatible">
 
<META charset="utf-8"> 
<META name="site-verification" content="check"> <TITLE>meavesta  </TITLE> 
<META name="description" content=""> 
<META name="viewport" content="width=device-width, initial-scale=1.0"> 
<META name="viewport" content="width=device-width, initial-scale=1.0"> <!--CSS --> 
<LINK href="http://fonts.googleapis.com/css?family=Open+Sans:200,400,600,700,800" 
rel="stylesheet" type="text/css"> <LINK href="http://www.meavesta.fr/css2/theme.css" 
rel="stylesheet" type="text/css"><LINK href="http://www.meavesta.fr/js2/popupfancy/jquery.fancybox-1.3.4.css" 
rel="stylesheet" type="text/css"> <LINK id="camera-css" href="http://www.meavesta.fr/css2/camera.css" 
rel="stylesheet" type="text/css" media="all"> <LINK href="http://www.meavesta.fr/css2/theme-print.css" 
rel="stylesheet" type="text/css" media="print"> <LINK href="http://www.meavesta.fr/fonts/awesome/font.css" 
rel="stylesheet"> <LINK href="http://www.meavesta.fr/css/style.css" rel="stylesheet" 
type="text/css"><!--// CSS --> <!--SCRIPT --> 
<SCRIPT src="http://www.meavesta.fr/js2/jquery-1.8.2.min.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/popupfancy/jquery.fancybox-1.3.4.pack.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/jquery.easing.1.3.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/jquery.mobile.customized.min.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/bootstrap.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/superfish.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/common.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/placeholder.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/myscript.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/gat.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/totop.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/js2/camera_annonce.js" type="text/javascript"></SCRIPT>
 
<SCRIPT src="http://www.meavesta.fr/plugins.js"></SCRIPT>

<SCRIPT src="http://www.meavesta.fr/js/fonctions.js" type="text/javascript"></SCRIPT>
 <!--// SCRIPT --> <!--[if lt IE 9]>
$.fn.placeholder();
</script>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<SCRIPT src="http://www.meavesta.fr/js2/carousel.js" type="text/javascript"></SCRIPT>

<META name="GENERATOR" content="MSHTML 10.00.9200.16578"></HEAD> 
<BODY class="body p_accueil lan_fr">
<DIV 
class="wrap container container1 container_imagehaut container1_accueil 1 ">
<DIV class="row" etage="1">
<DIV class="span0 image" id="idd" cptspan="0" nomspan="arraynomspan[1][0]" 
spantop="0"><A href="http://www.meavesta.fr/"><IMG title="" alt="Votre agence immobili�re meavesta � PARIS" 
src="http://www.meavesta.fr/image/logo.png"></A>     		 </DIV>
<DIV class="clear"></DIV></DIV></DIV>
<DIV class="wrap container container2 container_menu container2_accueil 2 ">
<DIV class="row" etage="2">
<DIV class="span12 menu_haut" id="idd12" cptspan="12" nomspan="arraynomspan[2][0]" 
spantop="12">
<DIV class="header">
<DIV class="navbar navbar_ clearfix">
<DIV class="row">
<DIV class="span12"><NAV id="main_menu">
<DIV class="menu_wrap">
<UL class="nav sf-menu">
  <LI><A class="onglet_menu_haut " 
  href="http://www.meavesta.fr/">accueil</A></LI>
  <LI><A class="onglet_menu_haut " 
  href="http://www.meavesta.fr/annonces.html">Annonces</A></LI>
  <LI><A class="onglet_menu_haut " href="http://www.meavesta.fr/institutionnels.html">Institutionnels</A></LI>
  <LI><A class="onglet_menu_haut " href="http://www.meavesta.fr/particuliers.html">Particuliers</A></LI>
  <LI><A class="onglet_menu_haut " 
  href="http://www.meavesta.fr/contact.html">contact</A></LI>
  <LI><A class="onglet_menu_haut " 
  href="http://www.meavesta.fr/bio.html">Bio</A></LI></UL></DIV></NAV></DIV></DIV></DIV></DIV></DIV>
<DIV class="clear"></DIV></DIV></DIV>
<DIV 
class="wrap container container3 container_animation container3_accueil 3 ">
<DIV class="row" etage="3">
<DIV class="span12 animation" id="idd12" cptspan="12" nomspan="arraynomspan[3][0]" 
spantop="12"><!--slider--> 
<DIV id="main_slider">
<DIV class="container">
<DIV class="camera_wrap" id="camera_wrap_1">
<DIV data-src="http://www.meavesta.fr/image/anim/1.jpg">
<DIV class="camera_caption fadeIn">
<H2>Mon Engagement Absolu !</H2></DIV></DIV>
<DIV data-src="http://www.meavesta.fr/image/anim/2.jpg">
<DIV class="camera_caption fadeIn">
<H2>Mon Engagement Absolu !</H2></DIV></DIV>
<DIV data-src="http://www.meavesta.fr/image/anim/3.jpg">
<DIV class="camera_caption fadeIn">
<H2>Mon Engagement Absolu !</H2></DIV></DIV>
<DIV data-src="http://www.meavesta.fr/image/anim/4.jpg">
<DIV class="camera_caption fadeIn">
<H2>Mon Engagement Absolu !</H2></DIV></DIV>
<DIV data-src="http://www.meavesta.fr/image/anim/5.jpg">
<DIV class="camera_caption fadeIn">
<H2>Mon Engagement Absolu !</H2></DIV></DIV>
<DIV data-src="http://www.meavesta.fr/image/anim/6.jpg">
<DIV class="camera_caption fadeIn">
<H2>Mon Engagement Absolu !</H2></DIV></DIV></DIV><!-- #camera_wrap_1 -->	   
</DIV></DIV><!--//slider-->     		</DIV>
<DIV class="clear"></DIV></DIV></DIV>
<DIV class="wrap container container4 container_0 container4_accueil 4 ">
<DIV class="row" etage="4">
<DIV class="span3 accueil_annonce" id="idd3" cptspan="3" nomspan="arraynomspan[4][0]" 
spantop="3">
<DIV class="titremodule">Derni�res Annonces</DIV>
<SCRIPT type="text/javascript">
        jQuery(document).ready(function() {
            // example 1
            $("ul.example1").simplecarousel({
               // width:400,
                //height:400,
                visible: 1,
                auto: 2500,
                next: $('.next'),
                prev: $('.prev'),
                pagination: true,
				fade: 300,

            });
            
        });
        
    </SCRIPT>
  
<UL class="example1" style="list-style: none; margin: 0px; padding: 0px;">
  <LI style="text-align: center;"><SPAN>
  <DIV class="row coupdecoeur">
  <DIV class="span3">
    <span><a href="http://www.meavesta.fr/vente-appartement-paris-8eme-arrondissement-6065627.html"><img 
  alt="vente appartement Paris 8eme arrondissement 870000 �" src="http://www.meavesta.fr/photos/6065/6065627_1.jpg"></a></span>
    <DIV class="accueil_titre "><SPAN class="accueil_loc"> vente</SPAN>            
               <SPAN class="accueil_tiret1 tiret">-</SPAN>                       
    <SPAN class="accueil_type">appartement</SPAN>                         <SPAN 
  class="accueil_tiret2 tiret ">-</SPAN>                         <SPAN class="accueil_ville">Paris 
  8eme arrondissement</SPAN>                         <SPAN class="accueil_tiret3 tiret">-</SPAN> 
                          <SPAN class="accueil_prix">  870 000  �</SPAN>         
              </DIV>
  <DIV class="home_cc_container"><A href="http://www.meavesta.fr/vente-appartement-paris-8eme-arrondissement-6065627.html"><SPAN 
  class="home_loc_type accueil_module_loctype">Triangle d'or - Face au th��tre 
  du Rond-point - Dans un immeubl [...]</SPAN></A></DIV>
  <DIV class="post_meta accueil"><A href="http://www.meavesta.fr/vente-appartement-paris-8eme-arrondissement-6065627.html">
  <DIV class="bouton">+ de d�tails</DIV></A> </DIV></DIV></DIV></SPAN></LI>
  <LI style="text-align: center;"><SPAN>
  <DIV class="row coupdecoeur">
  <DIV class="span3"><A href="http://www.meavesta.fr/vente-appartement-paris-6eme-arrondissement-6054709.html"><IMG 
  alt="vente appartement Paris 6eme arrondissement 1365000 �" src="http://www.meavesta.fr/photos/6054/6054709_1.jpg"></A> 
                      
  <DIV class="accueil_titre "><SPAN class="accueil_loc"> vente</SPAN>            
               <SPAN class="accueil_tiret1 tiret">-</SPAN>                       
    <SPAN class="accueil_type">appartement</SPAN>                         <SPAN 
  class="accueil_tiret2 tiret ">-</SPAN>                         <SPAN class="accueil_ville">Paris 
  6eme arrondissement</SPAN>                         <SPAN class="accueil_tiret3 tiret">-</SPAN> 
                          <SPAN class="accueil_prix"> 1 365 000  �</SPAN>        
               </DIV>
  <DIV class="home_cc_container"><A href="http://www.meavesta.fr/vente-appartement-paris-6eme-arrondissement-6054709.html"><SPAN 
  class="home_loc_type accueil_module_loctype">Quartier recherch� - Rue du 
  Dragon - Dans un bel immeuble ancien [...]</SPAN></A></DIV>
  <DIV class="post_meta accueil"><A href="http://www.meavesta.fr/vente-appartement-paris-6eme-arrondissement-6054709.html">
  <DIV class="bouton">+ de d�tails</DIV></A> </DIV></DIV></DIV></SPAN></LI>
  <LI style="text-align: center;"><SPAN>
  <DIV class="row coupdecoeur">
  <DIV class="span3"><A href="http://www.meavesta.fr/vente-appartement-paris-19eme-arrondissement-6054708.html"><IMG 
  alt="vente appartement Paris 19eme arrondissement 255000 �" src="http://www.meavesta.fr/photos/6054/6054708_1.jpg"></A> 
                      
  <DIV class="accueil_titre "><SPAN class="accueil_loc"> vente</SPAN>            
               <SPAN class="accueil_tiret1 tiret">-</SPAN>                       
    <SPAN class="accueil_type">appartement</SPAN>                         <SPAN 
  class="accueil_tiret2 tiret ">-</SPAN>                         <SPAN class="accueil_ville">Paris 
  19eme arrondissement</SPAN>                         <SPAN class="accueil_tiret3 tiret">-</SPAN> 
                          <SPAN class="accueil_prix">  255 000  �</SPAN>         
              </DIV>
  <DIV class="home_cc_container"><A href="http://www.meavesta.fr/vente-appartement-paris-19eme-arrondissement-6054708.html"><SPAN 
  class="home_loc_type accueil_module_loctype">EXCLUSIVIT� - INSTITUTIONNEL VEND 
  - 3P OCCUPE  [...]</SPAN></A></DIV>
  <DIV class="post_meta accueil"><A href="http://www.meavesta.fr/vente-appartement-paris-19eme-arrondissement-6054708.html">
  <DIV class="bouton">+ de d�tails</DIV></A> 
</DIV></DIV></DIV></SPAN></LI></UL><SPAN class="prev">prev</SPAN>     <SPAN 
class="next">next</SPAN>     		 </DIV>
<DIV class="span3 _accueil_annonce" id="idd3" cptspan="3" nomspan="arraynomspan[4][1]" 
spantop="3">
<DIV class="titremodule">Nos Op�rations</DIV>
<SCRIPT type="text/javascript">
  /*      jQuery(document).ready(function() {
            // example 1
            $("ul.example2").simplecarousel({
               // width:400,
                //height:400,
                visible: 1,
                auto: 2500,
                next: $('.next'),
                prev: $('.prev'),
                pagination: true,
				fade: 100,

            });
            
        });
    */    
    </SCRIPT>
  
<UL class="example2" style="list-style: none; margin: 0px; padding: 0px;">
  <LI style="text-align: center;"><SPAN>
  <DIV class="row coupdecoeur">
  <DIV class="span3"><A href="http://www.meavesta.fr/vente-appartement-paris-8eme-arrondissement-6065627.html"><IMG 
  alt="vente appartement Paris 8eme arrondissement 870000 �" src="http://www.meavesta.fr/photos/6065/6065627_1.jpg"></A> 
                      
  <DIV class="accueil_titre "><SPAN class="accueil_loc"> vente</SPAN>            
               <SPAN class="accueil_tiret1 tiret">-</SPAN>                       
    <SPAN class="accueil_type">appartement</SPAN>                         <SPAN 
  class="accueil_tiret2 tiret ">-</SPAN>                         <SPAN class="accueil_ville">Paris 
  8eme arrondissement</SPAN>                         <SPAN class="accueil_tiret3 tiret">-</SPAN> 
                          <SPAN class="accueil_prix">  870 000  �</SPAN>         
              </DIV>
  <DIV class="home_cc_container"><A href="http://www.meavesta.fr/vente-appartement-paris-8eme-arrondissement-6065627.html"><SPAN 
  class="home_loc_type accueil_module_loctype">Triangle d'or - Face au th��tre 
  du Rond-point - Dans un immeubl [...]</SPAN> </A></DIV>
  <DIV class="post_meta accueil"><A href="http://www.meavesta.fr/vente-appartement-paris-8eme-arrondissement-6065627.html">
  <DIV class="bouton">+ de d�tails</DIV></A> </DIV></DIV></DIV></SPAN>           
    </LI></UL><SPAN class="prev">prev</SPAN>     <SPAN class="next">next</SPAN>    
 		 </DIV>
<DIV class="span3 client" id="idd3" cptspan="3" nomspan="arraynomspan[4][2]" 
spantop="3">
<DIV class="titremodule">Liens Utiles</DIV>
<DIV class="row client">
<DIV class="span3">
<DIV style="border: 1px solid rgb(204, 204, 204);"><IMG src="http://www.meavesta.fr/image/liens-utiles.jpg" 
border="0"> </DIV>
<DIV class="lienut"><A class=" calculatrice" href="http://www.meavesta.fr/simulateur_fr/calcul_mensualites/">Calculette 
financi�re</A><A class=" calculatrice" href="http://www.meavesta.fr/simulateur_fr/frais_notaire/">Simulez 
vos frais de notaire</A><A href="http://www.meavesta.fr/alerte-mail.html">Alerte 
Email</A><A href="http://www.meavesta.fr/estimation.html">Estimations</A><A 
href="http://www.meavesta.fr/honoraires.html">Honoraires</A></DIV></DIV></DIV></DIV>
<DIV class="span3 client" id="idd3" cptspan="3" nomspan="arraynomspan[4][3]" 
spantop="3">
<DIV class="titremodule">Coordonn�es</DIV>
<DIV class="row client">
<DIV class="span3">
<DIV style="border: 1px solid rgb(204, 204, 204);"><IMG src="http://www.meavesta.fr/image/logogris.png" 
border="0"> </DIV>
<CENTER>
<DIV style="color: rgb(134, 18, 22);">MEAVESTA </DIV>
<DIV class="accueil_titre" style="height: auto; line-height: normal;">Franck 
GUILBERT</DIV><BR>25 rue de Ponthieu - 75008 Paris <BR>T�l/Fax : 01 73 71 59 63 
<BR>Mobile : 06 16 17 53 52<BR>Mail : fguilbert@meavesta.fr<BR><A href="http://www.meavesta.fr/contact.html">
<DIV class="bouton">Contactez-nous</DIV></A> </CENTER></DIV></DIV></DIV>
<DIV class="clear"></DIV></DIV></DIV>
<DIV class="footer_bottom">
<DIV class="wrap container container5 container_menu_bas container5_accueil 5 ">
<DIV class="row" etage="5">
<DIV class="span12 menu_bas" id="idd12" cptspan="12" nomspan="arraynomspan[5][0]" 
spantop="12">
<DIV class="container">
<DIV class="row">
<DIV class="span6">
<DIV class="copyright">
<UL class="menubas">
  <LI><A class=" " href="http://www.meavesta.fr/infos-legales.html" rel="nofollow">Infos 
  l�gales</A>					   <SPAN class="separateur-link">&nbsp; . 
  &nbsp;&nbsp;</SPAN>					  </LI>
  <LI><A class=" " href="http://www.meavesta.fr/admin.html" 
  rel="nofollow">Admin</A>					  					   </LI>								</UL></DIV></DIV>
<DIV class="separateur_20 visible-phone"></DIV>
<DIV class="span6 align_right">
<DIV class="cont_credits">
<DIV><A href="http://www.creation-site-immobilier.net/hebergement.htm"><IMG alt="http://www.creation-site-immobilier.net/hebergement.htm" 
src="http://www.meavesta.fr/images/lienbaspage/CCCCCC/design-by.png">            
		 </A><A href="http://www.creation-site-immobilier.net/">        	<IMG alt="http://www.creation-site-immobilier.net" 
src="http://www.meavesta.fr/images/lienbaspage/CCCCCC/creation-site-immo.png">   
         		 </A>        	<IMG alt="" src="http://www.meavesta.fr/images/lienbaspage/CCCCCC/pour.png"> 
           		 <A href="http://www.aktifimmo.com/immobilier-paris-75.html"><IMG 
alt="Aktifimmo" src="http://www.meavesta.fr/images/lienbaspage/CCCCCC/aktifimmo.png"> 
           		 </A>        	<IMG alt="" src="http://www.meavesta.fr/images/lienbaspage/CCCCCC/copyright-2014.png"> 
           		 </DIV></DIV></DIV></DIV></DIV></DIV>
<DIV class="clear"></DIV></DIV></DIV></DIV><!-- No piwik -->
<CENTER> </CENTER></BODY></HTML>
