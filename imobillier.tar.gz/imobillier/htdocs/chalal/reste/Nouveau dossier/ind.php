<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>
<style type="text/css">
<!--
.Style8 {
        color: #FF00FF;
        font-style: italic;
}
.Style11 {color: #FFFFFF; font-style: italic; }
-->
</style>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<form name="form1" method="post" action="checklogin.php">
<td>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#0A5B79">
<tr>
<td colspan="3"><table width="512" border="0" align="center">
  <tr>
    <td width="395"><h1 align="center" class="Style8">Identifiez-vouz !! </h1></td>
    <td width="101"><img src="images/logo3.jpg" alt="dfghj" width="100" height="70" /></td>
  </tr>
</table></td>
</tr>
<tr>
<td width="69"><span class="Style11">Username</span></td>
<td width="7"><span class="Style11">:</span></td>
<td width="422"><input name="myusername" type="text" id="myusername" ></td>
</tr>
<tr>
<td><span class="Style11">Password</span></td>
<td><span class="Style11">:</span></td>
<td><input name="mypassword" type="text" id="mypassword" ></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input name="Submit" type="submit" value="Login">
  <table width="78" border="0" align="right">
    <tr>
      <td><a href="a.php" class="Style11">Inscription!!</a></td>
    </tr>
  </table></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<body>
</body>
</html>
