<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>
<?php
/* Attention, dans php.ini => output_buffering = 0 */
/* Attention, aucun texte HTML ne doit �tre envoy� avant le cookie */
/* En d�but de code, pas de blancs */
setcookie('langage', 'PHP version 5', time()+ 60*60*24);
/* time()+ 60*60*24 => cookie � dur�e  de vie 24 heures */
?>

<head>
<title>Les cookies</title></head>
<body>
<?php
/* V�rifions si le cookie a �t� re�u */
if(isset($_COOKIE['langage']))
{
/* Dans le cas o� le cookie existe */
echo '<p>un cookie a �t� envoy�</p>';
echo '<p>son nom est langage</p>';
/* Lecture et affichage du contenu du cookie */
echo '<p>Son contenu est : ';
echo $_COOKIE['langage'];
echo '</p>';
}else{
/* Autrement c'est que le cookie n'a pas �t� re�u */
echo '<p>Aucun cookie du nom de langage n\'a �t� re�u</p>';
}
echo '<p>Liste de tous les cookies :</p>';
echo '<pre>';
print_r($_COOKIE);
echo '</pre>';
echo'<br/>';
?>
</body>
</html>
<body>
</body>
</html>
