<?php require_once('Connections/conn_memoire.php'); ?>
<?php
mysql_select_db($database_conn_memoire, $conn_memoire);
$query_Recordset1 = "SELECT * FROM client";
$Recordset1 = mysql_query($query_Recordset1, $conn_memoire) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>

<?php
	if (isset($_SESSION['login'])){
		//On le deconnecte en supprimant simplement les sesssions l_cl et id_cl
		unset($_SESSION['login'], $_SESSION['id']);
	?>
			<script type="text/javascript">
					window.alert("La d�connexion a r�ussi");
			</script>
			<a href="index.php"></a>
	<?php
	}
	else{
		$ouserename = '';
		//O v�rifie si le formilaire a �tait envoyer 
		if (isset ($_POST['login'], $_POST['mdp'])){
				//On echappe les variables pour pouvoir les mattres dans les requ�tes sql
				if(get_magic_quotes_gpc()){
					$ousername = stripslashes($_POST['login']);
					$login = stripslashes($_POST['login']);
					$mdp = stripslashes($_POST['mdp']);
				}
				else{
								$login = mysql_real_escape_string($_POST['login']);
					$mdp = $_POST['mdp'];
				}
				//On r�cup�re le mot de passe de l'utilisateur
				$req = mysql_query('select password, id from client where login="'.$l_cl.'"');
				$dn = mysql_fetch_array($req);
				//On le compare � celui qui la entrer et on v�rife si le nombre existe
				if ($dn['mot_de_passe_cl'] == $mdp and mysql_num_rows($req)>0){
						//si le mot de passe est bon, on ne vas pas afficher le formulaire
						$form = true;
						//on enregistre son pseudo dans la session l_cl et son identifiant dans la session id_cl
						$_SESSION['login'] = $_POST['login'];
						$_SESSION['id'] = $dn['id'];
						?>
					<script type="text/javascript">
						window.alert("La connexion a r�ussi");
					</script>
					<a href="proposer2.php">narim�ne</a>
					<?php	
				}
				else{
					//Sinon on indique que la combinaison n'est pas bonne
					$form = true;
					?>
						<script type="text/javascript">
								window.alert("La combinaison que vous avez netrer n'est pas bonne");
						</script>
					<?php	
				}
			}
			else{
				$form = true;
			}
			if ($form){
				//On affiche le formulaire
			?>
			

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<style>
body {
	background-color: #CCCCCC;
	background-image:url(images/BACKGROUND.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
</style>
</head>

<body>
<div id="conteneur">
	<div id="header">
		<div id="slogon" align="center">
				<img src="images/slogan.jpg" width="160" height="150" />
				<img src="images/naima3.jpg" width="960" height="150" />
		</div>
		<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onMouseMove="this.stop();" onMouseOut="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
		</div>
			
		
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
	<div id="corps">
		
		<div id="droite">
		</div>
		<div id="gauche">
		
		</div>
		<div id="milieu">
			<p>	<h4>&nbsp;&nbsp;Veuillez s'authentifier pour proposer un bien:</h4></p>
			<form method="POST" name="connexion" action="proposer2.php">
		<center><fieldset style="border:solid 1px black;padding:40px;width:90px;color:#000000;" >
		<label for="login" >Login</label>
		<input type="text" name="login" id="l_cl" placeholder="Nom utilisateur" /><br/>
		<label for="mot de passe">Mot de passe</label>
		<input type="password" name="mdp" id="mdp" placeholder="Mot de passe" />
		<center><input type="submit" style="font-size:11; font-weight:bold; border:solid 1px black; cursor:pointer;"   value="connexion" /></center>
		</fieldset></center>
		</form>
		<p><h4>&nbsp;&nbsp;Si vous n'�tes pas encore inscri, veuillez <a href="inscription.php">s'inscrire </a>afin de devenir un client.</h4></p>
	    </div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9">05-51-57-24-99</p>    </th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">E-mail:</p>
    <p align="center" class="Style9">chalal.immobilier@hotmail.fr</p></th>
  </tr>
</table>
	</div>
	
</div>
<?php
}
			
		}
	?>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
