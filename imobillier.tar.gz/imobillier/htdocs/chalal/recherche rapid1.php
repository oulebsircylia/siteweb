 <?php

require_once('config.php' );

if(isset($_POST['submit'])){

     if(isset($_POST['t']))	$t=  $_POST['t'];  else $t="";
     if(isset($_POST['lieu']))	$lieu=  $_POST['lieu'];else $lieu="";
if(isset($_POST['type']))$type_tran=  $_POST['type'];else $type_tran="";
		
 //La recherche a partir type 
	 if($_POST['t']=="appartement"){
 $sql="SELECT * FROM bien, transaction,appartement WHERE type_bien='appartement'AND bien.id_bien=transaction.id_bien AND bien.id_bien=appartement.id_bien ";
	
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	 } 
	else{
	if($_POST['t']=="villa"){
 $sql="SELECT * FROM bien, transaction,appartement WHERE type_bien='villa'AND bien.id_bien=transaction.id_bien AND bien.id_bien=villa.id_bien ";
	
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	 } 
	 else {
	 if($_POST['t']=="terrain"){
 $sql="SELECT * FROM bien, transaction,terrain WHERE type_bien='terrain'AND bien.id_bien=transaction.id_bien AND bien.id_bien=terrain.id_bien ";
	
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	 } else{
	 if($_POST['t']=="entrepot"){
 $sql="SELECT * FROM bien, transaction,entrepot WHERE type_bien='entrepot'AND bien.id_bien=transaction.id_bien AND bien.id_bien=entrepot.id_bien ";
	
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	 } 
	else{
// La recherche a partir de  type de transaction	
    if ($_POST['type']=="achat"){
	 $sql="SELECT * FROM bien, transaction WHERE type_transaction='achat'AND bien.id_bien=transaction.id_bien ";
	 echo $sql;
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
	 } 
else 
     {
    if ($_POST['type']=="location"){
	 $sql="SELECT * FROM bien, transaction WHERE (type_transaction='location' AND bien.id_bien=transaction.id_bien )";
	 echo $sql;
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
      }
 else {
	 
   	 if ($_POST['type']=="Echange"){
	 $sql="SELECT * FROM bien, transaction WHERE (type_transaction='Echange' AND bien.id_bien=transaction.id_bien )";
	 echo $sql;
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
    }
else 
	{
	  
	 
	 
	 
//La recherche a partir de lieu

	if ($_POST['lieu']=="$lieu"){
	 $sql="SELECT * FROM bien WHERE (lieu='$lieu')";
	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");

	}
	}
	}
	}

	 
	}}


}










/*if($_POST['t']=="appartement"){
$sql="SELECT  * FROM  bien,  appartement, transaction
WHERE((accord=1 AND transaction.id_bien=bien.id_bien AND  bien.id_bien=appartement.id_bien ANd type_bien='$t') 
AND((lieu='$lieu' AND type_transaction='$type_tran'AND type_bien='$t')
OR (((lieu='$lieu' AND type_transaction='$type_tran') OR type_bien='$t')
OR ((lieu='$lieu' OR type_transaction='$type_tran' AND type_bien='$t')))))";
	

//exécution de la requête SQL:
$conn =config::connectDB();
$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
}
		
/*		
  if($_POST['t']=='villa'){
$sql="SELECT  * FROM  bien,  villa, transaction
 WHERE ((accord=1 AND transaction.id_bien=bien.id_bien   AND  bien.id_bien=villa.id_bien AND type_bien='$t') 
AND ( (lieu='$lieu' AND type_transaction='$type_tran'AND type_bien='$t' )
OR ( ((lieu='$lieu' AND type_transaction='$type_tran') OR type_bien='$t' )
OR ( (lieu='$lieu' OR type_transaction='$type_tran' AND type_bien='$t')))))";
	
//exécution de la requête SQL:
 $conn =config::connectDB();
$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
}


		/*  if($_POST['t']=='terrain'){
		$sql="SELECT  * FROM  bien,  terrain, transaction WHERE (accord=1 AND transaction.id_bien=bien.id_bien   AND (bien.id_bien=terrain.id_bien ) AND (type_bien='t'  OR lieu='lieu'  OR (prix > '$prixinf' and prix < '$prixsup' )))";
		
		//exécution de la requête SQL:
		 
		  $conn =config::connectDB();
		$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
		
  }
 if($_POST['t']=='entrepot'){
 
		$sql="SELECT  * FROM  bien,  entrepot, transaction WHERE (accord=1 AND transaction.id_bien=bien.id_bien   AND (bien.id_bien=entrepot.id_bien ) AND (type_bien='t'  OR lieu='lieu'  OR (prix > '$prixinf' and prix < '$prixsup' )))";
		
		//exécution de la requête SQL:
		 
		  $conn =config::connectDB();
		$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
		
	}*/
	}
	
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
 <link rel="stylesheet"  href="file:///C|/Users/warda/Desktop/php/calendrier/calendar.css" type="text/css" media="all" />
 <link rel="stylesheet"  href="file:///C|/Users/warda/Desktop/php/calendrier/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="file:///C|/Users/warda/Desktop/php/yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="file:///C|/Users/warda/Desktop/php/calendrier/calendar.js"></script>
<script type="text/javascript" src="file:///C|/Users/warda/Desktop/php/calendrier/FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="file:///C|/Users/warda/Desktop/php/index.css" />
<link rel="stylesheet" href="file:///C|/Users/warda/Desktop/php/index3.css" />
<title>Document sans titre</title>

<style>
body {
	background-color: #FFFFFF;
	background-image:url(images/imageaa.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;

max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:270px;
	
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:270px;
	
	border-left: 1px solid black;
	}	
.Style1 {
	font-size: 24px;
	font-weight: bold;
}
.Style7 {color: #FFFFFF}
</style>
</head>

<body>
<div id="conteneur">

	<div id="header">
		<div id="slogon" align="center"><img src="images/warda.jpg" width="160" height="150" /><img src="images/naima3.jpg" width="960" height="150" />		</div>
		<div id="text_défiler">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col"> <span class="Style7">
				    <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();">
				      <em>Agence Immobiliére CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
			        </marquee>
					  </span> </th>
   				</tr>
 			</table>
		</div>
			
		<nobr>
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
			<li><a href="apropos.php"> A propos</a>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</nobr>
	</div>
	<div id="corps">
		
		<div id="droite">
		</div>
		<div id="gauche">
		
		</div>
		<div id="milieu" align="center">
		  
		  <center>
						
	  <br />
	 
	    <table width="726" border="0">
		
		<?php if(!empty($oRow)){ ?>
		 <span class="Style1 Style7">Les r&eacute;sultats de la recherche		  </span>
		 <br /><br />
		  <br /><br />
  <?php  while($rows = mysqli_fetch_array($oRow)){?>
  <center>
		 
		</center>
  <tr>
    <td width="250" height="204"><img src="./images/<?php echo $rows['image1'] ;?>"  name="image" width="250px" height="200px"/></td>
    <td width="460"> 
	<strong>Type de bien:</strong>	<?php echo $rows['type_bien'] ;?><strong>.</strong>	<br>
	<strong>Prix:</strong>	<?php echo $rows['prix'] ;?> <strong>DA.</strong>	<br>
	<strong>Superficie:</strong>	<?php echo $rows['superficie']  ;?> <strong>m².</strong>	<br />
	<br /><br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="voir.php?id=<?php echo $rows['id_bien'] ;?>"> + DE DETAILS </a>

	</td>
  </tr>
  <?php }}?>
</table>
<br /><br /><br />
<br /><br /><br />
	      </center>
      </div>
	 <div id="footer" >
   <table width="1219" height="178" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#000000">
	  
  <tr bgcolor="#666666">
    <th width="391" height="174" align="center" valign="top" bgcolor="#FFFFFF" scope="col"><p class="Style9"><img src="images/icone_recrutement.jpg" alt="1" width="377" height="167" /></p>    </th>
    <th width="393"  valign="top" bgcolor="#FFFFFF" scope="col">
<img src="images/Nouveau dossier (2)/maison-moderne-realiste-vecteur-icone_279-9647.jpg"width="50" height="48"/>Rue Aissat Idir Akbou -B&eacute;jaia-
<br /><img src="images/Nouveau dossier (2)/11.JPG" width="50" height="48" />  07-72-24-62-97<strong> /</strong>05-51-57-24-99<br />
<img src="images/Nouveau dossier (2)/14.JPG" alt="1" width="45" height="51" />chalal.immobilier@hotmail.fr</th>
     
    <th width="418" align="center" valign="top" bgcolor="#FFFFFF" scope="col"><table width="361" border="0">
      <tr>
        <td width="173"><a href="index.php"> Acceuil</a></td>
        <td width="178"><a href="inscription3.php">Inscreption</a></td>
      </tr>
      <tr>
        <td><a href="recherche.php">Recherche</a></td>
        <td><a href="contact.php"></a>	<a href="apropos.php">A propos</a></td>
      </tr>
      <tr>
        <td><a href="proposer1.php">Proposer</a></td>
        <td><a href="mondat.php">Mondat</a></td>
      </tr>
      <tr>
     <td height="49" align="center"> <img src="images/Nouveau dossier (2)/communication_icon.png" alt="4"width="52" height="36"/>
	 <a href="contact.php">Contactez-nous</a><a href="apropos.php"></a></td>
      </tr>	
    </table>	</th>
  </tr>
</table>
  </div>
	
</div>
</body>
</html>
