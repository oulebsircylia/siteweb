
<?php require_once('connexion.php'); ?>
<?php
session_start(); 

?>

<?php
$i=0 ;
$req2 = "SELECT *  FROM map  " ;
$res2= mysql_query($req2);
 


?>
<?php

$req3 = "SELECT *  FROM map  " ;
$res3= mysql_query($req3);
 $resp3=mysql_fetch_array($res3);
$valeur=$resp3['nub'] ;

?>



<link rel="stylesheet" type="text/css" href="view.css" media="all">

<script type="text/javascript" src="calendar.js"></script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>BC interne</title>

<style media="print" type="text/css">   .noImpr {   display:none;   } </style>

<style type="text/css">
<!--
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 955px;
	vertical-align: middle;
	padding-left: 5px;
	font-weight: bold;
	color: #FFF;
	font-style: normal;
	font-family: calibri;
	text-align: left;
}
#CONTNN #Stau ul {
	margin: 0px;
	list-style-type: none;
	padding: 2px;
	display: inline;
}
#CONTNN #Stau ul li {
	vertical-align: middle;
	display: inline;
	text-align: left;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: auto;
	width: 960px;
	background-repeat: repeat-y;
	text-align: center;
	vertical-align: top;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
	margin: 0px;
}
#CONTNN #CORP #form1 .noImpr a #Retour {
	text-decoration: none;
}
#CONTNN {
	width: 960px;
	margin-right: auto;
	margin-left: auto;
}
#CONTNN #Stau table tr th {
	text-align: left;
	color: #FFF;
}
#CONTNN #CORP #form1 {
	text-align: center;
	vertical-align: top;
	text-decoration: none;
}
#CONTNN #Stau table tr th a {
	color: #FFF;
	text-decoration: none;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
#CONTNN #CORP #form1 h2 {
	font-family: calibri;
}
.ht {
	font-family: calibri;
}
a {
	text-decoration: none;
}
#CONTNN #CORP table tr td .ht em strong u font strong {
	font-family: calibri;
}
#CONTNN #CORP table tr td p font {
}
#CONTNN #CORP table tr td p font {
	text-align: center;
}
#CONTNN #CORP table tr td p font {
	font-size: 18px;
}
#CONTNN #CORP table tr td p font {
	font-weight: bold;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onLoad="MM_preloadImages('images/B32 .jpg','images/B3i2.jpg','images/B3c2.jpg','images/IMG/gtk-refresh.png','images/gs1.jpg')">
<div id="CONTNN">
  <div id="Stau">
    <p><br />
   </p>
  </div>
  <div id="CORP">
    <table width="900" border="0" cellspacing="0" cellpadding="0" >
      <tr>
      <td width="220">&nbsp; </td>
        <td width="460" align="center"><br />
          <p><font face="CALIBRI, Times, serif">
            <center>
              MINISTÉRE DE L'ENSEIGNEMENT SUPÉRIEUR <br/>
              &nbsp;&nbsp;ET DE LA RECHERCHE SCIENTIFIUE
            </center>
          </font></p>
          <h3>&nbsp;</h3></td>
      </tr>
      <tr  align="center">
      <td></td>
        <td  ><h2 align="center" class="ht"><em><strong><u><font face="Times New Roman, Times, serif"><strong>BON D'ENTREE</strong></font> N°:°<?php echo $valeur; ?></u></strong></em></h2></td>
        <td width="220">BEJAIA ,le
        <?php $dat=date('d-m-y');echo"$dat"; ?></td>
      </tr>
    </table>
    <form id="form1" name="form1" method="post" action="">
      <center>
        <BR />
      </center>
<center>
        <table width="873" border="1" cellspacing="0" cellpadding="5" bgcolor="#EEFFFF">
        <tr>
          <td><table width="100%" border="1" cellspacing="0" cellpadding="10" bgcolor="#CCCCCC">
            <tr align="center" bgcolor="#6FA1D9" style="background-color: #D1E7F3; color: #000;" >
              <td width="">N°ord</td>
              <td width="">N° facture</td>
              <td width="">Date facture</td>
              <td width="">Fournisseur</td>
              <td width="">Qtt livré</td>
              <td width="">Désignation</td>
            </tr>
            <tr bgcolor="#F9F9F9">
              <?php 
					while ( $resp2=mysql_fetch_array($res2)) {          ?>
              <td width="" align="left"><?php echo $i=($i+1) ; ?></td>
              <td width=""><?php echo $resp2['nfact']; ?></td>
              <td width=""><?php echo  $resp2['dat_var'] ; ?></td>
              <td width=""><?php echo $resp2['nfour']; ?></td>
              <td width=""><?php echo $resp2['qttvar']  ; ?></td>
              <td width=""><?php echo $resp2['designation'] ; ?></td>
            </tr>
            <?php } ?>
          </table></td>
        </tr>
      </table></center>
      <br />
<div class="noImpr"></div>
<br />
    <table width="960" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="299" scope="col"><font face="Times New Roman, Times, serif">LE MAGASINIER </font><br />
          <br/>
Nom et Prénom : <?php echo $_SESSION['nom']; ?> <span><?php echo $_SESSION['prenom']; ?><span> </span></span><br/>
<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SIGNATURE</th>
        <th width="375" scope="col"><span class="noImpr">
          <input name="imprim2" type="button"onclick="window.print()" value="Imprimer" />
          <input name="retour" type="button" onClick="window.location='entree.php'" value="  Retour  " />
        </span></th>
        <th width="286" scope="col">&nbsp;<font face="Times New Roman, Times, serif">L'ACHETUER <br/>
            <br/>
        </font> Nom et Prénom :......... <br/>
        <br/>
SIGNATURE</th>
      </tr>
    </table>
    </form>
    <BR /> <BR />
</div>

  <div id="PIED"></div>
</div>
</body>
</html>
