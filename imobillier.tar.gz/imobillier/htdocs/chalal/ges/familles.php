
<?php require_once('connexion.php'); ?>
<?php
$affich="1";


session_start(); 
if ( $_SESSION['privilege'] == "admin"){ 
}
else {
header("Location:index.php?erreur=intru"); // redirection en cas d'echec
}

?>
<?php
$m="" ;
$etat="0";
if(isset($_POST['enregistrer'])){ // on vérifie la présence des variables de formulaire (si le formulaire a été envoyé)

	if(empty($_POST['fam']) ){ //  reridection  si la variable n'est pas presnté	
		header("Location:accueil.PHP");
	}
	else {
	
	$fm=$_POST['fam'] ;

		$add_fam = sprintf(" INSERT INTO `gestock`.`famille` (`design_fam` )VALUES ('$fm')");
				
  		$result = mysql_query($add_fam, $dbprotect) or die(mysql_error());
	
		header("Location:familles.PHP"); // redirection si création réussie
	
	}
	
}
?>

<?php
$reqa = "SELECT design_fam FROM famille" ;
$resulf= mysql_query($reqa);


?>

<?php
if(isset($_POST['supprimer'])){   


$requete2="DELETE FROM famille WHERE design_fam='".$_POST['famm']."' ";             
mysql_query($requete2);
header("Location:familles.php");

}

?>
<?php

if (isset($_POST['modif'])){
	$etat="1";
	
$reqq="SELECT  design_fam  FROM famille  WHERE design_fam='".$_POST['famm']."' ORDER BY design_fam ";
mysql_select_db($database_dbprotect, $dbprotect);
$mod=mysql_query($reqq,$dbprotect) or die(mysql_error());

$modf=mysql_fetch_array($mod) ;

$m=$modf['design_fam'] ;

} 
// la modification

if (isset($_POST['valider'])){
	$etat="0";

	
$h=$_POST['selectioner'] ;
$req1="UPDATE famille SET design_fam='".$_POST['fam']."'   WHERE design_fam='$h' ";
mysql_select_db($database_dbprotect, $dbprotect);
mysql_query($req1, $dbprotect)or die(mysql_error()) ;
header("Location:familles.php");
}


$selectt = "SELECT * FROM famille  ORDER BY design_fam ";
$resultf = mysql_query($selectt);

?>
 <?php 
  if(isset($_POST['afficher'])){
	  $affich="1";
	  }
  if(isset($_POST['cacher'])){
  $affich="0";
  }
  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>familles</title>
<style type="text/css">
<!--
#entete {
	background-image: url(images/Gest/fournisseur.jpg);
	height: 140px;
	width: 960px;
}
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 955px;
	vertical-align: middle;
	padding-left: 5px;
	font-weight: bold;
	color: #FFF;
	font-style: normal;
	font-family: calibri;
	text-align: left;
}
#CONTNN #Stau ul {
	margin: 0px;
	list-style-type: none;
	padding: 2px;
	display: inline;
}
#CONTNN #Stau ul li {
	vertical-align: middle;
	display: inline;
	text-align: left;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: auto;
	width: 960px;
	background-repeat: repeat-y;
	text-align: center;
	padding: 10px;
}
#CONTNN #CORP #form1 table {
	padding-left: 5px;
	vertical-align: top;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
}
#CONTNN {
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	padding-left: 0px;
}
#MENU {
	background-image: url(images/img06.gif);
	background-repeat: repeat-x;
	height: 44px;
	width: 960px;
	text-align: center;
}
#CONTNN #MENU table tr {
	text-align: center;
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	padding-left: 225px;
}
#CONTNN #Stau table tr th {
	text-align: left;
	color: #FFF;
}
#CONTNN #Stau table tr th a {
	color: #FFF;
	text-decoration: none;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
#CONTNN #CORP #form1 table {
	text-align: center;
	margin-left: 0px;
}
#CONTNN #CORP h2 strong {
	font-family: calibri;
}
#CONTNN #CORP #form1 div center table tr td {
	font-family: calibri;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('images/B32 .jpg','images/B3i2.jpg','images/B3c2.jpg','images/IMG/gtk-refresh.png','images/gs1.jpg')">
<div id="CONTNN">
  <div id="entete"></div>
  <div id="Stau">
    <table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="54" height="34" scope="col"><img src="images/MSN Messenger.png" width="28" height="28" /></th>
        <th width="771" scope="col">Bienvenue .:: <span><?php echo $_SESSION['prenom']; ?><span> </span><?php echo $_SESSION['nom']; ?> ::.</span></th>
        <th width="125" scope="col"><a href="index.php?erreur=logout"><strong>Se Déconnecter</strong></a></th>
      </tr>
    </table>
  </div>
  <div id="MENU">
    <table width="677" height="44" border="0" align="center" cellspacing="0">
      <tr>
        <th width="170" height="40" scope="col"><a href="Gestion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','images/B32 .jpg',1)"><img src="images/Gestion .jpg" name="Image2" width="170" height="40" border="0" id="Image2" /></a></th>
        <th width="170" scope="col"><a href="imprission.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','images/B3i2.jpg',1)"><img src="images/B3i1.jpg" name="Image3" width="170" height="40" border="0" id="Image3" /></a></th>
        <th width="170" scope="col"><a href="Consultation.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','images/B3c2.jpg',1)"><img src="images/B3c1 .jpg" name="Image4" width="170" height="40" border="0" id="Image4" /></a></th>
        <th width="159" scope="col"><a href="admin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','images/gs1.jpg',1)"><img src="images/gs.jpg" name="Image5" width="170" height="40" border="0" id="Image5" /></a></th>
      </tr>
    </table>
  </div>
  <div id="CORP">
    <h2><strong>OPERATIONS SUR LES FAMILLES</strong></h2>
    <form id="form1" name="form1" method="post" action="">
      <div align="left">
        <center><table width="900" border="0" cellspacing="10" cellpadding="0"  bgcolor="#F9F9F9">
          <tr>
            <td width="447" scope="col" align="left"><p>
              <label for="fam">Famille</label><input type="hidden" name="selectioner" value="<?php echo $m ; ?>"></input>
              : </p>
              <p>
                <textarea name="fam" id="fam" cols="45" rows="3" value="<?php echo $m ; ?>"><?php echo $m ; ?></textarea>
              </p>
              <p>&nbsp;</p></td>
            <td width="503" scope="col" align="center"><p>
              <label for="fami">Sélectionner une famille:<br />
                <br />
              </label>
               <select name="famm" id="famm">
			   <option >  </option> 
			  <?php
			  while($famille=mysql_fetch_array($resulf)){ ?>
            <option value="<?php  echo $famille['design_fam']; ?>"> <?php  echo $famille['design_fam']; ?> </option>

<?php        }    ?>
			  
              </select>
            </p>
              <p>&nbsp;</p>
              <p>
                <label for="modif"></label>
              </p></td>
          </tr>
          
        </table></center>
        
        <center>
        <table width="900" border="0" cellspacing="10" cellpadding="0"  bgcolor="#EFEFEF">
        <tr >
          <td width="426"  align="center" bgcolor=""><?php if($etat == "0") { ?>
           
              <label for="button"></label>
              <input type="submit" name="enregistrer" id="enregistrer" value="Enregistrer" />
              <label for="button2"></label>
              <?php } ?>
              <?php if($etat == "1") { ?>
              <input type="submit" name="valider" id="valider" value="Valider la modification" />
              <?php } ?>
              <input type="submit" name="button2" id="button2" value="Rénitialiser" />
           
            </td>
          <td width="444"  align="center"><input type="submit" name="modif" id="modif" value="Modifier" />
            <label for="supprimer2"></label>
            <input type="submit" name="supprimer" id="supprimer2" value="Supprimer" /></td>
          </tr>
        </table>
        <br />
        <input name="afficher" type="submit" value="Afficher la table" />
        <label for="cacher"></label>
        <input type="submit" name="cacher" id="cacher" value="Cacher la table" />
        <br />
        <br />
        <center>
          <?php if($affich=="1"){?>
          <table width="455" border="1" cellspacing="0" cellpadding="5" bgcolor="#EEFFFF">
            <tr bgcolor="#BEDEEB" align="center">
             <td width="56" align="center" >Id</td>
              <td width="373" align="center" >Famille</td>
               
            </tr>
            <tr>
              <?php while(  $faml =mysql_fetch_array($resultf)){?>
              <td align="center"><?php echo $faml ['id_fam'];?></td>
              <td align="left"><?php echo $faml ['design_fam'];?></td>
             
            </tr>
            <?php } ?>
          </table>
          <?php } ?>
        </center>
        </center>
        
      </div>
    
    </form>
    <br />
  </div>
  <div id="PIED"></div>
</div>
</body>
</html>
