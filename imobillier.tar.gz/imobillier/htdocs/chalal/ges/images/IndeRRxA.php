<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans nom</title>
<style type="text/css">
<!--
#entete {
	background-image: url(images/bgindex.jpg);
	height: 140px;
	width: 960px;
}
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 958px;
	vertical-align: middle;
	padding-left: 5px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: 500px;
	width: 960px;
	background-repeat: repeat-y;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
}
#CONTNN {
	width: 960px;
	margin-right: auto;
	margin-left: auto;
}
#MENU {
	background-image: url(images/img06.gif);
	background-repeat: repeat-x;
	height: 40px;
	width: 960px;
	text-align: center;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
-->
</style>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="CONTNN">
  <div id="entete"></div>
  <div id="Stau"><img src="images/MSN Messenger.png" width="28" height="28" /> </div>
  <div id="MENU">
    <ul id="MenuBar1" class="MenuBarHorizontal">
      <li><a class="MenuBarItemSubmenu" href="#">G.Stock</a>
        <ul>
          <li><a href="Article.html">G.Articles</a>          </li>
          <li><a href="famille.html">G.Famillles</a></li>
          <li><a href="fournisseur.html">G.Fournisseurs</a></li>
          <li><a href="entreé.html">G.Des Entr&eacute;es</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Impression</a>
        <ul>
          <li><a href="bninterne.html">B.C.Interne</a></li>
          <li><a href="bnsortie.html">B.Sortie</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Consultation</a>
        <ul>
          <li><a href="fiches.html">Fiche de Stock</a></li>
          <li><a href="selection.html">Par Selection</a></li>
        </ul>
      </li>
</ul>
  </div>
  <div id="CORP"></div>
  <div id="PIED"></div>
</div>
<script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
</body>
</html>
