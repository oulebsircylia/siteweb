

<html xmlns="">
<head>
  <link rel="stylesheet"  href="yui/ap-addons/calendar/assets/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="yui/calendar/calendar.js"></script>
<script type="text/javascript" src="FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<SCRIPT LANGUAGE="JavaScript">
function Hour () {
Today = new Date()();
Heure = Today.getHours();
Min = Today.getMinutes();
Sec = Today.getSeconds();
MessageHeure = Heure + "h " + Min + "m " + Sec + "s";
Calk.innerHTML = MessageHeure;
setTimeout("Hour()", 1000);
}
</SCRIPT> <!-- AFFICHER LA DATE//-->
<SCRIPT LANGUAGE="JavaScript">
Today = new Date;
Jour = Today.getDate();
Mois = (Today.getMonth())+1;
Annee = Today.getFullYear();
MessageDate = Jour + "/" + Mois + "/" + Annee;
</SCRIPT> 


<title>GESTOCK</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="header">
	
	<div id="menu">
		<ul>
			<li class="active"><a href="index.php" title="">Accueil</a></li>
			<li><a href="A propos.html" title="">A propos</a></li>
		
			
			
		</ul>
	</div>
</div>
<div id="content">
	<div id="sidebar">
		<div id="login" class="boxed">
			<div class="title">
				<h2>Authentification</h2>
			</div>
			<div class="content">
				<form id="form1" method="post" action="">
					
					<fieldset>
					<legend>conneter</legend>
					<label for="inputtext1">Login:</label>
					<input id="login2" type="text" name="login" value="" />
					<label for="inputtext2">Mot de passe:</label>
					<input id="pass" type="password" name="pass" value="" />
					<CENTER>

					  <input id="Submit" type="submit" name="Submit" value="Se connecter" />
					</CENTER>
					</fieldset>
					<p align="center" >
					
					</p>
				</form>
			</div>
		</div>
		<div id="updates" class="boxed">
			<div class="title">
				<h2>Calendrier</h2>
			</div>
			<div class="content">
			
		<div id="cal1Container" ></div>
	
			</div>
		</div>
		
	</div>
	
	<div id="main">
		<div id="welcome" class="post">
			<h2 class="title"><span>Bienvenus</span></h2>
			
			<div class="story"><img src="images/img09.png" alt="" width="120" height="120" class="left" />
				<br /><strong>GeStock</strong> est une application web qui sert a g&eacute;rer le stock 
				Cette application permet notament de g&eacute;rer les articles, familles, fournisseurs, le rangement  et 
				de saisir les entr&eacute;es, les sorties, et les bons. elle permet aussi de visualiser le contenu de stock avec les les diff&eacute;rents types de consultation disponibles .
			</div>
			
		</div><br><br><br> 
		
		<div id="example" class="post">
			<h2 class="title"><span>Examples des documents fournis par l'application</span></h2>
			
			<div class="story">
				<p>l'application Gestock  permet d'&eacute;tablire les diff&eacute;rents documents :</p>
				<blockquote>
					<p>&ldquo;Soit au magaziner soit aux services demmandeurs.&rdquo;</p>
				</blockquote>
				<h3>les documents sont:</h3>
			
				<ol>
					<li>Bon de commande interne </li>
					<li>Bon d'entree </li>					
					<li>Bon de sortie</li>
					<li>La fiche du stock</li>
				</ol>
			</div>
			
		</div>
	
	</div>

	<div id="sidebar2">
		<div id="sponsors" class="boxed">
			<div class="title">
				<h2>Date et Heur</h2>
			</div>
			<h3><center>
			<b><u>La date:</u></b><script LANGUAGE="JavaScript">
document.write(MessageDate);
</script><br><BR>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="125" height="125" id="FL" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="clock.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" />	<embed src="clock.swf" quality="high" bgcolor="#ffffff" width="125" height="125" name="Sans nom-1" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>

</center></h3>
		
		</div>
		<BR><BR><BR><BR>
		<div id="ad120x600"><a href="index.html">
		
		
		<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="170" height="300" id="FL" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="FL.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" />	<embed src="FL.swf" quality="high" bgcolor="#ffffff" width="170" height="300" name="Sans nom-1" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object></a></div>
	</div>
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end http://WorknBiz.cOmsidebar2 -->
<!-- end http://WorknBiz.cOmcontent -->
<div id="footer">
	<p id="legal">Copyright &copy; 2010 .</p>
	
</div>
</body>
</html>
	