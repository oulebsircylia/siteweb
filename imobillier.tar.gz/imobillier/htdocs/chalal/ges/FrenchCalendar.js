// French Calendar

YAHOO.namespace("ap.calendar");
	
YAHOO.ap.calendar.FrenchCalendarSet = function (cal) { 
		
	cal.cfg.setProperty("LOCALE_WEEKDAYS", "short");
	cal.cfg.setProperty("START_WEEKDAY", 1);
	cal.cfg.setProperty("MULTI_SELECT", false);
	
	cal.cfg.setProperty("DATE_FIELD_DELIMITER", "/");
	cal.cfg.setProperty("MDY_DAY_POSITION", 1);
	cal.cfg.setProperty("MDY_MONTH_POSITION", 2);
	cal.cfg.setProperty("MDY_YEAR_POSITION", 3);
	cal.cfg.setProperty("MD_DAY_POSITION", 1);
	cal.cfg.setProperty("MD_MONTH_POSITION", 2);
						
	// Date labels for French locale
	cal.cfg.setProperty("MONTHS_SHORT",   ["Janv", "Févr", "Mars", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"]);
	cal.cfg.setProperty("MONTHS_LONG",    ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]);
	cal.cfg.setProperty("WEEKDAYS_1CHAR", ["D", "L", "M", "M", "J", "V", "S"]);
	cal.cfg.setProperty("WEEKDAYS_SHORT", ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"]);
	cal.cfg.setProperty("WEEKDAYS_MEDIUM",["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"]);
	cal.cfg.setProperty("WEEKDAYS_LONG",  ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"]);
};