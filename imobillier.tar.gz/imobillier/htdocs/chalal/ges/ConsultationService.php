
<?php require_once('connexion.php'); ?>
<?php


session_start(); 
$affich=0;
?>
<?php
$reqd = "SELECT nom_ser  FROM serv_demandeur" ;
$resuld= mysql_query($reqd);
//____la requette d'affichge




if(isset($_POST['chercher'])){ 
$affich=1;

$jd = $_POST['jour_d'];
$md = $_POST['mois_d'];
$ad = $_POST['ann_d'];
$jf = $_POST['jour_f'];
$mf = $_POST['mois_f'];
$af = $_POST['ann_f'];
$dm = $_POST['demnd'];


$affiche=sprintf("SELECT l.num_bso,a.design_art,i.nom_ser,l.ds_art,l.qtt_serv,l.obs,b.date_bs,a.desgn_fam FROM article AS a,ligne_bs AS l,b_sortie AS b,bon_c_i AS i WHERE (b.num_bs=l.num_bso) AND (b.num_bs=i.num_b_c_i) AND (a.design_art=l.ds_art ) AND (i.nom_ser='".$_POST['demnd']."') AND b.date_bs BETWEEN '$ad-$md-$jd' AND '$af-$mf-$jf'");
$resaf = mysql_query($affiche, $dbprotect) or die(mysql_error());


}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Consultation</title>
<style type="text/css">
<!--
#entete {
	background-image: url(images/consultation/consultation.jpg);
	height: 140px;
	width: 960px;
}
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 955px;
	vertical-align: middle;
	padding-left: 5px;
	font-weight: bold;
	color: #FFF;
	font-style: normal;
	font-family: calibri;
	text-align: left;
}
#CONTNN #Stau ul {
	margin: 0px;
	list-style-type: none;
	padding: 2px;
	display: inline;
}
#CONTNN #Stau ul li {
	vertical-align: middle;
	display: inline;
	text-align: left;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: auto;
	width: 960px;
	background-repeat: repeat-y;
	margin: 0px;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
}
#CONTNN {
	width: 976px;
	margin-right: auto;
	margin-left: auto;
}
#MENU {
	background-image: url(images/img06.gif);
	background-repeat: repeat-x;
	height: 44px;
	width: 960px;
	text-align: center;
}
#CONTNN #MENU table tr {
	text-align: center;
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	padding-left: 225px;
}
#CONTNN #Stau table tr th {
	text-align: left;
	color: #FFF;
	font-size: 16px;
}
#CONTNN #Stau table tr th a {
	color: #FFF;
	text-decoration: none;
	font-size: 14px;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
#CONTNN #CORP center table tr td {
	font-family: Calibri;
}
.tt {
	font-family: Calibri;
}
#CONTNN #CORP center form {
	font-family: calibri;
}
#CONTNN #CORP center h2 strong {
	font-family: calibri;
}
#CONTNN #CORP center p {
	font-family: calibri;
}
#CONTNN #Stau table tr th a strong {
	font-family: calibri;
	font-size: 16px;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('images/B32 .jpg','images/B3i2.jpg','images/B3c2.jpg','images/IMG/gtk-refresh.png','images/gs1.jpg')">
<div id="CONTNN">
  <div id="entete"></div>
  <div id="Stau">
    <table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="54" height="34" scope="col"><img src="images/MSN Messenger.png" width="28" height="28" /></th>
        <th width="771" scope="col">Bienvenue .:: <span><?php echo $_SESSION['prenom']; ?><span> </span><?php echo $_SESSION['nom']; ?> ::. </span></th>
        <th width="125" scope="col"><a href="index.php?erreur=logout"><strong>Se Déconnecter</strong></a></th>
      </tr>
    </table>
  </div>
  <div id="MENU">
    <table width="677" height="44" border="0" align="center" cellspacing="0">
      <tr>
         <?php if($_SESSION['privilege'] == "admin") { ?><th width="170" height="40" scope="col"><a href="Gestion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','images/B32 .jpg',1)"><img src="images/B31 .jpg" name="Image2" width="170" height="40" border="0" id="Image2" /></a></th><?php }?>
        <th width="170" scope="col"><a href="imprission.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','images/B3i2.jpg',1)"><img src="images/B3i1.jpg" name="Image3" width="170" height="40" border="0" id="Image3" /></a></th>
        <th width="170" scope="col"><a href="Consultation.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','images/B3c2.jpg',1)"><img src="images/Consultation .jpg" name="Image4" width="170" height="40" border="0" id="Image4" /></a></th>
         <?php if($_SESSION['privilege'] == "admin") { ?><th width="159" scope="col"><a href="admin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','images/gs1.jpg',1)"><img src="images/gs.jpg" name="Image5" width="170" height="40" border="0" id="Image5" /></a></th><?php }?>
      </tr>
    </table>
  </div>
  <div id="CORP">
  <br /><center>
   <h2><strong>Cosultation par service demandeur</strong></h2>
 <b><b><b> 
 <p>Selectioner le demandeur
 <form action="" method="post">
   <select name="demnd" id="demnd">
     <?php
			  while($serv_demandeur=mysql_fetch_array($resuld)){ ?>
     <option value="<?php echo $serv_demandeur['nom_ser']; ?>"> <?php  echo $serv_demandeur['nom_ser']; ?> 
       </option>
     
     <?php        }    ?>
     
   </select>
   <br /><br />
   <b><b>
   <br /> date de debut
   
   
   
   <b><b>
   <select  name="jour_d" autocomplete="off">
     <option value="-1">Jour:</option>
     <option value="01">01</option> 
     <option value="02">02</option>
     <option value="03">03</option>
     <option value="04">04</option>
     <option value="05">05</option>
     <option value="06">06</option>
     <option value="07">07</option>
     <option value="08">08</option>
     <option value="09">09</option>
     <option value="10">10</option>
     <option value="11">11</option>
     <option value="12">12</option>
     <option value="13">13</option>
     <option value="14">14</option>
     <option value="15">15</option>
     <option value="16">16</option>
     <option value="17">17</option>
     <option value="18">18</option>
     <option value="19">19</option>
     <option value="20">20</option>
     <option value="21">21</option>
     <option value="22">22</option>
     <option value="23">23</option>
     <option value="24">24</option>
     <option value="25">25</option>
     <option value="26">26</option>
     <option value="27">27</option>
     <option value="28">28</option>
     <option value="29">29</option>
     <option value="30">30</option>
     <option value="31">31</option>
     
   </select>
   <select name="mois_d"autocomplete="off">
     <option value="-1">Mois:</option>
     <option value="01">01</option> 
     <option value="02">02</option>
     <option value="03">03</option>
     <option value="04">04</option>
     <option value="05">05</option>
     <option value="06">06</option>
     <option value="07">07</option>
     <option value="08">08</option>
     <option value="09">09</option>
     <option value="10">10</option>
     <option value="11">11</option>
     <option value="12">12</option>
   </select>
   <select  name="ann_d" autocomplete="off">
     <option value="-1">Année:</option>
     <option value="2010">2010</option> 
     <option value="2011">2011</option>
     <option value="2012">2012</option>
     <option value="2013">2013</option>
     <option value="2014">2014</option>
     <option value="2015">2015</option>
     <option value="2016">2016</option>
     <option value="2017">2017</option>
     <option value="2018">2018</option>
     <option value="2019">2019</option>
     <option value="2020">2020</option>
     <option value="2021">2021</option>
   </select>
   
   <b><b> <b>date fin  
   
   
   
   
   <b><b>
   <select  name="jour_f" autocomplete="off">
     <option value="-1">Jour:</option>
     <option value="01">01</option> 
     <option value="02">02</option>
     <option value="03">03</option>
     <option value="04">04</option>
     <option value="05">05</option>
     <option value="06">06</option>
     <option value="07">07</option>
     <option value="08">08</option>
     <option value="09">09</option>
     <option value="10">10</option>
     <option value="11">11</option>
     <option value="12">12</option>
     <option value="13">13</option>
     <option value="14">14</option>
     <option value="15">15</option>
     <option value="16">16</option>
     <option value="17">17</option>
     <option value="18">18</option>
     <option value="19">19</option>
     <option value="20">20</option>
     <option value="21">21</option>
     <option value="22">22</option>
     <option value="23">23</option>
     <option value="24">24</option>
     <option value="25">25</option>
     <option value="26">26</option>
     <option value="27">27</option>
     <option value="28">28</option>
     <option value="29">29</option>
     <option value="30">30</option>
     <option value="31">31</option>
     
   </select>
   <select name="mois_f"autocomplete="off">
     <option value="-1">Mois:</option>
     <option value="01">01</option> 
     <option value="02">02</option>
     <option value="03">03</option>
     <option value="04">04</option>
     <option value="05">05</option>
     <option value="06">06</option>
     <option value="07">07</option>
     <option value="08">08</option>
     <option value="09">09</option>
     <option value="10">10</option>
     <option value="11">11</option>
     <option value="12">12</option>
   </select>
   <select  name="ann_f" autocomplete="off">
     <option value="-1">Année:</option>
     <option value="2010">2010</option> 
     <option value="2011">2011</option>
     <option value="2012">2012</option>
     <option value="2013">2013</option>
     <option value="2014">2014</option>
     <option value="2015">2015</option>
     <option value="2016">2016</option>
     <option value="2017">2017</option>
     <option value="2018">2018</option>
     <option value="2019">2019</option>
     <option value="2020">2020</option>
     <option value="2021">2021</option>
   </select>
 </p>
<br /><br />
  <input  name="chercher" type="submit" class="tt" id="chercher" value="                                            Chercher                                        "  />

 
 </p>
 <br /> <br />
    <?php if($affich==1) { ?>
<table width="929" border="1" cellspacing="0" cellpadding="5" bgcolor="#EEFFFF">
  <tr  align="center"  bgcolor="#BEDEEB">
                <td width="101">N° Bn de sortie</td>
                <td width="129">Designation</td>
                <td width="99">Nom service</td>
                <td width="64">Qtt servie</td>
                <td width="119">Observation</td>
                <td width="114">Date bn de sortie</td>
			    <td width="217">Designation famille</td>
          </tr>

			  <?php while($articles=mysql_fetch_array($resaf))  { ?>
  <tr>

    <td><?php echo $articles['num_bso']; ?></td>
    <td><?php echo $articles['design_art']; ?></td>
	<td align="right"><?php echo $articles['nom_ser']; ?></td>
	<td align="right"><?php echo $articles['qtt_serv']; ?></td>
	<td><?php echo $articles['obs']; ?></td>
	<td><?php echo $articles['date_bs']; ?></td>
	<td align="right"><?php echo $articles['desgn_fam']; ?></td>

  </tr>
  <?php } ?>
        </table>
      <?php } ?>  
<BR>
   </form>
  </CENTER>
   
	  
  </div>
  <div id="PIED"></div>
</div>
</body>
</html>

