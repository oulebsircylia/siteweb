
<?php
//connection au serveur
  $cnx = mysql_connect( "localhost", "root", "mimia" );
  //s�lection de la base de donn�es:
 

  $db  = mysql_select_db("memoire");
  if(isset($_POST['valider'])){
  if(isset($_POST['t'],$_POST['description'], $_POST["lieu"],$_POST["superficie"],$_POST["t"],$_POST["bi"])){
    $type = $_POST['t'];
    $description = $_POST['description'];
  	$lieu = $_POST["lieu"];
 	$prix = $_POST["prix"] ;
	$type_transaction =$_POST["bi"];
  	$superficie = $_POST["superficie"] ;
  	//$accord = $_POST["accord"] ;
 
	  //cr�ation de la requ�te SQL:
	  $sql = "INSERT  INTO bien (type_bien, description, lieu, prix, superficie, accord) VALUES ('$type','$description', '$lieu', '$prix', '$superficie' ,0)" ;
	//ex�cution de la requ�te SQL:
	 $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
	
	$sql = mysql_query("SELECT id_bien FROM bien ORDER BY id_bien DESC LIMIT 1");
	$row = mysql_fetch_assoc($sql);
	$id_bien = $row["id_bien"];
		
	
	$sql2 = "INSERT  INTO transaction (id_bien, type_transaction) VALUES ($id_bien, '$type_transaction')" ;
	//ex�cution de la requ�te SQL:
	 $requete = mysql_query($sql2, $cnx) or die( mysql_error()) ;
	
		
	if($_POST['t']=='appartement'){
	if(isset($_POST['t_a'],$_POST['n_�'])){
		$type_appar = $_POST['t_a'];
		$num_etage = $_POST['n_�'];
		$image1 = $_FILES['image1']['name'];
		$image2 = $_FILES['image2']['name'];
		$image3 = $_FILES['image3']['name'];
		$image4 = $_FILES['image4']['name'];
		
		$sql = "INSERT INTO appartement (id_bien, type_appar, num_etage, image1 , image2 , image3 , image4) VALUES ('$id_bien', '$type_appar', '$num_etage' ,'$image1','$image2','$image3','$image4')";
		//ex�cution de la requ�te SQL:
		$requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		 
		  
		  }
		  }
		  if($_POST['t']=='villa'){
		  if(isset($_POST['p'],$_POST['n_e'])){
		 
		$nbr_piece = $_POST['p'];
		$nbr_etage = $_POST['n_e'];
		$image1 = $_FILES['image1']['name'];
		$image2 = $_FILES['image2']['name'];
		$image3 = $_FILES['image3']['name'];
		$image4 = $_FILES['image4']['name'];
		
		$sql = "INSERT INTO villa (id_bien, nbr_piece, nbr_etage, image1 , image2 , image3 , image4) VALUES ('$id_bien', $nbr_piece, '$nbr_etage','$image1','$image2','$image3','$image4')";
		//ex�cution de la requ�te SQL:
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		 }}
		  if($_POST['t']=='terrain'){
		  if(isset($_POST['n_f'],$_POST['ca'])){
		   echo"mmmmm";
		$nbr_fa�ade = $_POST['n_f'];
		$categorie = $_POST['ca'];
		$sql = "INSERT INTO terrain (id_bien, nbr_fa�ade, categorie) VALUES ('$id_bien', '$nbr_fa�ade', '$categorie')";
		//ex�cution de la requ�te SQL:
		
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		 
		  
  }}
 if($_POST['t']=='entrepot'){
 if(isset($_POST['h'],$_POST['la'],$_POST['lo'])){
		$hauteur = $_POST['h'];
		$largeur = $_POST['la'];
		$longeur = $_POST['lo'];
		$sql = "INSERT INTO entrepot (id_bien, hauteur, largeur, longueur) VALUES ('$id_bien', '$hauteur', '$largeur', '$longeur')";
		//ex�cution de la requ�te SQL:
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		 
	}}}else{ echo "viellez remplire tous les champs";}
	} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" ><head>
 <link rel="stylesheet"  href="calendrier/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="calendrier/calendar.js"></script>
<script type="text/javascript" src="calendrier/FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="file:index.css" />
<link rel="stylesheet" href="file:index3.css" />
<title>Document sans titre</title>
 <script src="../images/gen_validatorv4.js"></script>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('t').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('t_a').style.display= 'inline';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'inline';
	    document.getElementById('n_e').style.display= 'inline';
         document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		  document.getElementById('ca').style.display= 'none';
		  document.getElementById('n_f').style.display= 'none';
		  document.getElementById('n_�').style.display= 'none';
        } 
		  if (a == "terrain"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'inline';
			document.getElementById('n_f').style.display= 'inline';
			document.getElementById('n_�').style.display= 'none';
        } 
	if (a == "entrepot"){ 
		document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'inline';
		  document.getElementById('lo').style.display= 'inline';
		   document.getElementById('la').style.display= 'inline';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'none';
        } 
	
	
		
		   }
</script>
<style>
body {
	background-color: #FFFFFF;
	background-image:url(images/bg.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:750px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:750px;
	border-left: 1px solid black;
	}	
.Style3 {font-size: 16}
.Style4 {
	color: #000000;
	font-size: xx-large;
}
</style>

</head>
<body>
<div id="conteneur">
	<div id="header">
		
			<div id="slogon" align="center"><img src="images/slogan.jpg" width="150" height="153" /><img src="images/naima3.jpg" width="960" height="150" /></div>
			<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onMouseMove="this.stop();" onMouseOut="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
			</div>
			
		
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
	<li><a href="apropos.php"> A propos</a>
		
	</li>
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
  <div id="corps">
		
		<div id="droite">
		<p>&nbsp;</P>
		
		<p><div id="updates" class="boxed">
			<div class="title">
			<div id="sidebar">
			<div id="div2" class="boxed">
			<div class="title">
				<h2>Calendrier</h2>
			</div>
			<div class="content">
			<div id="div3"></div>
			</div>
			</div>
			</div>
			</div>
			<div class="content">
		<div id="cal1Container" ></div>
	
			</div>
		</div></P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</p>
		
		</P>
		<p>&nbsp;</P>
		<P><img src="images/fnai.jpg" width="180" height="116" /></P>
		<P>&nbsp;</P>
		</div>
		<div id="gauche"></div>
						
    <p align="center" class="Style4">proposer un bien </p>
      <form method="POST"  name="bien" action="" enctype="multipart/form-data">
	  <center><fieldset style="border:solid 1px black;padding:40px;width:90px;color:#000000;" >
	  <centre>
						   <table align="center" border="0">
							<tr>
									<td>
							  <label for="lieu" class="Style40"> </label></td>
									<td>
										
					                  <div align="justify">
					                    <input type="hidden" name="id_bien" />	
				                        </div></td>
							  </tr>
								<tr>
									<td width="143">
									
								  <label for="bien">
								  <div align="justify"><span class="Style40">Bien:    </span></div>
								  </label>									</td>
    							  <td width="681">
								    
						                <div align="justify">
								                <select id="t" name="t" onchange="Changer()">
								                  <option value="vide"></option>
								                  <option value="appartement">Appartement</option>
								                  <option value="villa">Villa</option>
								                  <option value="terrain">Terrain</option>
								                  <option value="entrepot">Entrepot</option>
						                  </select>
						                  <select name="t_a" id="t_a" style="display:none">
						                    <option value="vide">Type</option>
						                    <option value="F1">F1</option>
						                    <option value="F2">F2</option>
						                    <option value="F3">F3</option>
						                    <option value="F4">F4</option>
						                    <option value="F5">F5</option>
						                    <option value="F5">F5+</option>
					                      </select>
						                  <select name="n_e" id="n_e" style="display:none">
						                    <option value="vide">Nombre d'�tage</option>
						                    <option value="1_�tage">1 �tage</option>
						                    <option value="2_�tages">2 �tages</option>
						                    <option value="3_�tages">3 �tages</option>
						                    <option value="4_�tages">4 �tages</option>
						                    <option value="5_�tages">5 �tage</option>
						                    <option value="+_de_5">+ de5 �tages </option>
					                      </select>
					                      <input name="p" type="text" value="" id="p" placeholder="nombre de piece" style="display:none"/>
					                      <input name="h" type="text" value="" id="h" placeholder="saisir la hauteur" style="display:none"/>
					                      <input name="lo" type="text" value="" id="lo" placeholder="saisir la longueur" style="display:none"/>
					                      <input name="la" type="text" value="" id="la" placeholder="saisir la largeur" style="display:none"/>
					                      <input name="n_f" type="text" value="" id="n_f" placeholder="saisir le nombre de fa�ade" style="display:none"/>
					                      <input name="n_�" type="text" value="" id="n_�" placeholder="saisir le numero d'�tage" style="display:none"/>
						                  <select name="ca" id="ca" style="display:none">
						                    <option value="vide">cat�gorie</option>
						                    <option value="Terrain urbanisable">Terrain urbanisable</option>
						                    <option value="Terrain agricol">Terrain agricol</option>
						                    <option value="Terrain industr">Terrain industriel</option>
					                        </select>
			                            </div></td>
								</tr>
								<tr>
									<td>
										<label for="cat�gorie" class="Style40">
										<div align="justify">Type transaction: </div>
										</label>	</td>
									<td>
										
								          <div align="justify">
										            <select name="bi" id="bi" placeholder="Type de bien">
										              <option value="vide"></option> 
										              <option value="achat">Achat</option>
										              <option value="location">Location</option>
										              <option value="location">Echange</option>
							                </select>
					                    </div></td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">
										<div align="justify">description: </div>
								  </label></td>
									<td>
										
								          <div align="justify">
										            <textarea name="description" id="description"></textarea>
					                    </div></td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">
										<div align="justify">Lieu: </div>
								  </label></td>
									<td>
										
					                  <div align="justify">
					                    <input type="text" name="lieu" id="Lieu" />	
				                        </div></td>
								</tr>
								<tr>
									<td>
										<label for="superficie" class="Style40">
										<div align="justify">Superficie: </div>
										</label>	</td>
								  <td>
										
				                    <div align="justify">
				                      <input type="number" name="superficie" id="Superficie" />
				                      <span class="Style40">m�</span> </div></td>
								</tr>
								<tr>
									<td>
										<label for="prix" class="Style40">
										<div align="justify">Prix: </div>
										</label>									</td>
								  <td>
										
				                    <div align="justify">
				                      <input type="number" name="prix" id="prix" />
				                      <span class="Style40">DA</span> </div></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">
										<div align="justify">Ajouter image 1: </div>
										</label>									    </td>
									<td><label>
									  
				                    <div align="justify">
				                      <input type="file" name="image1" />
			                          </div>
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">
										<div align="justify">Ajouter image 2: </div>
										</label>									    </td>
									<td><label>
									  
				                    <div align="justify">
				                      <input type="file" name="image2" />
			                          </div>
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">
										<div align="justify">Ajouter image 3: </div>
										</label>									    </td>
									<td><label>
									  
				                    <div align="justify">
				                      <input type="file" name="image3" />
			                          </div>
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">
										<div align="justify">Ajouter image 4: </div>
										</label>									    </td>
									<td><label>
									  
				                    <div align="justify">
				                      <input type="file" name="image4" />
			                          </div>
									</label></td>
								</tr>
								
								<tr>
									<td>									<div align="justify"></div></td>
									<td>
										
					                  <div align="justify">
					                    <input type="submit" value="Valider" name="valider"/>									
				                        </div></td>
								</tr>
		 </table>
	                      </centre>  
                          </fieldset></center>  
    </form>
        <p>&nbsp;</p>
	    <p>&nbsp;</p>
	    <p>&nbsp;</p>
	    <p>&nbsp;</p>
	    <p>&nbsp;</p>
  </div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#cccccc" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#cccccc" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9"> 05-51-57-24-99</p>
    <p align="center" class="Style9">E-mail: chalal.immobilier@hotmail.fr</p>
    </th>
    <th width="418" align="center" valign="top" bgcolor="#cccccc" scope="col"><p align="center" class="Style9"><span class="Style1"><span class="Style2"><span class="Style3"><a href="index.php">acceuil</a></span></span></span></p>
      <p align="center" class="Style9 Style3"><a href="recherche1.php">recherche</a></p>
      <p align="center" class="Style9 Style3"><a href="proposer1.php">proposer</a></p>
      <p align="center" class="Style9 Style3"><a href="inscription3.php">inscreption</a></p>
      <p align="center" class="Style9 Style1"><span class="Style3"><span class="Style2"><a href="mondat.php">mondat</a></span></span></p>
      <p align="center" class="Style9 Style2"><a href="contact.php">contactez-nous</a></p>
      <p align="center" class="Style9"><span class="Style2"><a href="apropos.php">A propos</a></span> </p></th>
  </tr>
</table>
  </div>
	
</div>
</body>
</html>
