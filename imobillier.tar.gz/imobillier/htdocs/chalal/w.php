 <?php

require_once('config.php' );

  if(isset($_POST['submit'])){
 
 
  if(isset($_POST['t']))	$t=  $_POST['t'];  else $t="";
    if(isset($_POST['lieu']))	$lieu=  $_POST['lieu'];else $lieu="";
	 if($_POST['prix_min']!=''){	$prixinf=  $_POST['prix_min'];
	 echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
	 }else $prixinf="0";
	if(isset($_POST['prix_max']) && $_POST['prix_min']!='')	$prixsup=  $_POST['prix_max'];else $prixsup="9999999999"; 
  if(isset($_POST['bi']))	$type_transaction=  $_POST['bi'];else $type_transaction="";
	
 	
	if($_POST['t']=="appartement"){
		
		$sql = "SELECT DISTINCT * FROM appartement, bien,  transaction  WHERE ( type_bien='appartement'  AND accord='1' AND( (prix > '$prixinf' and prix < '$prixsup' ) OR lieu='$lieu' OR type_transaction='$type_transaction' )) ";
		//ex�cution de la requ�te SQL:
	
	
			$conn =config::connectDB();
		$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table: ");
		
		  
		  
		  }
		  if($_POST['t']=='villa'){
		
		$sql = "SELECT *  FROM villa, bien,  transaction  WHERE ( type_bien='villa'  AND accord='1' AND( prix= '$prix' OR lieu='$lieu' OR type_transaction='$type_transaction' ))"; 
		//ex�cution de la requ�te SQL:
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		 }
		  if($_POST['t']=='terrain'){
		  
		$sql = "SELECT *  FROM terrain, bien,  transaction  WHERE ( type_bien='terrain'  AND accord='1' AND( prix= '$prix' OR lieu='$lieu' OR type_transaction='$type_transaction' )) ";
		//ex�cution de la requ�te SQL:
		echo $sql;
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		  
  }
 if($_POST['t']=='entrepot'){
 
		$sql = "SELECT *  FROM entrepot, bien,  transaction  WHERE ( type_bien='entrepot'  AND accord='1' AND( prix= '$prix' OR lieu='$lieu' OR type_transaction='$type_transaction' )) ";
		//ex�cution de la requ�te SQL:
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		 
	}
	}
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>

<style>
body {
	background-color: #FFFFFF;
	background-image:url();
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;

max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
.Style1 {
	font-size: 24px;
	font-weight: bold;
}
</style>
</head>

<body>
<div id="conteneur">
	<div id="header">
		<div id="slogon" align="center">
				<img src="images/slogan.jpg" width="160" height="150" />
				<img src="images/naima3.jpg" width="960" height="150" />
		</div>
		<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
		</div>
			
		
			<ul id="menu" >
	<li><a href="index2.php">Acceuil</a>
		
	</li>
	<li><a href="recherche2.php">Recherche</a>
		
	</li>
	<li><a href="proposer2.php">Proposer</a>
		
	</li>
	<li><a href="inscription.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
			<li><a href="apropos.php"> A propos</a>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
	<div id="corps">
		
		<div id="droite">
		</div>
		<div id="gauche">
		
		</div>
		<div id="milieu" align="center">
		  <p class="Style1">chercher un bien:		  </p>
		  <p class="Style1">&nbsp;</p>
		  <center>
						<form method="POST"  name="bien" action="w.php">
						  <table align="center" border="0">
                            <tr>
                              <td width="143"><input type="hidden" name="id_bien" />
                                  <label for="bien"><span class="Style40">Bien: </span></label>
                              </td>
                              <td width="681"><select id="t" name="t" >
                                  <option value="vide"></option>
                                  <option value="appartement">Appartement</option>
                                  <option value="villa">Villa</option>
                                  <option value="terrain">Terrain</option>
                                  <option value="entrepot">Entrepot</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td><label for="cat&eacute;gorie" class="Style40">Type transaction: </label>
                              </td>
                              <td><select name="type" id="type" placeholder="Type de bien">
                                  <option value="vide"></option>
                                  <option value="achat">Achat</option>
                                  <option value="location">Location</option>
                                  <option value="location">Echange</option>
                                </select>
                              </td>
                            </tr>
                            <tr>
                              <td><label for="lieu" class="Style40">Lieu: </label></td>
                              <td><input type="text" name="lieu" id="lieu" />
                              </td>
                            </tr>
                            <tr>
                              <td><label for="prix" class="Style40">Prix (DA): </label>
                              </td>
                              <td><input type="text" name="prix_min" id="pri_min" placeholder="prix min"/>
                                  <input type="text" name="prix_max" id="pri_max" placeholder="prix max"/>
                              </td>
                            </tr>
                            <tr>
                              <td></td>
                              <td><input name="submit" type="submit" value="valider"/>
                              </td>
                            </tr>
                          </table>
            </form>
	 
	  
	  
	 
	 
	    <table width="522" border="1">
		<?php if(!empty($oRow)){ ?>
		 <tr><td>photo</td><td>information</td> </tr>
  <?php  while($rows = mysqli_fetch_array($oRow)){?>
  <tr>
    <td width="300" height="304"><img src="./images/<?php echo $rows['image1'] ;?>"  name="image" width="300px"/></td>
    <td width="206"><?php echo $rows['type_bien']."<br>".$rows['prix']."<br>".$rows['superficie']  ;?><a href="voir.php?id=<?php echo $rows['id_bien'] ;?>"> view </a></td>
  </tr>
  <?php }}?>
</table>
	  </center>
      </div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9">05-51-57-24-99</p>    </th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">E-mail:</p>
    <p align="center" class="Style9">chalal.immobilier@hotmail.fr</p></th>
  </tr>
</table>
	</div>
</div>
</body>
</html>