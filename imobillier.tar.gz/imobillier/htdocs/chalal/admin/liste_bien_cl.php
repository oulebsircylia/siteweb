<?php require_once('../Connections/conn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

if ((isset($_GET['id_bien'])) && ($_GET['id_bien'] != "")) {
  $deleteSQL = sprintf("DELETE FROM bien WHERE id_bien=%s",
                       GetSQLValueString($_GET['id_bien'], "int"));

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($deleteSQL, $conn) or die(mysql_error());

  $deleteGoTo = "liste_bien_cl.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_bien = "-1";
if (isset($_GET['accord'])) {
  $colname_bien = (get_magic_quotes_gpc()) ? $_GET['accord'] : addslashes($_GET['accord']);
}
mysql_select_db($database_conn, $conn);
$query_bien = sprintf("SELECT * FROM bien WHERE accord = 0", $colname_bien);
$bien = mysql_query($query_bien, $conn) or die(mysql_error());
$row_bien = mysql_fetch_assoc($bien);
$totalRows_bien = mysql_num_rows($bien);

$colname_bien_sup = "-1";
if (isset($_GET['id_bien'])) {
  $colname_bien_sup = (get_magic_quotes_gpc()) ? $_GET['id_bien'] : addslashes($_GET['id_bien']);
}
mysql_select_db($database_conn, $conn);
$query_bien_sup = sprintf("SELECT * FROM bien WHERE id_bien = %s", $colname_bien_sup);
$bien_sup = mysql_query($query_bien_sup, $conn) or die(mysql_error());
$row_bien_sup = mysql_fetch_assoc($bien_sup);
$totalRows_bien_sup = mysql_num_rows($bien_sup);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<SCRIPT LANGUAGE="JavaScript">
function confirmation(id_bien) {
var msg = "Etes-vous sur de vouloir supprimer ce enregistrement ?";
if (confirm(msg)){
window.location.href="liste_bien_cl.php?id_bien="+id_bien;
}else{
return false;
}
}
</SCRIPT>
<style>

#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}

#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}


#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:550px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:550px;
	border-left: 1px solid black;
	}	

	
.Style1 {color: #000000}
</style>

<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
.Style46 {font-size: 14px}
.Style47 {color: #FFFFFF; font-size: 14px; }
.Style48 {color: #000000; font-size: 14px; }
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><img src="../images/Capture.JPG" width="189" height="151" /></th>
    <th width="987" scope="col"><div align="center"><img src="../images/naima3.jpg" width="960" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>







<ul id="menu" >
	<li><a href="../index.php">Acceuil</a>
		
	</li>
	<li><a href="../recherche1.php">Recherche</a>
		
	</li>
	<li><a href="../proposer1.php">Proposer</a>
		
	</li>
	<li><a href="../inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="../mondat.php">Mondat</a>
		
	</li>	
		
		</li>
	<li><a href="../apropos.php">A propos</a>
		
	</li>
		
		
		
		<li><a href="../contact.php">Contactez-nous</a>
		
	</li>
	
	</ul>
<p><span class="Style48">
<table width="1211" height="611" border="0">
  <tr>
    <th width="256" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
<ul id ="menu-accordeon">
<li><a href ="#">Gestion des client </a>
  <ul>
<li> <a href="ajouter client.php"> Ajouter</a></li>
<li><a href="modifie un client.php">Modifie</a> </li>
<li><a href="supprimer client.php">Supprimer</a> </li>
   </ul>
   </li>
   
   <li><a href ="#">Gestion des bien </a>
     <ul>
<li> <a href="ajouter_un_bien.php">Ajouter</a></li>
<li><a href="modifier_un_bien.php">Modifie</a></li>
<li><a href="supprimer_bien.php">Supprimer</a></li>
   </ul>
   </li>
   
    
  
   <li><a href="liste_bien_cl.php">Consulter les biens  </a>
     <ul>
   </ul>
   </li>
   </ul></th>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>

    <th width="939" align="center" valign="top" class="Style37" scope="col"><p class="Style38">La liste des biens des proposer par les clients </p>
      <table width="747" border="1" bordercolor="#000000">
        <tr>
		
		
          <th width="90" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">id bien </span></span></th>
          <th width="101" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">type bien</span></span></th>
          <th width="109" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">description</span></span></th>
          <th width="87" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">lieu</span></span></th>
          <th width="66" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">prix</span></span></th>
          <th width="102" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">superficie</span></span></th>
         
		    <th width="59" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">accepeter</span></span></th>
			<th width="59" scope="col"><span class="Style47 id_client Style46"><span class="Style38 id_client">supprimer</span></span></th>
        </tr>
         <span class="Style46"></span>
          <?php do { ?><tr>
            <td height="42"><span class="Style48"><?php echo $row_bien['id_bien']; ?></span></td>
            <td><span class="Style48"><?php echo $row_bien['type_bien']; ?></span></td>
            <td><span class="Style48"><?php echo $row_bien['description']; ?></span></td>
            <td><span class="Style48"><?php echo $row_bien['lieu']; ?></span></td>
            <td><span class="Style48"><?php echo $row_bien['prix']; ?></span></td>
            <td><span class="Style48"><?php echo $row_bien['superficie']; ?></span></td>
            
		<th width="59" scope="col"><a href="modifier_un_bien.php?id_bien=<?php echo $row_bien['id_bien']; ?>"><img src="../images/accepter-verifier-vert-ok-oui-icone-6380-128.png" width="41" height="29" /></a></th>
		<th width="59" scope="col"><a href=""#" onclick="confirmation(<?php echo $row_bien['id_bien']; ?>)""><img src="../images/Erase.png" /></a></th>
		</tr>
			
            <?php } while ($row_bien = mysql_fetch_assoc($bien)); ?>
      </table>
      <p>&nbsp;</p>
</table>

<table width="1218" height="138" border="0" align="center" bordercolor="#000000">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>




<?php
mysql_free_result($bien);

mysql_free_result($bien_sup);
?>
