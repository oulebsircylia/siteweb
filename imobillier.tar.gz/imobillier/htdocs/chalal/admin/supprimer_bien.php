<?php require_once('../Connections/conn.php'); ?>
<?php
mysql_select_db($database_conn, $conn);
$query_Recordset1 = "SELECT * FROM bien";
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
 
	mysql_connect("localhost", "root", "benamara") or die ("Erreur de connexion");
	mysql_select_db("agence_chaalal") or die ("Erreur de connexion � la base");
	$query = mysql_query("SELECT * FROM bien") or die ("Erreur de connexion � la table bien");
	
	
	if(isset($_GET['delete'])){

   $multiple = ($_GET['multiple']);
   
   $i = 0;
   
   $sql = "DELETE FROM bien";
		 foreach($multiple as $item_id){ $i ++;
	
  if($i == 1){
	  $sql .= " WHERE id_bien = " . mysql_real_escape_string($item_id) . "";
	    }else {
		  $sql .= " OR id_bien = " . mysql_real_escape_string($item_id) . "";
		}
	}
	mysql_query($sql) or die ("erreur");
	header("location: " . $_SERVER['PHP_SELF']);
	exit();
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<SCRIPT LANGUAGE="JavaScript">
function confirmation(id) {
var msg = "Etes-vous sur de vouloir supprimer ce enregistrement ?";
if (confirm(msg)){
window.location.href="supprimer client.php?id="+id;
}else{
return false;
}
}
</SCRIPT>
<style>

#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}

#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}


#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:550px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:550px;
	border-left: 1px solid black;
	}	

	
.Style1 {color: #000000}
</style>

<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
	height:70000;
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
.Style48 {color: #000000; font-size: 14px; }
#tableau{
	margin: 0 auto;
	/*width: 1000px;*/
	text-align: center;
}
td{
	padding: 12px;
	border: 1px solid black;
}
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#FFFFFF" scope="col"><div align="right"><img src="../images/Capture.JPG" width="192" height="151" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/naima3.jpg" width="960" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>




<ul id="menu" >
	<li><a href="../index.php">Acceuil</a>
		
	</li>
	<li><a href="../recherche1.php">Recherche</a>
		
	</li>
	<li><a href="../proposer1.php">Proposer</a>
		
	</li>
	<li><a href="../inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="../mondat.php">Mondat</a>
		
	</li>	
		
		</li>
	<li><a href="../apropos.php">A propos</a>
		
	</li>
		
		
		
		<li><a href="../contact.php">Contactez-nous</a>
		
	</li>
	
	</ul>


<p>&nbsp;</p>
<table width="1446" height="611" border="0">
  <tr>
    <th width="306" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
<ul id ="menu-accordeon">
<li><a href ="#">Gestion des client </a>
  <ul>
<li> <a href="ajouter client.php"> Ajouter</a></li>
<li><a href="modifie un client.php">Modifie</a> </li>
<li><a href="supprimer un client .php">Supprimer</a> </li>
   </ul>
   </li>
   
   <li><a href ="#">Gestion des bien </a>
     <ul>
<li> <a href="ajouter_un_bien.php">Ajouter</a></li>
<li><a href="modifie_un_bien.php">Modifie</a></li>
<li><a href="supprimer_bien.php">Supprimer</a></li>
   </ul>
   </li>
   
    
   <li><a href="modifier le mot de passe.php">Modifie login et mot de passe </a>   </li>
   
     
   <li><a href="consulter.php">Consulter les biens  </a>
     <ul>
   </ul>
   </li>
   </ul></th>
      </tr>
    </table>
    </th>
    <th width="1130" align="left" valign="top" class="Style37" scope="col"><p class="Style38"><center>
    </center></p>
      <table width="880" border="1" bordercolor="#000000">
         <div id="tableau">
		 	<?php if (mysql_num_rows($query) > 0): ?>
		 	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
				<table width="300">
					<thead>
						<tr>
							<td><span class="Style48">Identificateur</span></td>
							<td><span class="Style48">type_bien</span></td>
							<td><span class="Style48">description</span></td>
							<td><span class="Style48">lieu</span></td>
							<td><span class="Style48"> prix</span></td>
							<td><span class="Style48">superficie</span></td>
							<td><span class="Style48">accord</span></td>
							
							<td></td>
						</tr>
					</thead>
					<tbody>
					   <?php while ($row = mysql_fetch_assoc($query)){ ?>
						<tr>
							<td><span class="Style48"><?php echo $row['id_bien'] ?></span></td>
							<td><span class="Style48"><?php echo $row['type_bien'] ?></span></td>
							<td><span class="Style48"><?php echo $row['description'] ?></span></td>
							<td><span class="Style48"><?php echo $row['lieu'] ?></span></td>
							<td><span class="Style48"><?php echo $row['prix'] ?></span></td>
							<td><span class="Style48"><?php echo $row['superficie'] ?></span></td>
							<td><span class="Style48"><?php echo $row['accord'] ?></span></td>
							<td>
								<input type="checkbox" name="multiple[]" value="<?php echo $row['id_bien']; ?>"   onclick="confirmation(<?php echo $row_liste_personnes['id_bien']; ?>)"checked="checked"/> 
							</td>
						</tr>
						
						<?php } ?>
						
					</tbody>
				</table>
				<br />
				<br />
				<center><input type="reset" name="bouton" value="initialisation" />
				<input type="submit" name="delete" value="supprimer" /> 
				</center>				
			</form>
			 <?php else: ?>
			 <h2 class="Style38">Aucun enregistrement � supprimer</h2>
			 <?php endif; ?>
		 </div>
		
        
      </table>  
	  
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
</table>

<table width="1218" height="138" border="0" align="center" bordercolor="#000000">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>







</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
