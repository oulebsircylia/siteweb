<?php
//connection au serveur
  $cnx = mysql_connect( "localhost", "root", "benamara" );
  //s�lection de la base de donn�es:
   $db  = mysql_select_db("agence_chaalal");
   if(isset($_POST['t'],$_POST['description'], $_POST["lieu"],$_POST["superficie"],$_POST["t"],$_POST["bi"])){
   //r�cup�ration des valeurs des champs:
    $type = $_POST['t'];
    $description = $_POST['description'];
  	$lieu = $_POST["lieu"];
 	$prix = $_POST["prix"] ;
	$type_transaction =$_POST["bi"];
  	$superficie = $_POST["superficie"] ;
  	//$accord = $_POST["accord"] ;
 //r�cup�ration de l'identifiant de la personne:
  $id_bien = $_POST["id_bien"] ;
 
	  //cr�ation de la requ�te SQL:
	  $sql = "UPDATE bien SET  type_bien = '$type', description = '$description', lieu='$lieu', prix = '$prix', superficie = '$superficie' WHERE id_bien='$id_bien'" ;
	  echo $sql;
	//ex�cution de la requ�te SQL:
	 $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
	
	  if($requete){
		echo("La modification � �t� correctement effectu�e") ;
	  }else{
		echo("La modification � �chou�e") ;
	  }
$sql2 = "UPDATE transaction SET type_transaction = '$type_transaction'  id_bien=$id_bien" ;
echo $sql2;
	//ex�cution de la requ�te SQL:
	 $requete = mysql_query($sql2, $cnx) or die( mysql_error()) ;
	
		
	if($_POST['t']=='appartement'){
	if(isset($_POST['t_a'],$_POST['n_�'])){
		$type_appar = $_POST['t_a'];
		$num_etage = $_POST['n_�'];
		$image1 = $_FILES['image1']['name'];
		$image2 = $_FILES['image2']['name'];
		$image3 = $_FILES['image3']['name'];
		$image4 = $_FILES['image4']['name'];
		
$sql = "UPDATE appartement SET image1 = '$image1'  , image2 = '$image2' , image3 = '$image3', image4 ='$image4' ";
		//ex�cution de la requ�te SQL:
		$requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		  if($requete){
			echo("La modificationnt a bien �t� inseret") ;
		  }else{
			echo("erreur") ;
		  }
		  
		  }
		  }
		  if($_POST['t']=='villa'){
		  if(isset($_POST['p'],$_POST['n_e'])){
		 
		$nbr_piece = $_POST['p'];
		$nbr_etage = $_POST['n_e'];
		$image1 = $_FILES['image1']['name'];
		$image2 = $_FILES['image2']['name'];
		$image3 = $_FILES['image3']['name'];
		$image4 = $_FILES['image4']['name'];
		
		$sql ="UPDATE villa SET image1 = '$image1'  , image2 = '$image2' , image3 = '$image3', image4 ='$image4' ";
		//ex�cution de la requ�te SQL:
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		  if($requete){
			echo("La villa a bien �t�  modifie") ;
		  }else{
			echo("erreur") ;
		  }}}
		 /* if($_POST['t']=='terrain'){
		  if(isset($_POST['n_f'],$_POST['ca'])){
		   echo"mmmmm";
		$nbr_fa�ade = $_POST['n_f'];
		$categorie = $_POST['ca'];
		$sql = "INSERT INTO terrain (id_bien, nbr_fa�ade, categorie) VALUES ('$id_bien', '$nbr_fa�ade', '$categorie')";
		//ex�cution de la requ�te SQL:
		echo $sql;
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		  if($requete){
			echo("Le terrain a bien �t� modifie") ;
		  }else{
			echo("erreur") ;
		  }
		  
  }}
 if($_POST['t']=='entrepot'){
 if(isset($_POST['h'],$_POST['la'],$_POST['lo'])){
		$hauteur = $_POST['h'];
		$largeur = $_POST['la'];
		$longeur = $_POST['lo'];
		$sql = "INSERT INTO entrepot (id_bien, hauteur, largeur, longueur) VALUES ('$id_bien', '$hauteur', '$largeur', '$longeur')";
		//ex�cution de la requ�te SQL:
		  $requete = mysql_query($sql, $cnx) or die( mysql_error()) ;
		  if($requete){
			echo("L'entrepot a bien �t� modifie") ;
		  }else{
			echo("erreur") ;
		  }*/
	
	}
?>