<?php
session_start();
?>
<?php require_once('../Connections/conn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

if ((isset($_GET['id_bien'])) && ($_GET['id_bien'] != "")) {
  $deleteSQL = sprintf("DELETE FROM bien WHERE id_bien=%s",
                       GetSQLValueString($_GET['id_bien'], "int"));

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($deleteSQL, $conn) or die(mysql_error());
}
  ?>
							<script type="text/javascript">
								window.alert("le bien a �t� bien modifier ");
								window.location.replace("http://localhost/agence_immobiliere/admin/liste_bien_cl.php");
							</script>
							
							<?php

$colname_sup_bien = "-1";
if (isset($_GET['id_bien'])) {
  $colname_sup_bien = (get_magic_quotes_gpc()) ? $_GET['id_bien'] : addslashes($_GET['id_bien']);
}
mysql_select_db($database_conn, $conn);
$query_sup_bien = sprintf("SELECT * FROM bien WHERE id_bien = %s", $colname_sup_bien);
$sup_bien = mysql_query($query_sup_bien, $conn) or die(mysql_error());
$row_sup_bien = mysql_fetch_assoc($sup_bien);
$totalRows_sup_bien = mysql_num_rows($sup_bien);

mysql_free_result($sup_bien);
?>