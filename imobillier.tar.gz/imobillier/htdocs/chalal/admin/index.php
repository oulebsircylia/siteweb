<?php
//Ouverture de la session
session_start();
//Si l'action de valider a �t� faite
if(isset($_POST['valider'])){
echo "bonjoue";
	//les identifiants
	$pseudo = "wezna";
	$pass = "wazar";
	//On teste les identifiants
	if($_POST['pseudo'] == $pseudo AND $_POST['password'] == $pass){
		//On cr�� les sessions
		header('Location:acceuil.php');
	}
	else{
		echo 'Mot de passe ou pseudo invalide!';
	}
}
//Si les 2 sessions existes
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>

<style type="text/css">
<!--
.Style1 {color: #FFFFFF}
body {
	background-image: url();
	background-color: #FFFFFF;
}
.Style2 {color: #000000; font-size: x-large; }
.Style3 {color: #000000}
.Style4 {font-size: x-large}
-->
</style>
</head>

<body>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#FFFFFF" scope="col"><div align="right"><img src="../images/Capture.JPG" width="176" height="125" /></div></th>
    <th width="987" background="../images/naima.jpg" scope="col"><div align="center"></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col"> <span class="Style1">
      <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();">
        <em><span class="Style3">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-</span><span class="Style3">Terrain-Locaux</span></em>
      </marquee>
     </span> </th>
   </tr>
</table>
              
<table width="1213" height="446" border="0" align="center">
  <tr>
    <th scope="col"> <p class="Style2">&nbsp;</p>
	  <table width="334" border="0" align="center">
        <tr>
          <th width="101" class="Style3" scope="col"><img src="../images/cle.gif" />&nbsp;</th>
          <th width="223" class="Style3" scope="col"><span class="Style4">Autentification </span></th>
        </tr>
      </table>
	  
	  <table width="399" height="196" border="3" align="center">
        <tr>
         <td> 	  
		 
		 <form id="form1" name="form1" method="POST" action="index.php">
		 
	    <table width="364" border="0" align="center">
          <tr align="center" valign="middle">
            <td> nom utilisateur : </td>
            <td><input name="pseudo" type="text" /></td>
          </tr>
          <tr align="center" valign="middle">
            <td> mot de passe : </td>
            <td><input name="password" type="password" /></td>
          </tr>
          <tr align="center" valign="middle">
            <td height="28">&nbsp;</td>
            <td> <input name="valider" type="submit"  id="submit" value="Connexion"/></td>
          </tr>
        </table>
		
		
      </form>
	  
	 
	  
        </tr>
      </table>
	  <p>&nbsp;</p>    </th>
  </tr>
</table>
<table width="1218" height="138" border="0" align="center" bordercolor="#000000" bgcolor="#006666">
  <tr bgcolor="#666666"> <th width="391" height="132" align="center" valign="top" bgcolor="#006699" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#003333" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>


</body>
</html>
