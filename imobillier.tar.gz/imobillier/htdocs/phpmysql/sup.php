<?php

mysql_connect("localhost","root","mimia") or die ("erreur");
mysql_select_db("people") or die ("erreur de s");

$querydate = mysql_query("SELECT * FROM people") or die ("errr");


if(isset($_GET['delete'])){

   $multiple = ($_GET['multiple']);
   
   $i = 0;
   
   $sql = "DELETE FROM people";
   foreach($multiple as $item_id){ $i ++;
	
  if($i == 1){
	  $sql .= " WHERE id = " . mysql_real_escape_string($item_id) . "";
	    }else {
		  $sql .= " OR id = " . mysql_real_escape_string($item_id) . "";
		}
	}
	mysql_query($sql) or die ("erreur");
	header("location: " . $_SERVER['PHP_SELF']);
	exit();
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Delete Multiple</title>
<style type="text/css">
    
     body{
	     
		 font-family:Arial,  sans-serif;
		 font-size:14px;
		 line-height:1.6;
		 text-align:center;
	 
	 }
    #wrapper{
	
	      margin: 0 auto;
		  width:650px;
		  text-align:left;
	
	}
	
	td{
	    padding:20px;
	
	}
	
	thead{ 
	     background:#D2E6EA; 
	
	}

</style>
</head>

<body>
<div id="wrapper">
<?php if(mysql_num_rows($querydate) > 0): ?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">

     <table width="100%">
	 
	    <thead>
		   <tr>
		    <td>First name</td>
			<td>Last name</td>
			<td>Age</td>
			<td align="center">
			 <div>
			   <input type="submit" name="delete" value="delete multiple" />
			 </div>			</td>
		   </tr>
		</thead>
		
		<tbody>
		
		<?php while($row = mysql_fetch_assoc($querydate)) { ?>
		    <tr>
		    <td><?php echo $row['first_name'] ?></td>
			<td><?php echo $row['last_name'] ?></td>
			<td><?php echo $row['age'] ?></td>
			<td align="center">
			    <input type="checkbox" name="multiple[]" value="<?php echo $row['id']; ?>" />			</td>
			</tr>
       <?php } ?> 
		</tbody>
	 </table>
</form>
<?php else: ?>
<h2>no data to display</h2>
<?php endif; ?>
</div>
</body>
</html>
