<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
	<?php
		try{
			$bdd = new PDO ('mysql:host=localhost;dbname=tests','root','mimia'); 
			//echo 'Connexion � la base de donn�e r�ussie';
			}
		catch(Exception $e){
			die('Erreur: '. $e->getMessage());
		}
		$req = $bdd->prepare('SELECT nom, prix FROM jeux_videos WHERE processeur= :processeur AND prix<= :prixmax');
		$req->execute(array('processeur'=> 'Florent', 'prixmax'=>25));
		echo '<ul>';
		while ($donnees = $req->fetch()) {
			echo '<li>'.$donnees['nom']. ' ('.$donnees['prix'].'&#8364;)</li>';
		}
		echo '</ul>';
		$req->closeCursor();
		
	?>
</body>
</html>
