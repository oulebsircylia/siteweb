<?php 
	$langue_afficher = isset ($_GET['langue']) ? $_GET['langue'] : 'fr';
	define ('AFFICHE', $langue_afficher);
	$langue = array(
		'en' => 'Hello World !',
		'fr' => 'Bonjour tout le monde !',
		'es' => 'Hole mundo !',
		'de' => 'Hallo Welt !',
	);
	$langues = array(
		'en' => 'english',
		'fr' => 'fran�ais',
		'es' => 'espanol',
		'de' => 'deutch',
	);
	$retour = '<br/>';
	function paragraphe ($message, $couleur  ='blue'){
		return '<p style="color: '.$couleur.'">'.$message.'</p>';
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>
<body>
<p>
	Afficher en :
	<?php
		foreach ($langues as $symbole=>$en_cours){ 
			echo '<a href="./?langue='.$symbole.'" style="margin: 5px 10px; font-size:smaller">'.$en_cours.'</a>';
		}
	?>
</p>
	<?php
		if (AFFICHE == 'all'){
			$recap = '';
			foreach ($langue as $lang=>$message){
				$recap = $lang.' : '.$message.$retour;
			}
			echo paragraphe ($recap, 'red'); 
		}
		else{
			switch (AFFICHE){
				case 'en':
				case 'am':
					echo $langue['en'];
					break;
				case 'fr':
				case 'ca':
				case 'be':
				case 'ch':
					echo $langue['fr'];
					break;
				case 'es':
				case 'me':
					echo $langue['es'];
					break;
				case 'de':
				case 'at':
					echo $langue['de'];
					break;
				default:
					echo 'Votre langue n\'est pas connue !';		
			}
		}
	?>

</body>
</html>
