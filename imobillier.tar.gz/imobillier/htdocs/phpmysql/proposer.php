<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('operation').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('nbr_piece').style.display= 'inline';
	  document.getElementById('piece').style.display= 'none';
	    document.getElementById('nbr_etage').style.display= 'none';
		 document.getElementById('hauteur').style.display= 'none';
		  document.getElementById('longueur').style.display= 'none';
		   document.getElementById('largeur').style.display= 'none';
		    document.getElementById('cat�gorie').style.display= 'none';
			document.getElementById('nbr_fa�ades').style.display= 'none';
			document.getElementById('num_�tage').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('nbr_piece').style.display= 'none';
	  document.getElementById('piece').style.display= 'inline';
	    document.getElementById('nbr_etage').style.display= 'inline';
         document.getElementById('hauteur').style.display= 'none';
		  document.getElementById('longueur').style.display= 'none';
		   document.getElementById('largeur').style.display= 'none';
		  document.getElementById('cat�gorie').style.display= 'none';
		  document.getElementById('nbr_fa�ades').style.display= 'none';
		  document.getElementById('num_�tage').style.display= 'none';
        } 
		  if (a == "terrain"){
	 document.getElementById('nbr_piece').style.display= 'none';
	  document.getElementById('piece').style.display= 'none';
	    document.getElementById('nbr_etage').style.display= 'none';
		 document.getElementById('hauteur').style.display= 'none';
		  document.getElementById('longueur').style.display= 'none';
		   document.getElementById('largeur').style.display= 'none';
		    document.getElementById('cat�gorie').style.display= 'inline';
			document.getElementById('nbr_fa�ades').style.display= 'inline';
			document.getElementById('num_�tage').style.display= 'none';
        } 
	if (a == "entrepot"){ 
		document.getElementById('nbr_piece').style.display= 'none';
	  document.getElementById('piece').style.display= 'none';
	    document.getElementById('nbr_etage').style.display= 'none';
		 document.getElementById('hauteur').style.display= 'inline';
		  document.getElementById('longueur').style.display= 'inline';
		   document.getElementById('largeur').style.display= 'inline';
		    document.getElementById('cat�gorie').style.display= 'none';
			document.getElementById('nbr_fa�ades').style.display= 'none';
			document.getElementById('num_�tage').style.display= 'none';
        } 
	
	
		
		   }
</script>

<style>
body {
	background-color: #CCCCCC;
	background-image:url(images/BACKGROUND.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
</style>
</head>

<body>
<div id="conteneur">
	<div id="header">
		<div id="slogon" align="center">
				<img src="images/logopaint.jpg" width="160" height="150" />
				<img src="images/naima3.jpg" width="960" height="150" />
		</div>
		<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
	 			 </tr>
 			</table>
		</div>
			
		
			<ul id="menu" >
	<li><a href="index2.php">Acceuil</a>
		
	</li>
	<li><a href="recherche2.php">Recherche</a>
		
	</li>
	<li><a href="proposer2.php">Proposer</a>
		
	</li>
	<li><a href="inscription.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
	<div id="corps">
		
		<div id="droite">
		</div>
		<div id="gauche">
		
		</div>
		<div id="milieu">
			<h1 align="center">Proposer un bien: </h1>
						<form action="" method="post" enctype="multipart/form-data">
							<table align="center" border="0">
								<tr>
									<td width="125">
								  <label for="bien">Bien:    </label>									</td>
    							  <td width="741"><select id="operation" name="operation" onchange="Changer()">
                                      <option value="vide"></option>
                                      <option value="appartement">Appartement</option>
                                      <option value="villa">Villa</option>
                                      <option value="terrain">Terrain</option>
                                      <option value="entrepot">Entrepot</option>
                                    </select>
    							    <select name="select2" id="nbr_piece" style="display:none">
                                      <option value="vide">Type</option>
                                      <option value="f1">F1</option>
                                      <option value="f2">F2</option>
                                      <option value="f3">F3</option>
                                      <option value="f4">F4</option>
                                      <option value="f5">F5</option>
                                      <option value="f5">F5+</option>
                                    </select>
    							    <select name="select3" id="nbr_etage" style="display:none">
                                      <option value="vide">Nombre d'�tage</option>
                                      <option value="f1">1 �tage</option>
                                      <option value="f2">2 �tages</option>
                                      <option value="f3">3 �tages</option>
                                      <option value="f4">4 �tages</option>
                                      <option value="f5">5 �tage</option>
                                      <option value="f5">+ de5 �tages </option>
                                    </select>
   						 <input name="piece" type="text" value="" id="piece" placeholder="nombre de piece" style="display:none"/>
		<input name="hauteur" type="text" value="" id="hauteur" placeholder="saisir la hauteur" style="display:none"/>
	<input name="longueur" type="text" value="" id="longueur" placeholder="saisir la longueur" style="display:none"/>
	<input name="largeur" type="text" value="" id="largeur" placeholder="saisir la largeur" style="display:none"/>
	<input name="nbr_fa�ades" type="text" value="" id="nbr_fa�ades" placeholder="saisir le nombre de fa�ade" style="display:none"/>
	<input name="num_�tage" type="text" value="" id="num_�tage" placeholder="saisir le numero d'�tage" style="display:none"/>
  <select name="cat�gorie" id="cat�gorie" style="display:none">
                                      <option value="vide">cat�gorie</option>
                                      <option value="1">Terrain urbanisable</option>
                                      <option value="2">Terrain agricol</option>
                                      <option value="3">Terrain industriel</option>
                                     
                                    </select>
			
							      </td>
								</tr>
								<tr>
									<td>
										<label for="cat�gorie">Type transaction: </label>	</td>
									<td>
										<select name="bien" id="bien" placeholder="Type de bien">
	 										<option value="vide"></option> 
											<option value="achat">Achat</option>
											<option value="location">Location</option>
											<option value="location">Echange</option>
										</select>	</td>
								</tr>
								<tr>
									<td>
										<label for="lieu">Lieu: </label></td>
									<td>
										<input type="text" name="lieu" id="lieu" />	</td>
								</tr>
								<tr>
									<td>
										<label for="superficie">Superficie: </label>	</td>
									<td>
										<input type="number" name="superficie" id="superficie" />m�									</td>
								</tr>
								<tr>
									<td>
										<label for="prix">Prix: </label>									</td>
									<td>
										<input type="number" name="prix" id="prix" />DA									</td>
								</tr>
								<tr>
									<td>
										<label for="description">Ajouter des images: </label>									    </td>
									<td><input name="" type="image" /></td>
								</tr>
								<tr>
									<td>									</td>
									<td>
										<input type="submit" value="Valider"/>									</td>
								</tr>
						</table>
		  </form>
	    </div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9">05-51-57-24-99</p>    </th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">E-mail:</p>
    <p align="center" class="Style9">chalal.immobilier@hotmail.fr</p></th>
  </tr>
</table>
	</div>
</div>
</body>
</html>
