// JavaScript Document

<script type ="text/javascript">
	alert('test javascript')
</script>