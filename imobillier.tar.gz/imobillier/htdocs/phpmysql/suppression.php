<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
	<?php
		try{
			$bdd = new PDO ('mysql:host=localhost;dbname=tests','root','mimia'); 
			//echo 'Connexion � la base de donn�e r�ussie';
			}
		catch(Exception $e){
			die('Erreur: '. $e->getMessage());
		}
		$req=$bdd->prepare('DELETE FROM jeux_videos WHERE nom=:nom_jeu');
		$req->execute(array(
		'nom_jeu' => 'Mario'   ));
		//echo $nb_modif.' entr�es ont �t� modifi�es !';
		/*$bdd->exec('UPDATE jeux_videos SET prix=10, nbr_joueurs_max=32 WHERE nom=\'Battelefield 1942\'');*/
		echo 'La suppr�ssion est �ff�ctu� !';
		?>
</body>
</html>
