<?php
class autentif{

	static function get_msg_connection($nummsg){
	switch($nummsg){
	case 0:return '<div class="confirmation">'."Bienvenue ".$_SESSION['user_ed2c'].'</div>';break;
	case 1:return '<div class="erreur">'."Identifiant ou mot de passe incorrect .</div>";break;
	}
	}
	static function get_msg_deconnection($nummsg){
	switch($nummsg){
	case 0:return '<div class="confirmation">'."Vous �tre maintenant d�connect� .</div>";break;
	case 1:return '<div class="confirmation">'."Vous �tre d�j� d�connect� .</div>";break;
	}
	}
	static function get_msg_acces(){
	return '<div class="erreur">'."Vous ne pouvez pas acc�der � ce service soit parce que :
	<br>-	Vous ne vous �tre pas authentifi�.
	<br>-	Vous n�avez l�autorisation d�acc�der � ce service.</div>";
	}

}
class releve{
	static function get_msg_erreur(){
	return '<div class="erreur">'."Relev� de note incomplet . Il manque certaines notes .</div>";
	}

}
class etudiant{

	static function get_msg_erreur($nummsg){
	switch ($nummsg){
	case 0:return '<div class="erreur">'."Vous n�avez pas s�lectionn�e un(e) �tudiant(e) .</div>";break;
	case 1:return '<div class="erreur">'."Le code que vous avez inscrit appartient d�j� � un autre �tudiant(e) .</div>";break;
	case 2:return '<div class="erreur">'."Vous n�avez rien inscrit pour la recherche .</div>";break;
	case 3:return '<div class="erreur">'."Erreur lors de la suppression .<br>Veuillez recommencer .</div>";break;
	case 4:return '<div class="erreur">'."L'�tudiant(e) que vous avez s�l�ction�(e) n'existe pas (plus) </div>.";break;
	case 5:return '<div class="erreur">'."Aucun(e) �tudiant(e) trouv�(e) .</div>";break;
	case 6:return '<div class="erreur">'.'Aucune inscription trouv�e .</div>';break;
	case 7:return '<div class="erreur">'.'Aucun m�moire trouv� .</div>';break;
	case 8:return '<div class="erreur">'.'Aucun dipl�me trouv� .</div>';break;
	}
	}
	static function get_msg_ajout($nom,$prenom){
	return '<div class="confirmation">'."L��tudiant(e) ".$nom." ".$prenom." a �t� ajout�(e) avec succ�s .</div>";
	}
	static function get_msg_modif(){
	return '<div class="confirmation">'."Les modifications sur l'�tudiant(e) ont �t� effectu�es avec succ�s .</div>";
	}

}
class enseignant{

	static function get_msg_erreur($nummsg){
	switch ($nummsg){
	case 0:return '<div class="erreur">'."Vous n�avez pas s�lectionn�e un(e) enseignant(e) .</div>";break;
	case 1:return '<div class="erreur">'."Le code que vous avez inscrit appartient d�j� � un(e) autre enseignant(e) .</div>";break;
	case 2:return '<div class="erreur">'."Vous n�avez rien inscrit pour la recherche .</div>";break;
	case 3:return '<div class="erreur">'."Erreur lors de la suppression .<br>Veuillez recommencer .</div>";break;
	case 4:return '<div class="erreur">'."L'enseignant(e) que vous avez s�l�ction�(e) n'existe pas (plus) .</div>";break;
	case 5:return '<div class="erreur">'."Aucun(e) enseignant(e) trouv�(e) .</div>";break;
	}
	}
	static function get_msg_ajout($nom,$prenom){
	return '<div class="confirmation">'."L�enseignant(e) ".$nom." ".$prenom." a �t� ajout�(e) avec succ�s .</div>";
	}
	static function get_msg_modif(){
	return '<div class="confirmation">'."Les modifications sur l'enseignant(e) ont �t� effectu�es avec succ�s .</div>";
	}

}
class memoire{

	static function get_msg_erreur($nummsg){
	switch ($nummsg){
	case 0:return '<div class="erreur">'."Vous n�avez pas s�lectionn�e un m�moire .</div>";break;
	case 1:return '<div class="erreur">'."Vous n�avez rien inscrit pour la recherche .</div>";break;
	case 2:return '<div class="erreur">'."Erreur lors de la suppression .<br>Veuillez recommencer .</div>";break;
	case 3:return '<div class="erreur">'."Le m�moire que vous avez s�l�ction�(e) n'existe pas (plus) .</div>";break;
	case 4:return '<div class="erreur">'."Aucun m�moire trouv� .</div>";break;
	}
	}
	static function get_msg_ajout($intitule){
	return '<div class="confirmation">'."Le m�moire $intitule a �t� ajout�(e) avec succ�s .</div>";
	}
	static function get_msg_modif(){
	return '<div class="confirmation">'."Les modifications sur l'enseignant(e) ont �t� effectu�es avec succ�s .</div>";
	}

}
class formulaire{
	static function get_msg($nummsg){
	switch ($nummsg){
	case 0 :return '<div class="confirmation">'."Veuillez remplir tous les champs obligatoires . (Marqu� avec une �toile *)</div>";break;
	case 1 :return '<div class="erreur">'."Certains champs n�ont pas �t� remplis .<br>Veuillez remplir tous les champs obligatoires .</div>";break;
	case 2 :return '<div class="erreur">'."La date ins�r�e est incorrect .</div>";break;
	case 3 :return '<div class="erreur">'."Les deux mots de passe ne concorde pas .</div>";break;
	}
	}
}
class champ{
	static function get_msg_vide(){
	return '<i>Information non communiqu�e</i>';
	}
}

class annee_univ{
	static function get_msg_ajout($annee){
	echo '<div class="confirmation">'."L'ann�e universitaire ".$annee."/".($annee+1)." a �t� ajout� avec succ�s .</div>";
	}
	static function get_msg_erreur($nummsg){
	switch ($nummsg){
	case 0:return '<div class="erreur">'."Vous n�avez pas s�lectionn�e une ann�e universitaire .</div>";break;
	case 1:return '<div class="erreur">'."L'ann�e universitaire que vous avez inscrit existe d�ja .</div>";break;
	case 2:return '<div class="erreur">'."L'ann�e universitaire que vous avez inscrit n'existe pas (plus) .</div>";break;
	case 3:return '<div class="erreur">'."Erreur lors de la suppression .<br>Veuillez recommencer .</div>";break;
	}
	}
}
class user{
	static function get_msg_erreur($nummsg){
		switch($nummsg){
		case 0:return '<div class="erreur">'."L'utilisateur existe d�ja .</div>";break;
		case 1:return '<div class="erreur">'."L'utilisateur n'existe pas (plus) .</div>";break;
		case 2:return '<div class="erreur">'."Vous n'avez pas s�l�ction� un utilisateur .</div>";break;
		}
	}
	static function get_msg($user){
	return '<div class="confirmation">'."L'utilisateur ".$user." a �t� ajout� avec succ�s .</div>";
	}
	static function get_msg_modif($user){
	return '<div class="confirmation">'."L'utilisateur ".$user." a �t� modifi� avec succ�s .</div>";
	}
}
class supp{
	static function get_msg($nummsg,$arg){
		switch($nummsg){
		case 0:return '<div class="confirmation">'."L'utilisateur ".$arg." a �t� supprim� avec succ�s .</div>";break;
		case 1:return '<div class="confirmation">'."L'�tudiant(e) ".$arg." a �t� supprim�(e) avec succ�s, ainsi que tous ces dipl�mes,inscriptions,notes et m�moires .</div>";break;
		case 2:return '<div class="confirmation">'."L'enseignant(e) ".$arg." a �t� supprim�(e) avec succ�s, ainsi que les m�moires o� il(elle) a paricip�s .</div>";break;
		case 3:return '<div class="confirmation">'."Le m�moire ".$arg." a �t� supprim�(e) avec succ�s .</div>";break;
		case 4:return '<div class="confirmation">'."L'inscription de l'�tudiant(e) ".$arg." a �t� supprim�(e) avec succ�s .</div>";break;
		case 5:return '<div class="confirmation">'."L'enseignant(e) ".$arg." a �t� supprim�(e) avec succ�s .</div>";break;
		case 6:return '<div class="confirmation">'."L'enseignant(e) ".$arg." a �t� supprim�(e) avec succ�s .</div>";break;
		case 7:return '<div class="confirmation">'."Le dipl�me de l'etudiant(e) ".$arg." a �t� supprim�(e) avec succ�s .</div>";break;
		case 8:return '<div class="confirmation">'."Le module ".$arg." a �t� supprim� avec succ�s .</div>";break;
		case 9:return '<div class="confirmation">'."L'option ".$arg." a �t� supprim�e avec succ�s .</div>";break;
		case 10:return '<div class="confirmation">'."Le module ".$arg." avec succ�s .</div>";break;
		case 11:return '<div class="confirmation">'."L'ann�e universitaire ".$arg."/".($arg+1)." a �t� supprim�e avec succ�s .</div>";break;
		}
	}
	static function get_msg_avert($nummsg,$arg){
		switch($nummsg){
		case 0:return "Etre vous sure de vouloir supprimer l'utilisateur ".$arg." ?";break;
		case 1:return "Etre vous sure de vouloir supprimer l'�tudiant(e) ".$arg.", ainsi que tous ces dipl�mes,inscriptions,notes et m�moires ?";break;
		case 2:return "Etre vous sure de vouloir supprimer l'enseignant(e) ".$arg.", ainsi que les m�moires o� il(elle) a paricip�(e) ?";break;
		case 3:return "Etre vous sure de vouloir supprimer le m�moire ".$arg." ?";break;
		case 4:return "Etre vous sure de vouloir supprimer l'inscription de ".$arg." ?";break;
		case 5:return "Etre vous sure de vouloir supprimer l'enseignant(e) ".$arg." ?";break;
		case 6:return "Etre vous sure de vouloir supprimer la news ".$arg." ?";break;
		case 7:return "Etre vous sure de vouloir supprimer le dipl�me en ".$arg." ?";break;
		case 8:return "Etre vous sure de vouloir supprimer le module ".$arg." ?";break;
		case 9:return "Etre vous sure de vouloir supprimer l'option ".$arg." ?";break;
		case 10:return "Etre vous sure de vouloir supprimer le module ".$arg." ?";break;
		case 11:return "Etre vous sure de vouloir supprimer l'ann�e universitaire ".$arg."/".($arg+1)." ?";break;
		}
	}
}
class insc{
	static function get_msg_erreur($nummsg){
		switch($nummsg){
		case 0:return '<div class="erreur">'."L'etudiant n'est pas(plus) inscrit dans l'ann�e universitaire .</div>";break;
		}
	}
	static function get_msg_ajout_inscr($nom,$prenom,$annee,$option,$niveau,$cycle){
	return '<div class="confirmation">'."L'�tudiant(e) ".$nom." ".$prenom." a �t� inscrit(e) � l'ann�e universitaire ".$annee."/".($annee+1)." dans l'option ".$option.", en tant que ".$niveau." ".$cycle." avec succ�s .</div>";
	}
}
class jury{
	static function get_msg_erreur($nummsg){
		switch($nummsg){
		case 0:return '<div class="erreur">'."L'enseignant(e) ne fait pas(plus) partie du jury .</div>";break;
		}
	}
}
class news{
	static function get_msg_erreur($nummsg){
		switch($nummsg){
		case 0:return '<div class="erreur">'."La news n'existe pas(plus) .</div>";break;
		}
	}
}
class diplome{
	static function get_msg_erreur($nummsg){
		switch($nummsg){
		case 0:return '<div class="erreur">'."Le dipl�me de l�tudiant(e) n'existe pas(plus) .</div>";break;
		}
	}
	static function get_msg_ajout_diplome($nom,$prenom,$cycle){
	return '<div class="confirmation">'."Le dipl�me en ".$cycle." a �t� ajout� � l'�tudiant(e) ".$nom." ".$prenom." avec succ�s .</div>";
	}
}
class op_mod{
	static function get_msg_erreur($nummsg){
		switch($nummsg){
		case 0:return '<div class="erreur">'."Erreur .</div>";break;
		case 1:return '<div class="erreur">'."Le module n'existe pas (plus) .</div>";break;
		case 2:return '<div class="erreur">'."L'option n'existe pas (plus) .</div>";break;
		case 3:return '<div class="erreur">'."Le module est d�ja inclue dans l'option .</div>";break;
		}
	}
	static function get_msg_ajout_op($arg){
		return '<div class="confirmation">'."L'option ".$arg." a �t� ajout�e avec succ�s .</div>";
	}
	static function get_msg_ajout_inclusion($arg,$arg1){
		return '<div class="confirmation">'."Le module ".$arg." a �t� inclue dans l'option ".$arg1." avec succ�s .</div>";
	}
	static function get_msg_modif_inclusion($arg,$arg1){
		return '<div class="confirmation">'."Le coefficient du module ".$arg." dans l'option ".$arg1." a �t� modifi�e avec succ�s .</div>";
	}
	static function get_msg_ajout_mod($arg){
		return '<div class="confirmation">'."Le module ".$arg." a �t� ajout� avec succ�s .</div>";
	}
	static function get_msg_modif_op($arg){
		return '<div class="confirmation">'."L'option ".$arg." a �t� modifi�e avec succ�s .</div>";
	}
	static function get_msg_modif_mod($arg){
		return '<div class="confirmation">'."Le module ".$arg." a �t� modifi� avec succ�s .</div>";
	}
}
?>