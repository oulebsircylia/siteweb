<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<title>Ecole doctorale : accueil</title>
	<link rel="stylesheet" media="screen" type="text/css" title="Design" href="css/design.css" />
	<script language="javascript" src="JS/jquery-1.6.1.js"></script>
	<script language="javascript" src="JS/script_mv.js"></script>
	<script language="javascript" src="JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include("entete.php") ?>
		<?php include("menu_ver.php") ?>
		<div id="corp_page">					
			<div class="titre_formulaire">
				<div class="titre_form_cgauche"></div>
				<div class="titre_form_text">Formulaire</div>
				<div class="titre_form_cdroite"></div>
			</div>
			<div class="formulaire_contenu">
				<form>
					<fieldset>
						<legend> Identifiants </legend>
							<label for="ident">Identifiant: </label>
								<input type="text" size="14" name="identifiant" class="champ_form" /><br/>
							<label for="ident">Mot de passe: </label>
								<input type="password" size="14" name="mot_de_passe" class="champ_form" /><br/>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<?php include("pied_page.php") ?>
</body>
</html>