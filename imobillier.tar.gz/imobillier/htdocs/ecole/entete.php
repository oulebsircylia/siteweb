<?php
if(isset($_GET['action'])){
			if($_GET['action']=='connexion'){
			@session_start();
				if(!(isset($_SESSION['user_ed2c']))&&(!isset($_SESSION['user_ed2c_crypted']))){
				if((isset($_POST['user']))&&(isset($_POST['password']))){
				include("cryptage.php");
				$user=crypter($_POST['user'],$key,$iv);
				$password=md5($_POST['password']);
				$id_root=mysql_connect("localhost","ed2c_level_3","6ubReBncfU9yp9vZ");
				mysql_select_db("ed2c",$id_root);
				$req=mysql_query("SELECT * FROM `users` WHERE `user` =\"$user\" AND `password`=\"$password\"",$id_root);
				if(mysql_numrows($req)){
					$_SESSION['user_ed2c']=$_POST['user'];
					$_SESSION['user_ed2c_crypted']=$user;
					$connected=true;
					$msg=autentif::get_msg_connection(0);
					}else{
					$msg=autentif::get_msg_connection(1);
					}
				}
				}		
			}else if($_GET['action']=='deconnexion'){
			@session_start();
				if((isset($_SESSION['user_ed2c']))||(isset($_SESSION['user_ed2c_crypted']))){
				session_unset();
				$connected=false;
				$msg=autentif::get_msg_deconnection(0);
				}else{
				$msg=autentif::get_msg_deconnection(1);
				}
			}
}
	if(!(isset($connected))){
		@session_start();
		if((isset($_SESSION['user_ed2c']))&&(isset($_SESSION['user_ed2c_crypted']))){
			$connected=true;
		}else{
			$connected=false;
			
		}
	}
?>
<div id="entete">
	<div id="logo">
			<a href="index.php">
				<img src="<?php echo ($chemin);?>IMG/logo.png" /></a>
	</div>
	<div id="barre_h">
		<div id="barre_navigation">
			<a href="<?php echo ($chemin);?>"><div <?php if($page_courante == 'index'){echo('class="bouton_page_courante"');}?> class="bouton_nav"> Accueil </div></a>
			<a href="<?php echo ($chemin);?>presentation_ed2c.php"><div <?php if ($page_courante == 'presentation'){echo('class="bouton_page_courante"');}?> class="bouton_nav"> Pr�sentation </div></a>
			<a href="<?php echo ($chemin);?>actualites_ed2c.php"><div <?php if ($page_courante == 'actualit�s'){echo('class="bouton_page_courante"');}?> class="bouton_nav"> Actualit�s </div></a>
			<a href="<?php echo ($chemin);?>formations_ed2c.php"><div <?php if ($page_courante == 'formations'){echo('class="bouton_page_courante"');}?> class="bouton_nav"> Formations </div></a>
			<?php if($connected){ ?><a href="<?php echo ($chemin).'Admin/';?>administration.php"><div <?php if ($page_courante == 'administration'){echo('class="bouton_page_courante"');}?> class="bouton_nav"> Administration </div></a><?php }?>
		</div>		
			<div class="liens_nav_gauche"> 
			<?php		
			if(!($connected)){
			?>
			|<a href="javascript:afficheId('contenu');"> Connexion </a>
			</div>
			<div class="contenant" id="contenu">
							<form method="post" action=<?php if($page_courante<>'administration'){ echo 'Admin/';};echo 'administration.php?action=connexion';?> id="form_connexion">			
								<label for="ident">Identifiant :</label>
									<input type="text" size="14" name="user" class="champ_form" /><br/>
								<label for="ident">Mot de passe :</label>
									<input type="password" size="14" name="password" class="champ_form"/><br>
								<a href=""><input type="submit" value="Se connecter" class="bouton_form"/></a>	
							</form>
			<?php } else{ ?>
				|<a href=<?php echo "../index.php?action=deconnexion";?>> D�connexion </a>
			<?php } ?>
			</div>
	</div> 
	</div>