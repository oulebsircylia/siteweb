<?php 
		@session_start();
		if(!(isset($connected))){
			if((isset($_SESSION['user_ed2c']))&&(isset($_SESSION['user_ed2c_crypted']))){
				$connected=true;
			}else{
				$connected=false;
			}
		}
?>
<div id="menu_ver">
	<ul class="navigation">
	<?php
	if($connected){
		echo '<font color="#C0C0C0">Connect� en tant que : <font size=4><u>'.$_SESSION['user_ed2c'].'</u></font></font>';
	}
	?>
    <li><a href="<?php echo($chemin);?>" title="Page d'acceil">Accueil</a></li>
	<li><a href="<?php echo($chemin).'presentation_ed2c.php';?>" title="Page d'acceil">Pr�sentation</a></li>
	<li><a href="<?php echo($chemin).'actualites_ed2c.php';?>" title="Page d'acceil">Actualit�s</a></li>
	<li><a href="<?php echo($chemin).'formations_ed2c.php';?>" title="Page d'acceil">Formations</a></li>
		<?php
		if($connected){
		?>
    <li class="toggleSubMenu"><span>> Administration</span>
		<ul class="subMenu">
			<?php include("acces.php"); if(isset($id_user)&&($level=="333")){?>
			<li><a href="<?php echo($chemin);?>Admin/gestion_utilisateurs.php" title="Gestion des utilisateurs">Gestion des utilisateurs</a></li> <?php }?>
            <li><a href="<?php echo($chemin);?>Admin/gestion_news.php" title="Gestion des news">Gestion des news</a></li> 
			<li><a href="<?php echo($chemin);?>Admin/gestion_etudiants.php" title="Gestion des �tudiants">Gestion des �tudiants</a></li> 			
			<li><a href="<?php echo($chemin);?>Admin/gestion_enseignants.php" title="Gestion des enseignants">Gestion des enseignants</a></li> 
			<li><a href="<?php echo($chemin);?>Admin/gestion_memoires.php" title="M�moires">Gestion des m�moires</a></li> 
			<li><a href="<?php echo($chemin);?>Admin/gestion_notes.php" title="Gestion des notes des examens">Gestion des notes</a></li> 
			<li><a href="<?php echo($chemin);?>Admin/gestion_options_modules.php" title="Gestion des options et des modules">Gestion options/modules</a></li> 
			<li><a href="<?php echo($chemin);?>Admin/inscriptions.php" title="Inscription">Inscriptions</a></li>
			<li><a href="<?php echo($chemin);?>Admin/diplomes.php" title="Dipl�mes">Dipl�mes</a></li>
		</ul> 
    </li> 
		<?php
		}
		?>
	</ul>
</div>
