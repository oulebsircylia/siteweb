<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<?php 
		$chemin = "../Ecole doctorale/";
		$page_courante = "index";
		include($chemin."msg.php");
	?>
	<title>Ecole doctorale : accueil</title>
	<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
	<link rel="stylesheet" media="screen" type="text/css" href=" <?php echo ($chemin); ?>css/form.css" />
	<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
	<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
	<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php 
			include("entete.php");
			include("menu_ver.php");
		?>
		<?php 
			function adapter_datetime($dat_heur){
				$jj = substr($dat_heur, 8, 2);
				$mm = substr($dat_heur, 5, 2);
				$aa = substr($dat_heur, 0, 4);
				$min = substr($dat_heur, -5, 2);
				$h = substr($dat_heur, -8, 2);
				return "Ajout�e le ".$jj."/".$mm."/".$aa." � ".$h.":".$min;
			}
			
			function extraire_chaine($chaine, $val){
							$i = 0;
							$chaineResultat="";
							//$nombre_de_ln=0;
							$chaineResultat=substr($chaine, 0, $val);
							if (strlen($chaine)>$val){
								while($chaine[$i]!=' '){
									$chaineResultat = $chaineResultat.$chaine[$i];
									$i++;
								}
							$chaineResultat=$chaineResultat."... ";
							}
				return $chaineResultat;
			}
		?>		
		<div id="corp_page">
		<?php
		if(isset($msg)){
		echo '<p>'.$msg.'</p>';
		}
		?>
			<h1> Ecole doctorale ed2c </h1>
			<p>
			   L��cole doctorale <strong>ed2c</strong> est le fruit mature de l��cole doctorale en R�seaux et Syst�mes Distribu�s ReSyD qui a �t� mise 
			   en place en Novembre 2003. Les objectifs et les attentes de l��poque sont largement d�pass�s. Cette nouvelle offre
			   est survenue suite � l�organisation des journ�es doctorales de B�jaia le 28 et 29 Novembre 2010 o� les participants � la table
			   ronde ont sugg�r� la red�finition des missions de la nouvelle �cole doctorale et la n�cessit� d�am�liorer les programmes de 
			   la formation R�seaux et Syst�mes Distribu�s pour �tre en phase avec les nouveaux d�veloppements des TIC. Dans ce contexte et
			   dans celui de la r�cession �conomique et de la mutation technologique, le recours aux technologies de virtualisation comme 
			   le Cloud Computing devient de plus en plus une n�cessit�.
			</p>
			<h1> Actualit�s </h1>
			<table class="tableau_news">
			<?php
				$id_user=mysql_connect("localhost", "ed2c_level_3", "6ubReBncfU9yp9vZ"); 
				mysql_select_db("ed2c",$id_user);
				$reponse = mysql_query("SELECT * from news ORDER BY code_news DESC LIMIT 5 ",$id_user);
					if(!(mysql_num_rows($reponse))){
					echo '<center>Aucune nouvelle pour le moment !</center>';
					}
				while ($news = mysql_fetch_array($reponse)){
				?>	
				<tr>
					<td class="titre_news">
						<div id="titre_news_pgauche">
							<?php 
								echo "<a href=\"afficher_news.php?num_news=".$news['code_news']."\"><strong>";
								echo extraire_chaine($news['titre_news'],60);
								echo "</strong></a>"; 
							?>
						</div>
						<div id="titre_news_pdroite">
							<?php echo adapter_datetime($news['date_heure_ajout']); ?>
						</div>			
					</td>
				</tr>
				<tr>
					<td class="contenu_news">
						<?php 
							echo "<pre>".extraire_chaine($news['enonce_news'],300)."</pre>";
							echo "<a href=\"afficher_news.php?num_news=".$news['code_news']."\">"; 
							if (strlen($news['enonce_news'])>300){echo ">> Lire la suite</a>";} 
						?>
					</td>
				</tr>
			<?php
			}	
			mysql_close();
			?>
			</table>
		
		</div>
		<?php include("pied_page.php");?>
	</div>
</body>
</html>
