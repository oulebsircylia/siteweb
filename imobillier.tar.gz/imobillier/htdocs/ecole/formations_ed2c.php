<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<?php 
	$chemin = "../Ecole doctorale/";
	$page_courante = "formations";
	?>
	<title>Ecole doctorale : accueil</title>
	<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
	
	<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
	<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
	<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
	
</head>
<body>
	<div id="site"> 
		<?php 
		include("entete.php");
		include("menu_ver.php"); 
		?>
		<div id="corp_page">
		
		</div>
		<?php include("pied_page.php");?>
	</div>
</body>
</html>
