<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<?php 
	$chemin = "../Ecole doctorale/";
	$page_courante = "actualit�s";
	?>
	<title>Ecole doctorale : accueil</title>
	<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
	
	<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
	<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
	<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
	
</head>
<body>
	<div id="site"> 
		<?php 
		include("entete.php");
		include("menu_ver.php");
		function adapter_datetime($dat_heur){
			$jj = substr($dat_heur, 8, 2);
			$mm = substr($dat_heur, 5, 2);
			$aa = substr($dat_heur, 0, 4);
			$min = substr($dat_heur, -5, 2);
			$h = substr($dat_heur, -8, 2);
			return "Ajout�e le ".$jj."/".$mm."/".$aa." � ".$h.":".$min;
		}
		$id_user=mysql_connect("localhost", "ed2c_level_3", "6ubReBncfU9yp9vZ"); 
		mysql_select_db("ed2c",$id_user);
		$num_news = $_GET['num_news'] ;
		$reponse = mysql_query("SELECT * from news WHERE code_news = $num_news");
		?>
		<div id="corp_page">
		<?php
		while($news = mysql_fetch_array($reponse)){
		echo "<h1>".$news['titre_news']."</h1>";
		echo "<p>".$news['enonce_news']."</p>";
		echo '<br><div align="right">'.adapter_datetime($news['date_heure_ajout']).'</div>';
		}
		?>
		</div>
		<?php
		mysql_close();
		include("pied_page.php");
		?>
	</div>
</body>
</html>