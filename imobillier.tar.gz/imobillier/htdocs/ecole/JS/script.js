function afficheId(baliseId){
  if (/*document.getElementById && */document.getElementById(baliseId) != null){
		if ((document.getElementById(baliseId).style.visibility == 'hidden')&&(document.getElementById(baliseId).style.display == 'none')){
			document.getElementById(baliseId).style.visibility='visible';
			document.getElementById(baliseId).style.display='block';
		}
		else{
			document.getElementById(baliseId).style.visibility='hidden';
			document.getElementById(baliseId).style.display='none';
		}
    }
  }

afficheId('contenu');

afficheId('contenu');

afficheId('contenu');
//cacheId('contenu');

// si JavaScript est disponible, cache le contenu d�s le
// chargement de la page. Sans JavaScript, le contenu sera
// affich�.