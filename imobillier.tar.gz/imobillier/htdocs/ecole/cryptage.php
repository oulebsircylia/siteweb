<?php
function crypter($msg,$key,$iv){
	return  mcrypt_encrypt(MCRYPT_3DES, $key, $msg, MCRYPT_MODE_NOFB, $iv);
}
function decrypter($msg,$key,$iv){
	return  mcrypt_decrypt(MCRYPT_3DES, $key, $msg, MCRYPT_MODE_NOFB, $iv);
}
//$key_length= mcrypt_module_get_algo_key_size(MCRYPT_3DES);
//$iv_length = mcrypt_get_iv_size(MCRYPT_3DES, MCRYPT_MODE_NOFB);
$iv='E��>I��';
$key='HyWnD8yBMUgMp9tCpZTGAZSD';
?>