<div id="pied_page">
	<br />
	<p>
		<a href="<?php echo ($chemin);?>"> Acceuil </a> |
		<a href="<?php echo ($chemin);?>presentation_ed2c.php"> Pr�sentation </a> |
		<a href="<?php echo ($chemin);?>actualites_ed2c.php"> Actualit� </a> |
		<a href="<?php echo ($chemin);?>formations_ed2c.php"> Formations </a> 
		<?php 
		@session_start();
		if(isset($_SESSION['user_ed2c'])){
		?>
		|
		<a href="<?php echo ($chemin);?>Admin/administration.php"> Administration </a> <br /><br />
		<?php }?>
	</p>
</div>