<?php
function adapter_datetime($dat_heur){
	$jj = substr($dat_heur, 8, 2);
	$mm = substr($dat_heur, 5, 2);
	$aa = substr($dat_heur, 0, 4);
	$min = substr($dat_heur, -5, 2);
	$h = substr($dat_heur, -8, 2); 
	return $jj."/".$mm."/".$aa." - ".$h.":".$min;
}
function adapter_date($date){
	$jj = substr($date, 8, 2);
	$mm = substr($date, 5, 2);
	$aa = substr($date, 0, 4);
	return $jj."/".$mm."/".$aa;
}
function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	$chaineResultat=substr($chaine, 0, $val);
	if(strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> R�sultat de la recherche : Etudiants </title>
<?php
	$chemin = "../";
	$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site">
		<?php include($chemin."entete.php");?>
		<?php include($chemin."menu_ver.php");?>
		 	<div id="corp_page">
				<p style="text-indent:0px;">Le r�sultat de la recherche:</p>
			<table class="affichage_table">
				<thead class="entete_tableau">
				<tr>
					<th>Matricule</th>
					<th>Nom</th>
					<th>Pr�nom</th>
					<th>Date de naissance</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody> 
					<?php
					$bool = true; 
					foreach($tab_resultat as $etudiant){
						if($bool){
								echo '<tr class="tableau_ligne_paire">';
							}else{
								echo'<tr class="tableau_ligne_impaire">';
							}
								$bool = !$bool;
							?>
								<td>
									<?php
										echo $etudiant['code_etudiant'];
									?>
								</td>
								<td>
									<?php
									echo $etudiant['nom_etudiant'];
									?>
								</td>
								<td>
									<?php
									echo $etudiant['prenom_etudiant'];
									?>
								</td>
								<td>
									<?php
									echo adapter_date($etudiant['date_naiss_etudiant']);
									?>
								</td>
								<td> 
									<?php 
										echo '<a href=info_etudiant.php?code='.$etudiant['code_etudiant'].' title="Aper�u">';
									?>
										<img src="IMG/apercu_icone.png"/></a>
									<?php 
										echo '<a href=modif_etudiant.php?code='.$etudiant['code_etudiant'].' title="Modifier">';
									?>
										<img src="IMG/modifie_icone.png"/></a>
									<?php 
										echo '<a href=supp.php?type=etudiant&code='.$etudiant['code_etudiant'].' title="Supprimer">';
									?>
										<img src="IMG/supp_icone.png"/></a>
									<?php //"</a>"?>
								</td>
							</tr>
						<?php } mysql_close();?>	
			</tbody>
		</table>
		</div>
		<?php include ($chemin."pied_page.php"); ?>
	</div>
</body>
</html>
		