<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des utilisateurs </title>
<?php 
$chemin = "../";
$page_courante = "administration";

include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if(isset($id_user)&&($level=="333")){
			$acces=true;
			if((isset($_GET['type']))&&(($_GET['type']=='option')||($_GET['type']=='module'))){
					switch($_GET['type']){
						case 'option':$msg='une option';
						if((isset($_POST['designation']))&&(isset($_POST['systeme']))){
						$des=$_POST['designation'];
						$sys=$_POST['systeme'];
						if(($_POST['designation']<>'')&&($_POST['systeme']<>'')){
						
							mysql_query("INSERT INTO `ed2c`.`option` (`code_option` ,`designation_option`,`systeme_option`)VALUES (NULL, \"$des\",\"$sys\");",$id_user);echo op_mod::get_msg_ajout_op($des);
							$err=false;
						}else{
						echo formulaire::get_msg(1);
						}
					}else{
					echo formulaire::get_msg(0);
					}
					break;
						case 'module':$msg='un module';
					if(isset($_POST['designation'])){
						if($_POST['designation']<>''){
						$des=$_POST['designation'];
						mysql_query("INSERT INTO `ed2c`.`module` (`code_module` ,`designation_module`)VALUES (NULL, \"$des\");",$id_user);echo op_mod::get_msg_ajout_mod($des);
						$err=false;
						}else{
						echo formulaire::get_msg(1);
						}
					}else{
					echo formulaire::get_msg(0);
					}	
					break;
					
					}
				}else{
				$err=false;
				echo op_mod::get_msg_erreur(0);
				}
			}else{
			$acces=false;
			echo autentif::get_msg_acces();
			}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des options/modules</a> > <a>Ajouter <?php echo $msg;?></a></p> 
		<form action="ajout_option_module.php?type=<?php echo $_GET['type'];?>" method="post" id="form_ajout_utilisateur" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Ajouter <?php echo $msg;?></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Designation (*) :</label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="designation" class="champ_form" value=<?php if(isset($des)&&($des<>'')){ echo $des;}else{ echo '""';} ?> />
								</td>
							</tr>
							<?php if($_GET['type']=='option'){?>
							<tr>
								<td class="case_gauche">
									<label for="ident">Syst�me (*) :</label>
								</td>
								<td class="case_droite">
								<select name="systeme" class="champ_form">
									<option value="classique">Classique</option>
									<option value="LMD">LMD</option>
								</select>
								</td>
							</tr>
							<?php }?>
							<tr>
								<td class="case_gauche">
								</td>
								<td class="case_droite">
									<a href=""><input type="submit" value="Ajouter" class="bouton_form"/></a>	
									<a href=""><input type="reset" value="Effacer" class="bouton_form"/></a>	
								</td>
							</tr>
						</table>
					</fieldset>
				</div>	
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>