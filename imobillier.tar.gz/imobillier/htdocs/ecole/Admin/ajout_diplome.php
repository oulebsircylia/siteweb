<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des dipl�mes </title>
<?php 
$chemin = "../";
$page_courante = "administration";

include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if(isset($id_user)&&(($level=="333")||($level=="222"))){
			$acces=true;
			if(isset($_GET['code'])){
			$code=$_GET['code'];
				if(mysql_num_rows(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code\""))){
				$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code\"",$id_user));
				$nom=$result['nom_etudiant'];
				$prenom=$result['prenom_etudiant'];
				if(isset($_POST['code_cycle'])&&isset($_POST['date_obtention'])){
					$date=$_POST['date_obtention'];
					$cycle=$_POST['code_cycle'];
						if(($date<>'')&&($cycle<>'')){
							$jj=substr($date,0,2);	$mm=substr($date,3,2);	$aa=substr($date,6,4);
							if(@checkdate($mm,$jj,$aa)){
							$date=$aa.'-'.$mm.'-'.$jj;
							mysql_query("INSERT INTO `diplome` (`code_diplome`,`code_etudiant`,`code_cycle`,`date_obtention`) VALUES (NULL,\"$code\",\"$cycle\",REVERSE(\"$date\"));",$id_user);
							$err=false;
							$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `cycle` WHERE `code_cycle`=\"$cycle\"",$id_user));
							$cy=$result['designation_cycle'];
							echo diplome::get_msg_ajout_diplome($nom,$prenom,$cy);
							}else{
							echo formulaire::get_msg(2);
							}
						}else{
						echo formulaire::get_msg(1);
						}
				}else{
				echo formulaire::get_msg(0);
				}
				}else{
				$err=false;
				}
			}else{
			$err=false;
			}
			}else{
			$acces=false;
			}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des dipl�mes</a> > <a>Ajouter un dipl�me</a></p> 
		<form action="ajout_diplome.php?code=<?php echo $code; ?>" method="post" id="form_ajout_utilisateur" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Ajouter un dipl�me � l'�tudiant(e) <?php echo $nom." ".$prenom;?></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Date d'obtention (*) :</label>
								</td>
								<td class="case_droite">
								<input type="text" size="10" name="date_obtention" value=<?php if(isset($date)&&$date<>''){echo $date;}else{ echo'""';} ?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Cycle (*) :</label>
								</td>
								<td class="case_droite">
								<select name="code_cycle" class="champ_form">
								<?php
								$result=(mysql_query("SELECT * FROM `cycle` WHERE `code_cycle` NOT IN (SELECT `code_cycle` FROM `diplome` WHERE `code_etudiant`=\"$code\") AND `code_cycle` IN (SELECT `code_cycle` FROM `inscription` WHERE `code_etudiant`=\"$code\" AND ((`code_cycle`=1 AND `code_niveau`=2) OR ((`code_cycle`=2 OR `code_cycle`=3) AND `code_niveau`=3) ) )"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_cycle'].'">'.$tab['designation_cycle'].'</option>';
									}
								?>
								</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
								</td>
								<td class="case_droite">
									<a href=""><input type="submit" value="Ajouter" class="bouton_form"/></a>	
									<a href=""><input type="reset" value="Effacer" class="bouton_form"/></a>	
								</td>
							</tr>
						</table>
					</fieldset>
				</div>	
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>