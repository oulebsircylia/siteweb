<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des utilisateurs </title>
<?php 
$chemin = "../";
$page_courante = "administration";

include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if(isset($id_user)&&($level=="333")){
			$acces=true;
				if(isset($_GET['code_option'])&&isset($_GET['code_module'])){
				$old_option=$_GET['code_option'];
				$old_module=$_GET['code_module'];
				if(mysql_num_rows(mysql_query("SELECT * FROM `inclusion` WHERE `code_option`=\"$old_option\" AND `code_module`=\"$old_module\""))){
					if(isset($_POST['coef'])){
					$option=$_POST['option'];
					$module=$_POST['module'];
					$coef=$_POST['coef'];
					if($coef<>''){
						if(!(mysql_num_rows(mysql_query("SELECT * FROM `inclusion` WHERE `code_option`=\"$option\" AND `code_module`=\"$module\"")))){
						mysql_query("UPDATE `inclusion` (`code_option`,`code_module`,`coefficient`) VALUES (\"$option\",\"$module\",\"$coef\");",$id_user);
						$err=false;
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$option\"",$id_user));
						$op=$result['designation_option'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `module` WHERE `code_module`=\"$module\"",$id_user));
						$mo=$result['designation_module'];
						echo op_mod::get_msg_modif_inclusion($op,$mo);
						}else{
						echo op_mod::get_msg_erreur(3);
						}
					}else{
					echo formulaire::get_msg(1);
					}
					}else{
					$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `inclusion` WHERE `code_option`=\"$old_option\" AND `code_module`=\"$old_module\""));
					$coef=$result['coefficient'];
					$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$old_option\""));
					$op=$result['designation_option'];
					$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `module` WHERE `code_module`=\"$old_module\""));
					$mo=$result['designation_module'];
					echo formulaire::get_msg(0);
					}
				}else{
				$err=false;
				}
				}else{
				$err=false;
				}
			}else{
			$acces=false;
			}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des options/modules</a> > <a>Modifier le coefficient d'un module dans une option</a></p> 
		<form action="ajout_inclusion.php" method="post" id="form_ajout_utilisateur" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Modifier le coefficient du module <?php echo $op;?> dans l'option <?php echo $mo;?></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>	
							<tr>
								<td class="case_gauche">
									<label for="ident">Coefficient (*) :</label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="coef" class="champ_form" value=<?php if(isset($coef)&&($coef<>'')){ echo $coef;}else{ echo '""';} ?> />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
								</td>
								<td class="case_droite">
									<a href=""><input type="submit" value="Ajouter" class="bouton_form"/></a>	
									<a href=""><input type="reset" value="Effacer" class="bouton_form"/></a>	
								</td>
							</tr>
						</table>
					</fieldset>
				</div>	
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>