<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Administration </title>
<?php 
$chemin = "../../Ecole doctorale/";
$page_courante = "administration";
include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site">
		<?php 
		include($chemin."entete.php");
		include($chemin."acces.php");
		include($chemin."menu_ver.php");
		?>
		<div id="corp_page">
		<?php
		if(isset($msg)){
		echo '<p>'.$msg.'</p>';
		}
		?>
			<?php
			if(isset($id_user)){
				@session_start();
				if(isset($_POST['code_annee_univ'])){
				$code_annee=$_POST['code_annee_univ'];
					if(mysql_num_rows(mysql_query("SELECT * FROM `annee_univ` WHERE `code_annee_univ`=\"$code_annee\""))){
					$_SESSION['code_annee_univ']=$code_annee;
					}
				}
				if(isset($_SESSION['code_annee_univ'])){
				$code_annee=$_SESSION['code_annee_univ'];
				$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `annee_univ` WHERE `code_annee_univ`=\"$code_annee\""));
				echo '<div class="confirmation">'."L'ann�e universitaire de travail : ".$result['annee_debut'].'/'.($result['annee_debut']+1)."</div>";
				}else{
				echo '<div class="erreur">'."Vous n'avez pas encore selectionn� une ann�e universitaire de travail.<br>Vous pouvez le faire ci-dessous.</div>";
				}
				$result=mysql_query("SELECT * FROM `annee_univ` ORDER BY `annee_debut` DESC");
			?>
	<div class="formulaire">
		<div class="titre_formulaire">
			<div class="titre_form_cgauche"></div>
			<div class="titre_form_text"> Choix de l'ann�e universitaire de travail </div>
			<div class="titre_form_cdroite"></div>
		</div>
		<div class="formulaire_contenu">
			<form action="administration.php" method="post" class="formulaire">
			<table class="align_form">
				<tr>
				<td class="case_gauche">Choix :
				<select name="code_annee_univ" class="champ_form">
			<?php 
				while($tab=mysql_fetch_assoc($result)){
				echo '<option value="'.$tab['code_annee_univ'].'">'.$tab['annee_debut'].'/'.($tab['annee_debut']+1).'</option>';
				}
			?>
				</select>
				</td>
				<td><input type="submit" value="Choisir" class="bouton_form"/></td>
				</tr>
			</table>
			</form>
		</div>
	</div>
	<br/>
	<?php
		if((isset($id_user))&&(($level=="222")||($level=="333"))){
			if(isset($_GET['action'])&&($_GET['action']=='ajout')){
				if(isset($_POST['annee_debut'])){
				$annee=$_POST['annee_debut'];
					if(!mysql_num_rows(mysql_query("SELECT * FROM `annee_univ` WHERE `annee_debut`=\"$annee\""))){
					mysql_query("INSERT INTO `annee_univ` (`code_annee_univ`,`annee_debut`) VALUES (NULL,\"$annee\")");
					echo '<div class="confirmation">'."L'ann�e universitaire ".$annee."/".($annee+1)." a �t� ajout� avec succ�s .</div>";
					}else{
					echo '<div class="erreur">'."L'ann�e universitaire ".$annee."/".($annee+1)." a d�ja �t� ajout� .</div>";
					}
				}
			}
	?>
	<div class="formulaire">
		<div class="titre_formulaire">
			<div class="titre_form_cgauche"></div>
			<div class="titre_form_text"> Ajouter une ann�e universitaire</div>
			<div class="titre_form_cdroite"></div>
		</div>
		<div class="formulaire_contenu">
			<form action="administration.php?action=ajout" method="post" class="formulaire">
			<table class="align_form">
				<tr>
				<td class="case_gauche">Ann�e de d�but :
				<input type="text" size="10" name="annee_debut" class="champ_form" />
				</td>
				<td><input type="submit" value="Ajouter" class="bouton_form"/></td>
				</tr>
			</table>
			</form>
		</div>
	</div>
	<p>Liste des ann�es universitaires</p>
					<table class="affichage_table">
						<thead class="entete_tableau">
							<th>Ann�e Universitaire</th>
							<th>Action</th>
						</thead>
						<?php 
						$class="paire";
						$result=mysql_query("SELECT * FROM `annee_univ` ORDER BY `annee_debut` DESC");
							while($tab=mysql_fetch_assoc($result)){
						?>
						<tr class=<?php echo '"tableau_ligne_'.$class.'"';?>>
						<td><?php echo $tab['annee_debut'].'/'.($tab['annee_debut']+1);?></td>
						<td><a href=<?php echo "supp.php?type=annee&code=".$tab['code_annee_univ'];?>><img src="IMG/supp_icone.png"></img></a></td>
						</tr>
						<?php
										if($class=="paire"){
										$class=="impaire";
										}else{
										$class=="paire";
										}
							}
						?>
					</table>
			<?php 
				
			}
			} ?>
		</div>
		<?php 
		include($chemin."pied_page.php");?>
	</div>
</body>
</html>
