<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des etudiants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
function adapter_date($date){
	$jj = substr($date, 8, 2);
	$mm = substr($date, 5, 2);
	$aa = substr($date, 0, 4);
	return $jj."/".$mm."/".$aa;
}
function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	//$nombre_de_ln=0;
	$chaineResultat=substr($chaine, 0, $val);
	if (strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}	
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php");
		include($chemin."msg.php");
		include($chemin."acces.php");
		if(isset($id_user)){
			if(isset($_GET['code'])){
			$code=$_GET['code'];
				if(mysql_num_rows(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code\"",$id_user))){
				$resultat=mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code\"",$id_user);
				$tab=mysql_fetch_assoc($resultat);
				$nom=$tab['nom_etudiant'];
				$prenom=$tab['prenom_etudiant'];
					if(!(isset($_GET['option']))){
					$dn=$tab['date_naiss_etudiant'];
					$lieu=$tab['lieu_naiss_etudiant'];
					$adresse=$tab['adresse_etudiant'];
					$nationalite=$tab['nationalite_etudiant'];
					$diplome=$tab['diplome_acces_etudiant'];
					$labo=$tab['labo_rech_etudiant'];
		?>
			<div id="corp_page">
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des �tudiants</a> > <a>Informations sur un(e) �tudiant(e)</a></p> 
			<div class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Informations sur un(e) �tudiant(e) </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Matricule : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $code;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nom : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $nom;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�nom : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $prenom;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date de naissance : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo adapter_date($dn);?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Lieu de naissance : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $lieu;?></label>
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
									<label for="ident">Adresse : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $adresse;?></label>
								</td>
								<tr>
								<td class="case_gauche">
									<label for="ident">Nationalit� : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $nationalite;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Dipl�me d�acc�s : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $diplome;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Laboratoire de recherche :</label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if($labo==''){ echo champ::get_msg_vide(); }else{echo $labo;}?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Voir les inscriptions :</label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><a href=<?php echo "info_etudiant.php?code=".$code."&option=insc" ?>>Clicker ici</a></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Voir les m�moires :</label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><a href=<?php echo "info_etudiant.php?code=".$code."&option=mem" ?>>Clicker ici</a></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Voir les dipl�mes :</label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><a href=<?php echo "info_etudiant.php?code=".$code."&option=dip" ?>>Clicker ici</a></label>
								</td>
							</tr>
						<?php
							}else{
							$option=$_GET['option'];
							if($option=='insc'){
							$num_insc=mysql_num_rows(mysql_query("SELECT * FROM `inscription` WHERE `code_etudiant`=\"$code\"",$id_user));
							$resultat=mysql_query("SELECT * FROM `inscription`,`annee_univ` WHERE `code_etudiant`=\"$code\" AND `inscription`.`code_annee_univ`=`annee_univ`.`code_annee_univ` ORDER BY `annee_debut` DESC",$id_user);
							?>
			<div id="corp_page">
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des �tudiants</a> > <a>Informations sur un(e) �tudiant(e)</a></p>
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> <a href=<?php echo "info_etudiant.php?code=".$code;?>>Informations sur les inscriptions de <?php echo $nom." ".$prenom." (".$num_insc.")"; ?></a></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
					<?php if(($level==222)||($level=="333")){?>
					<p style="text-indent:0px;">
					Pour inscrire l'�tudiant(e) dans une nouvelle ann�e universitaire clicker sur : <a href=<?php echo '"ajout_inscription.php?code='.$code.'"';?>><input type="button" value="Inscrire l'�tudiant(e)" class="bouton_form"/></a>
					</p>
					<?php }?>
						
							<?php
								if(!(mysql_num_rows($resultat))){
								echo '<div align="center">'.etudiant::get_msg_erreur(6).'</div>';
								}else{
								?>
								<table class="affichage_table">
							<thead class="entete_tableau">
							<th>Ann�e Universitaire</th>
							<th>Option</th>
							<th>Niveau</th>
							<th>Cycle</th>
							<th>Action</th>
							</thead>
								<?php
								while($tab=mysql_fetch_assoc($resultat)){
								$code_annee=$tab['code_annee_univ'];
								$code_option=$tab['code_option'];
								$code_niveau=$tab['code_niveau'];
								$code_cycle=$tab['code_cycle'];
								$annee=$tab['annee_debut'];
								$result=mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$code_option\"",$id_user);
								$tab2=mysql_fetch_assoc($result);
								$des_option=$tab2['designation_option'];
								$sys=$tab2['systeme_option'];
								$result=mysql_query("SELECT * FROM `niveau` WHERE `code_niveau`=\"$code_niveau\"",$id_user);
								$tab2=mysql_fetch_assoc($result);
								$des_niveau=$tab2['designation_niveau'];
								$result=mysql_query("SELECT * FROM `cycle` WHERE `code_cycle`=\"$code_cycle\"",$id_user);
								$tab2=mysql_fetch_assoc($result);
								$des_cycle=$tab2['designation_cycle'];
						?>
			
							<tr>
								<td>
									<label for="ident"><?php if(($code_niveau==1)&&($code_cycle==1)){ echo '<a href="'.$chemin.'Admin/releve_note.php?code='.$code.'&annee='.$code_annee.'">'.$annee."/".($annee+1).'</a>';}else{ echo $annee."/".($annee+1); }?></label>
								</td>
								<td>
									<label for="ident"><?php echo $des_option.' ('.$sys.')';?></label>
								</td>
								<td>
									<label for="ident"><?php echo $des_niveau;?></label>
								</td>
								<td>
									<label for="ident"><?php echo $des_cycle;?></label>
								</td>
								<td>
									<label for="ident"><a href=<?php echo '"modif_inscription.php?code_etudiant='.$code.'&code_annee_univ='.$code_annee.'"';?>><img src="IMG/modifie_icone.png"></img></a><a href=<?php echo '"supp.php?type=inscription&code='.$code.'|'.$code_annee.'"';?>><img src="IMG/supp_icone.png"></img></a></label>
								</td>
							</tr>
						<?php
									
								}
								}
							}else if($option=='mem'){
							$num_mem=mysql_num_rows(mysql_query("SELECT * FROM `memoire` WHERE `code_etudiant`=\"$code\" ORDER BY `date_debut_travaux` DESC",$id_user));
							$resultat=mysql_query("SELECT * FROM `memoire` WHERE `code_etudiant`=\"$code\" ORDER BY `date_debut_travaux` DESC",$id_user);
							?>
			<div id="corp_page">
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des �tudiants</a> > <a>Informations sur un(e) �tudiant(e)</a></p>
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> <a href=<?php echo "info_etudiant.php?code=".$code;?>>Informations sur les m�moires pr�par�s par <?php echo $nom." ".$prenom." (".$num_mem.")"; ?> </a></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
				<fieldset> 
					<p style="text-indent:0px;">
					Pour ajouter un m�moire � l'�tudiant(e) clickez sur : <a href=<?php echo '"ajout_memoire.php?code_etudiant='.$code.'"';?>><input type="button" value="Ajouter un m�moire � l'�tudiant(e)" class="bouton_form"/></a>
					</p>
					
							<?php
								if(!(mysql_num_rows($resultat))){
								echo '<div align="center">'.etudiant::get_msg_erreur(7).'</div>';
								}else{
							?>
							<table class="affichage_table">
							<thead class="entete_tableau">
							<th>Intitule m�moire</th>
							<th>Promoteur</th>
							<th>Co promoteur</th>
							<th>Date soutenance</th>
							<th>Action</th>
							</thead>
							<?php
								$class="paire";
									while($tab=mysql_fetch_assoc($resultat)){
									$code_pro=$tab['code_promoteur'];
									$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code_pro\""));
									$pro=$result['nom_enseignant']." ".$result['prenom_enseignant'];
									$code_co_pro=$tab['code_co_promoteur'];
										if($code_co_pro<>''){
										$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code_ens\""));
										$copro=$result['nom_enseignant']." ".$result['prenom_enseignant'];
										}
									?>
						<tr class=<?php echo "tableau_ligne_".$class;?>>
							<td><?php echo '<a href="info_memoire.php?code='.$tab['code_memoire'].'">'.extraire_chaine($tab['intitule_memoire'],35).'</a>';?></td>
							<td><?php echo '<a href="info_enseignant.php?code='.$code_pro.'">'.$pro.'</a>';?></td>
							<td><?php if(isset($co_pro)){ echo'<a href="info_enseignant.php?code='.$code_co_pro.'">'.$copro.'</a>';}?></td>
							<td><?php if($tab['date_effective']<>''){ echo 'a soutenu le: '.adapter_date($tab['date_effective']);}else if($tab['date_prevue']<>''){ echo 'pr�vue pour le: '.adapter_date($tab['date_prevue']);}else{ echo 'avant le: '.adapter_date($tab['date_delai_soutenance']);}?></td>
							<td><a href=<?php echo "modif_memoire.php?code=".$tab['code_memoire'];?>><img src="IMG/modifie_icone.png"></img></a><a href=<?php echo "supp.php?type=memoire&code=".$tab['code_memoire'];?>><img src="IMG/supp_icone.png"></img></a></td>
						</tr>
									<?php
										if($class=="paire"){
										$class=="impaire";
										}else{
										$class=="paire";
										}
									}
								}
							}else if($option=='dip'){
							$num_dip=mysql_num_rows(mysql_query("SELECT * FROM `diplome` WHERE `code_etudiant`=\"$code\"",$id_user));
							$resultat=mysql_query("SELECT * FROM `diplome` WHERE `code_etudiant`=\"$code\" ORDER BY `date_obtention` DESC",$id_user);
							?>
				<div id="corp_page">
				<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des �tudiants</a> > <a>Informations sur un(e) �tudiant(e)</a></p>
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> <a href=<?php echo "info_etudiant.php?code=".$code;?>>Informations sur les dipl�mes de <?php echo $nom." ".$prenom." (".$num_dip.")"; ?> </a></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
				<fieldset>
					<p style="text-indent:0px;">
					Pour ajouter un dipl�me � l'�tudiant(e) clickez sur : <a href=<?php echo '"ajout_diplome.php?code='.$code.'"';?>><input type="button" value="Ajouter un dipl�me � l'�tudiant(e)" class="bouton_form"/></a>
					</p>
					
							<?php
								if(mysql_num_rows($resultat)){
								?>
								<table class="affichage_table">
							<thead class="entete_tableau">
							<th>Nature du dipl�me</th>
							<th>Option</th>
							<th>Date d'obtention</th>
							<th>Action</th>
							</thead>
								<?php
									$class="paire";
									while($tab=mysql_fetch_assoc($resultat)){
									$code_cycle=$tab['code_cycle'];
									$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `inscription` WHERE `code_etudiant`=\"$code\" AND `code_cycle`=\"$code_cycle\" ORDER BY `date_inscription` DESC"));
									$code_option=$tab2['code_option'];
									$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$code_option\"",$id_user));
									$des=$tab2['designation_option'].'('.$tab2['systeme_option'].')';
									$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `cycle` WHERE `code_cycle`=\"$code_cycle\""));
								?>
							<tr class=<?php echo "tableau_ligne_".$class;?>>
							<td><?php echo $tab2['designation_cycle'];?></td>
							<td><?php echo $des;?></td>
							<td><?php echo adapter_date($tab['date_obtention']);?></td>
							<td><a href=<?php echo "modif_diplome.php?code=".$tab['code_diplome'];?>><img src="IMG/modifie_icone.png"></img></a><a href=<?php echo "supp.php?type=diplome&code=".$tab['code_diplome'];?>><img src="IMG/supp_icone.png"></img></a></td>
						</tr>
							<?php
										if($class=="paire"){
										$class=="impaire";
										}else{
										$class=="paire";
										}
									}
								}else{
								echo '<div align="center">'.etudiant::get_msg_erreur(8).'</div>';
								}
							}else{
							echo '<div id="corp_page"><div align="left">Erreur !';
							}
						}
					?>
					</table>
					</fieldset>
				</div>
			<?php if((!(isset($option)))){ echo '</div>'; }?>
		</div>
		<?php 
				}else{
				echo '<div id="corp_page">'.etudiant::get_msg_erreur(4).'</div>';
				}
			}else{
			echo '<div id="corp_page">'.etudiant::get_msg_erreur(0).'</div>';
			}
		}else{
		echo '<div id="corp_page">'.autentif::get_msg_acces().'</div>';
		}
		include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
