<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des �tudiants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if((isset($id_user))&&(($level=="222")||($level="333"))){
			$acces=true;
			if(isset($_GET['code'])){
			$ancien_code=$_GET['code'];
				if(mysql_num_rows(mysql_query("SELECT `code_etudiant` FROM `etudiant` WHERE `code_etudiant` =\"$ancien_code\""))){
					if((isset($_POST['code_etudiant']))&&(isset($_POST['nom_etudiant']))&&(isset($_POST['prenom_etudiant']))&&(isset($_POST['date_naiss_etudiant']))&&(isset($_POST['lieu_naiss_etudiant']))&&(isset($_POST['adresse_etudiant']))&&(isset($_POST['nationalite_etudiant']))&&(isset($_POST['diplome_acces_etudiant']))&&(isset($_POST['labo_rech_etudiant']))){
					$code=$_POST['code_etudiant'];
					$nom=$_POST['nom_etudiant'];
					$prenom=$_POST['prenom_etudiant'];
					$dn=$_POST['date_naiss_etudiant'];
					$lieu=$_POST['lieu_naiss_etudiant'];
					$adresse=$_POST['adresse_etudiant'];
					$nationalite=$_POST['nationalite_etudiant'];
					$diplome=$_POST['diplome_acces_etudiant'];
					$labo=$_POST['labo_rech_etudiant'];
						if(($code<>'')&&($nom<>'')&&($prenom<>'')&&($dn<>'')&&($lieu<>'')&&($adresse<>'')&&($nationalite<>'')&&($diplome<>'')){
							if(($ancien_code==$code)||(!(mysql_num_rows(mysql_query("SELECT `code_etudiant` FROM `etudiant` WHERE `code_etudiant` =\"$code()\""))))){	
								$jj=substr($dn,0,2);	$mm=substr($dn,3,2);	$aa=substr($dn,6,4);
								if(@checkdate($mm,$jj,$aa)){
								@mysql_query("UPDATE `ed2c`.`etudiant` SET `code_etudiant` = \"$code\",`nom_etudiant` = \"$nom\",`prenom_etudiant` = \"$prenom\",`date_naiss_etudiant` = \"$dn\",`lieu_naiss_etudiant` = \"$lieu\",
								`adresse_etudiant` = \"$adresse\",`nationalite_etudiant` = \"$nationalite\",`diplome_acces_etudiant` = \"$diplome\",`labo_rech_etudiant` = \"$labo\" WHERE `etudiant`.`code_etudiant` = \"$ancien_code\";",$id_user);
								$err=false;
								echo etudiant::get_msg_modif();
								}else{
								echo formulaire::get_msg(2);
								include("formulaire_etudiant.php");
								// date incorrect (recharger page avec infos dans formulaire)
								}
							}else{
							echo etudiant::get_msg_erreur(1);
							// code_etudiant deja existant dans la base
							}
						}else{
						echo formulaire::get_msg(1);
						//il manque des infos (recharger page avec infos dans formulaire)
						}
					}else{
					echo formulaire::get_msg(0);
					$code=$_GET['code'];
					$resultat=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant` =\"$code\""));
					$nom=$resultat['nom_etudiant'];
					$prenom=$resultat['prenom_etudiant'];
					$dn=$resultat['date_naiss_etudiant'];
					$lieu=$resultat['lieu_naiss_etudiant'];
					$adresse=$resultat['adresse_etudiant'];
					$nationalite=$resultat['nationalite_etudiant'];
					$diplome=$resultat['diplome_acces_etudiant'];
					$labo=$resultat['labo_rech_etudiant'];
					// afficher le formulaire avec les infos de la base ($ancien_code)
					}
				}else{
				echo etudiant::get_msg_erreur(4);
				$err=false;
				// code_etudiant existe pas dans la base
				}
			}else{
			echo etudiant::get_msg_erreur(0);
			$err=false;
			//l'etudiant n'a pas ete choisie
			}
		}else{
		echo autentif::get_msg_acces();
		$acces=false;
		// acces refus�e
		}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des �tudiants</a> > <a>Modifier un(e) �tudiant(e)</a></p> 
		<form action=<?php echo '"modif_etudiant.php?code='.$code.'"'; ?> method="post" class="formulaire" >
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Modifier l'�tudiant(e) <?php echo @$nom." ".@$prenom;?></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Matricule (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="code_etudiant" value=<?php if(isset($code)&&($code<>'')){ echo $code;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="nom_etudiant" value=<?php if(isset($nom)&&($nom<>'')){ echo $nom;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="prenom_etudiant" value=<?php if(isset($prenom)&&($prenom<>'')){ echo $prenom;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date de naissance (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="10" name="date_naiss_etudiant" value=<?php if(isset($dn)&&($dn<>'')){ echo $dn;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Lieu de naissance (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="lieu_naiss_etudiant" value=<?php if(isset($lieu)&&($lieu<>'')){ echo $lieu;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
									<label for="ident">Adresse (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="30" name="adresse_etudiant" value=<?php if(isset($adresse)&&($adresse<>'')){ echo $adresse;}else{ echo '""'; }?> class="champ_form" />
								</td>
								<tr>
								<td class="case_gauche">
									<label for="ident">Nationalit� (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="nationalite_etudiant" value=<?php if(isset($nationalite)&&($nationalite<>'')){ echo $nationalite;}else{ echo '"Alg�rienne"'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Dipl�me d�acc�s (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="diplome_acces_etudiant" value=<?php if(isset($diplome)&&($diplome<>'')){ echo $diplome;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Laboratoire de recherche :</label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="30" name="labo_rech_etudiant" value=<?php if(isset($labo)&&($labo<>'')){ echo $labo;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
								</td>
								<td class="case_droite">
									<input type="submit" value="Modifier" class="bouton_form"/>
									<input type="reset" value="Effacer" class="bouton_form"/>
								</td>
							</tr>
						</table>
					</fieldset>
				</div>
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>