<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Modifier une news </title>
<?php 
$chemin = "../";
$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin)?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin)?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin)?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin)?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin)?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin)?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin)?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php 
		include($chemin."entete.php");
		include($chemin."menu_ver.php"); 
		function adapter_datetime($dat_heur){
			$jj = substr($dat_heur, 8, 2);
			$mm = substr($dat_heur, 5, 2);
			$aa = substr($dat_heur, 0, 4);
			$min = substr($dat_heur, -5, 2);
			$h = substr($dat_heur, -8, 2);
			return "Modif�e le ".$jj."/".$mm."/".$aa." � ".$h.":".$min;
		}
		mysql_connect("localhost", "ed2c_level_3", "6ubReBncfU9yp9vZ"); 
		mysql_select_db("ed2c");
		
		if(isset($_POST['titre']) AND isset($_POST['contenu'])){
			if(($_POST['titre'] != NULL) AND ($_POST['contenu'] != NULL)){
				$titre_news = mysql_real_escape_string(htmlspecialchars($_POST['titre']));
				$contenu_news = mysql_real_escape_string(htmlspecialchars($_POST['contenu']));
				$date_heure = date('y-m-d h:i:s');
				$contenu_news=$contenu_news.'...'.adapter_datetime($date_heure);
				if(isset($_GET['num_news'])){
					$num_news = $_GET['num_news'];
				}
				mysql_query("UPDATE news SET titre_news='$titre_news', enonce_news='$contenu_news' WHERE code_news='$num_news'");
				echo '<p class="confirmation"> Confirmation: La news est modifi�e!</p>';
			} 
			else{
				echo '<p class="erreur"> Erreur: Vous devez remplir les deux champs ci-desous!</p>';
			}
			if(isset($_GET['num_news'])){
				$num_news = $_GET['num_news'];
			}
			$reponse = mysql_query("SELECT * from news WHERE code_news = '$num_news'");	
			while($news = mysql_fetch_array($reponse)){
		?> 	
		<div id="corp_page">
			<form action="modifier_news.php?num_news=<?php echo '$num_news';?>" method="post" id="form_news">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Modification d'une news </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu" id="formulaire_news_contenu">
					<fieldset> 
						<label for="ident">Titre de la news : </label><br/>
							<input type="text" value="<?php echo $news['titre_news'];?>" size="50" name="titre" class="champ_form" /><br/>
						<label for="ident">Contenu : </label></br>
							<textarea rows="20" cols="100" name="contenu" class="champ_form" id="contenu_news">
								<?php echo $news['enonce_news'];?>
							</textarea><br/>
						<input type="submit" value="Modifier" class="bouton_form"/>
						<input type="reset" value="Effacer" class="bouton_form"/>
					</fieldset>
				</div>
			</form>
		</div>
		<?php		
		}
		mysql_close();
		}else{
			if(isset($_GET['num_news'])){
				$num_news = $_GET['num_news'];
			}
			$reponse = mysql_query("SELECT * from news WHERE code_news='$num_news'");	
			while($news = mysql_fetch_array($reponse)){
			?> 	
			<div id="corp_page">
				<form action="modifier_news.php?num_news=<?php echo $num_news;?>" method="post" id="form_news">
					<div class="titre_formulaire">
						<div class="titre_form_cgauche"></div>
						<div class="titre_form_text"> Modification d'une news </div>
						<div class="titre_form_cdroite"></div>
					</div>
					<div class="formulaire_contenu" id="formulaire_news_contenu">
						<fieldset> 
								<label for="ident">Titre de la news : </label><br/>
									<input type="text" value="<?php echo $news['titre_news'];?>" size="50" name="titre" class="champ_form" /><br/>
								<label for="ident">Contenu : </label></br>
									<textarea rows="20" cols="100" name="contenu" class="champ_form" id="contenu_news"><?php echo $news['enonce_news'];?></textarea><br/>
								<input type="submit" value="Modifier" class="bouton_form"/>
								<input type="reset" value="Effacer" class="bouton_form"/>
						</fieldset>
					</div>
				</form>
			</div>
		<?php
			}
		mysql_close();
		}
		include($chemin."pied_page.php");
		?>
	</div>
</body>
</html>
