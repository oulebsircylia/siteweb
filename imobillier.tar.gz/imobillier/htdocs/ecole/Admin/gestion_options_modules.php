<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des options/modules </title>
<?php 
$chemin = "../";
$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php"); ?>
		<?php include($chemin."menu_ver.php");
		include($chemin."msg.php");
		include($chemin."acces.php");
		?>
		<div id="corp_page">
		
		<?php
			if(isset($id_user)&&(($level=="222")||($level=="333"))){
		?>
		<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des Options/Modules</a></p> 
			<p style="text-indent:0px;">
				Pour ajouter une nouvelle option clickez sur : <a href="ajout_option_module.php?type=option"><input type="button" value="Ajouter une option" class="bouton_form"/></a>
			</p>
			<p style="text-indent:0px;">
				Pour ajouter un nouveau module clickez sur : <a href="ajout_option_module.php?type=module"><input type="button" value="Ajouter un module" class="bouton_form"/></a>
			</p>
			<p style="text-indent:0px;">
				Pour inclure un module dans une option clickez sur : <a href="ajout_inclusion.php"><input type="button" value="Ajouter une inclusion" class="bouton_form"/></a>
			</p>
			<table class="affichage_table">
						 <thead class="entete_tableau">
						    <tr>
								<th>Option</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody> 
							<?php 
								$bool = true; 
								$resultat=mysql_query("SELECT * FROM `option` ORDER BY `designation_option` ASC",$id_user);
								while ($tab = mysql_fetch_array($resultat)){
								if($bool){
									echo '<tr class="tableau_ligne_paire">';
								}else{
									echo'<tr class="tableau_ligne_impaire">';
								
								}
								$bool = !$bool;
								?>
								<td>
									<?php echo $tab['designation_option'].' ('.$tab['systeme_option'].')';?>
								</td>
								<td>
								<a href=<?php echo "modif_option_module.php?type=option&code=".$tab['code_option'];?>><img src="IMG/modifie_icone.png"/></a>
								<a href=<?php echo "supp.php?type=option&code=".$tab['code_option'];?>><img src="IMG/supp_icone.png"/></a>
								</td>
							</tr>
						<?php };?>	
						</tbody>
				</table>
				<br />
			<table class="affichage_table">
						 <thead class="entete_tableau">
						    <tr>
								<th>Module</th>
								<th>Actions</th>
								<th>Inclusion</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody> 
							<?php 
								$bool = true; 
								$resultat=mysql_query("SELECT * FROM `module` ORDER BY `designation_module` ASC");
								while ($tab = mysql_fetch_array($resultat)){
								$code_module=$tab['code_module'];
								if($bool){
									echo '<tr class="tableau_ligne_paire">';
								}else{
									echo'<tr class="tableau_ligne_impaire">';
								
								}
								$bool = !$bool;
								?>
								<td>
									<?php echo $tab['designation_module'];?>
								</td>
								<td>
								<a href=<?php echo "modif_option_module.php?type=module&code=".$code_module;?>><img src="IMG/modifie_icone.png"/></a>
								<a href=<?php echo "supp.php?type=module&code=".$code_module;?>><img src="IMG/supp_icone.png"/></a>
								</td>
								<td>
									<?php
										$result=mysql_query("SELECT * FROM `inclusion` WHERE `code_module`=\"$code_module\"");
										while($tab2=mysql_fetch_array($result)){
										$code_option=$tab2['code_option'];
										$tab3=mysql_fetch_array(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$code_option\""));
										echo $tab3['designation_option'].' ('.$tab3['systeme_option'].')'.'</br>';
										}
									?>
								</td>
								<td>
								<?php
										$result=mysql_query("SELECT * FROM `inclusion` WHERE `code_module`=\"$code_module\"");
										while($tab2=mysql_fetch_array($result)){
										$code_option=$tab2['code_option'];
										$tab3=mysql_fetch_array(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$code_option\""));
								?>
										<a href=<?php echo "modif_inclusion.php?code_option=".$tab3['code_option'].'&code_module='.$code_module;?>><img src="IMG/modifie_icone.png"/></a>
										<a href=<?php echo "supp.php?type=inclusion&code=".$tab3['code_option'].'|'.$code_module;?>><img src="IMG/supp_icone.png"/></a>
										<?php echo '</br>';?>
									<?php }?>
								</td>
							</tr>
						<?php } mysql_close();?>	
						</tbody>
				</table>
		<?php 
			}else{
			echo autentif::get_msg_acces();
			}
		?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
