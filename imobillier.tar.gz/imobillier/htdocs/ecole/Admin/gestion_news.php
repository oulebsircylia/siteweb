<?php 
function adapter_datetime($dat_heur){
	$jj = substr($dat_heur, 8, 2);
	$mm = substr($dat_heur, 5, 2);
	$aa = substr($dat_heur, 0, 4);
	$min = substr($dat_heur, -5, 2);
	$h = substr($dat_heur, -8, 2); 
	return $jj."/".$mm."/".$aa." - ".$h.":".$min;
}

function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	$chaineResultat=substr($chaine, 0, $val);
	if(strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}	
	
		mysql_connect("localhost", "ed2c_level_3", "6ubReBncfU9yp9vZ"); 
		mysql_select_db("ed2c");
	
   		$rep_pages = mysql_query("SELECT COUNT(*) AS nbr from news ");
		if ((isset($_GET['page']))AND(isset($_GET['d_affiche']))AND(isset($_GET['n_page']))){
			$page_affiche = $_GET['page'];
			$debut_affiche = $_GET['d_affiche'];
			$num_page = $_GET['n_page'];
		}else{
			$page_affiche = 'prem';	
			$debut_affiche = 0;
			$num_page = 1;
		}
		
		$req_pages = mysql_fetch_array($rep_pages);
		$nombre_tuplets = $req_pages['nbr'];
		$nombre_pages = $nombre_tuplets/15;
	
		if (round($nombre_pages)-$nombre_pages<0){
			$nombre_pages = round($nombre_pages)+1;
		}else{
			$nombre_pages = round($nombre_pages);
		}
	
		switch($page_affiche){
		case 'prem':{	
					$num_page = 1;
					$debut_affiche = 0;
		}break;
		case 'prec':{
					$debut_affiche = $debut_affiche - 15; 
					$num_page--;
					if($debut_affiche<0){
						$debut_affiche = 0;
						$num_page = 1;
					}
				}break;
		case 'suiv':{
					$num_page++;
					$debut_affiche = $debut_affiche + 15; 
					if($debut_affiche > $nombre_tuplets){
						$debut_affiche = $debut_affiche-15;
						$num_page--;
					}
				}break;
		case 'dern':{
					$debut_affiche = $nombre_tuplets-($nombre_tuplets % 15);
					$num_page = $nombre_pages;
				}break;
		}
		$reponse = mysql_query("SELECT code_news, titre_news, date_heure_ajout from news ORDER BY code_news LIMIT ".$debut_affiche.", 15");
	
?>	
			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Liste de toutes les news </title>
<?php
	$chemin = "../";
	$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site">
		<?php include($chemin."entete.php");?>
		<?php include($chemin."menu_ver.php");?>
		 	<div id="corp_page">
				<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des news</a> > </p> 
				<p style="test-indent:0px;">Pour ajouter une news cliquz sur: 
					<a href="<?php echo $chemin.'Admin/ajout_news.php'?>"><input type="submit" value="Ajouter une news" class="bouton_form"/></a>
				</p>
				<p style="text-indent:0px;">La liste de toutes les news :</p>
				<div class="avant_tableau">
					<form class="boite_gauche">
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=prem&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" << " class="bouton_form"/></a>
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=prec&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" < " class="bouton_form"/></a>
							<Caption> page: </Caption>
							<?php 
								echo($num_page." / ".$nombre_pages.' ');
							?>
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=suiv&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" > " class="bouton_form"/></a>
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=dern&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" >> " class="bouton_form"/></a>	
					</form>
					<form action="recherche.php" method="post" class="boite_droite">
						<input type="text" size="20" value="Rechercher"  name="mots_recherche" class="champ_form" />
						<label for="pays">Dans : </label>
						<select name="rech" id="rech" class="champ_form">
							<option value="titres" select="selected">Titres</option>
							<!--<option value="enonces">Enonc�s</option>-->
						</select>
						<input type="submit" value="Rechercher" class="bouton_form"/>
						<input type="hidden" name="rech_dans" value="news">
						<input type="hidden" name="champ" value="titre_news">
					</form>
				</div>
				<table class="affichage_table">
						<thead class="entete_tableau">
						    <tr>
								<th>Titre</th>
								<th>Date d'ajout</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody> 
						<?php $bool = true;
						while ($news = mysql_fetch_array($reponse)){?>	 
							<?php if($bool){
							?>
								<tr class="tableau_ligne_paire">
							<?php }else{
							?>
								<tr class="tableau_ligne_impaire">
							<?php }
								$bool = !$bool;
							?>
								<td>
									<?php
										echo "<a href=\"../afficher_news.php?num_news=".$news['code_news']."\">";
										echo extraire_chaine($news['titre_news'],60);
										echo "</a>";
									?>
								</td>
								<td>
									<?php 
										echo adapter_datetime($news['date_heure_ajout']);
									?>
								</td>
								<td> 
									<?php
										echo '<a href="../afficher_news.php?num_news='.$news['code_news'].'" title=\"Voir cette news">';
									?>
										<img src="IMG/apercu_icone.png"/>
									<?php 
										echo '</a><a href="modifier_news.php?num_news='.$news['code_news'].'" title="Modifier cette news">';
									?>
										<img src="IMG/modifie_icone.png"/>
									<?php 
										echo '</a><a href="" title="Supprimer cette news">';
									?>
										<img src="IMG/supp_icone.png"/></a>
									<?php "</a>"?>
								</td>
							</tr>
						<?php } mysql_close();?>	
						</tbody>
				</table>	
				<div class="apres_tableau">
					<form class="boite_gauche">
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=prem&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" << " class="bouton_form"/></a>
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=prec&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" < " class="bouton_form"/></a>
							<Caption> page: </Caption>
							<?php 
								echo($num_page." / ".$nombre_pages.' ');
							?>
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=suiv&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" > " class="bouton_form"/></a>
							<a href="<?php echo "$chemin"."Admin/gestion_news.php?page=dern&amp;d_affiche=$debut_affiche&amp;n_page=$num_page";?>"><input type="button" value=" >> " class="bouton_form"/></a>	
					</form>
				</div>
			</div>
		<?php include ($chemin."pied_page.php"); ?>
	</div>
</body>
</html>