<?php 
$chemin = "../";
$page_courante = "administration";
function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	//$nombre_de_ln=0;
	$chaineResultat=substr($chaine, 0, $val);
	if (strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}
include($chemin."acces.php");

?>
			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Liste de toutes les news </title>
<?php 
$chemin = "../";
$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php") ?>
		 	<div id="corp_page">
			<?php
				if(isset($id_user)){
					if(mysql_num_rows(mysql_query("SELECT * FROM `memoire`"))){
					$result=mysql_query("SELECT * FROM `memoire` ORDER BY `intitule_memoire`");
			?>	
			<p style="text-indent:0px;">
				Pour ajouter un nouveau m�moire clisquez sur : <a href="ajout_memoire.php"><input type="button" value="Ajouter un m�moire" class="bouton_form"/></a>
			</p>
				<h1>Liste des m�moires :</h1>
				<table class="affichage_table">
						 <thead class="entete_tableau">
						    <tr>
								<th>Titre</th>
								<th>Nature</th>
								<th>Etudiant</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
						<?php $bool = true; while ($tab = mysql_fetch_array($result)){?>	 
							<?php if($bool){
							?>
								<tr class="tableau_ligne_paire">
							<?php }else{
							?>
								<tr class="tableau_ligne_impaire">
							<?php }
								$bool = !$bool;
							?>
								<td>
									<?php
										echo '<a href="info_memoire.php?code='.$tab['code_memoire'].'">'.$tab['intitule_memoire'].'</a>';
									?>
								</td>
								<td>
									<?php
										echo $tab['nature_memoire'];
									?>
								</td>
								<td>
									<?php
										$code_etudiant=$tab['code_etudiant'];
										$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code_etudiant\""));
										echo '<a href="info_etudiant.php?code='.$code_etudiant.'">'.$tab2['nom_etudiant']." ".$tab2['prenom_etudiant'].'</a>';
										
									?>
								</td>
								<td> 
									
									<?php
										//echo "<a href=\"../".$news['URL_news']."\" title=\"Voir cette news\">";
									?>
										<a href=<?php echo '"info_memoire.php?code='.$tab['code_memoire'].'"';?>><img src="IMG/apercu_icone.png"/></a>
									<?php 
										//echo "</a><a href=\"\" title=\"Modifier cette news\">"
									?>
										<a href=<?php echo '"modif_memoire.php?code='.$tab['code_memoire'].'"';?>><img src="IMG/modifie_icone.png"/></a>
									<?php 
										//echo "</a><a href=\"\" title=\"Supprimer cette news\">"
									?>
										<a href=<?php echo '"supp.php?type=memoire&code='.$tab['code_memoire'].'"';?>><img src="IMG/supp_icone.png"/></a>
									<?php
										//echo "<a href=\"../".$news['URL_news']."\" title=\"Voir cette news\">";
									?>
										<a href=<?php echo '"download_memoire.php?code='.$tab['code_memoire'].'"';?>><img src="IMG/download_icone.png"/>
								</td>
							</tr>
						<?php } mysql_close();?>	
						</tbody>
				</table>	
					<?php
						}else{
						echo '<div class="confirmation">Aucun m�moire trouv� .</div>';
						}
					}else{
					echo autentif::get_msg_acces();
					}
					?>
			</div>	
		<?php include ($chemin."pied_page.php") ?>
	</div>
</body>
</html>