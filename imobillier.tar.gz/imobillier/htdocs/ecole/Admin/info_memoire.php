<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des memoires </title>
<?php 
$chemin = "../";
$page_courante = "administration";
function adapter_date($date){
	$jj = substr($date, 8, 2);
	$mm = substr($date, 5, 2);
	$aa = substr($date, 0, 4);
	return $jj."/".$mm."/".$aa;
}
function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	//$nombre_de_ln=0;
	$chaineResultat=substr($chaine, 0, $val);
	if (strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}	
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php");
		include($chemin."msg.php");
		include($chemin."acces.php");
		if(isset($id_user)){
			if(isset($_GET['code'])){
			$code=$_GET['code'];
				if(mysql_num_rows(mysql_query("SELECT * FROM `memoire` WHERE `code_memoire`=\"$code\"",$id_user))){
				$resultat=mysql_query("SELECT * FROM `memoire` WHERE `code_memoire`=\"$code\"",$id_user);
				$tab=mysql_fetch_assoc($resultat);
				$intitule=$tab['intitule_memoire'];
				$nature=$tab['nature_memoire'];
				$mots_cles=$tab['mots_cles_memoire'];
				$resume=$tab['resume_memoire'];
				$date_debut=$tab['date_debut_travaux'];
				$date_delai=$tab['date_delai_soutenance'];
				$date_prevue=$tab['date_prevue'];
				$date_effective=$tab['date_effective'];
				$mention=$tab['mention_memoire'];
				$note=$tab['note_memoire'];
				$decision=$tab['decision_jury'];
				$code_etudiant=$tab['code_etudiant'];
				$code_pro=$tab['code_promoteur'];
				$code_co_pro=$tab['code_co_promoteur'];
				$resultat=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code_etudiant\"",$id_user));
				$etudiant=$resultat['nom_etudiant']." ".$resultat['prenom_etudiant'];
				$resultat=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code_pro\"",$id_user));
				$promoteur=$resultat['nom_enseignant']." ".$resultat['prenom_enseignant'];
					if($code_co_pro<>''){
					$resultat=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code_co_pro\"",$id_user));
					$copromoteur=$resultat['nom_enseignant']." ".$resultat['prenom_enseignant'];
					}
		?>
			<div id="corp_page">
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des m�moires</a> > <a>Informations sur un m�moire</a></p> 
			<div class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Informations sur un m�moire </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�par� par : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo '<a href="info_etudiant.php?code='.$code_etudiant.'">'.$etudiant.'</a>';?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Promoteur : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo '<a href="info_enseignant.php?code='.$code_pro.'">'.$promoteur.'</a>';?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Co promoteur: </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if(!(isset($copromoteur))){ echo champ::get_msg_vide(); }else{ echo '<a href="info_enseignant.php?code='.$code_co_pro.'">'.$copromoteur.'</a>';;};?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Intitul�: </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $intitule;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nature : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $nature;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Mots cl�s : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $mots_cles;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">R�sum� : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $resume;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date de d�but de travaux : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo adapter_date($date_debut);?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date d�lai de soutenance : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo adapter_date($date_delai);?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date pr�vue soutenance : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if($date_prevue==''){ echo champ::get_msg_vide(); }else{ echo adapter_date($date_prevue);}//?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date effective soutenance : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if($date_effective==''){ echo champ::get_msg_vide(); }else{ echo adapter_date($date_effective);}?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Mention : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if($mention==''){ echo champ::get_msg_vide(); }else{echo $mention;}?></label>
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
									<label for="ident">Note : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if($note==''){ echo champ::get_msg_vide(); }else{echo $note;}?></label>
								</td>
								<tr>
								<td class="case_gauche">
									<label for="ident">D�cision du jury : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php if($decision==''){ echo champ::get_msg_vide(); }else{echo $decision;}?></label>
								</td>
							</tr>
						</table>
					</fieldset>
					</div>
					<p>Liste des jury</p>
					<?php
						if(mysql_num_rows(mysql_query("SELECT * FROM `jury` WHERE `code_memoire`=\"$code\""))){
						$result=mysql_query("SELECT * FROM `jury` WHERE `code_memoire`=\"$code\"");
						?>
						<table class="affichage_table">
							<thead class="entete_tableau">
							<th>Nom et Pr�nom</th>
							<th>N� jury</th>
							<th>Action</th>
							</thead>
						<?php
						$class="paire";
							while($tab=mysql_fetch_assoc($result)){
							$code_ens=$tab['code_enseignant'];
							$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code_ens\""));
							
						?>
						<tr class="tableau_ligne_<?php echo $class.'"';?>>
						<td><?php echo '<a href="info_enseignant.php?code='.$code_ens.'">'.$tab2['nom_enseignant']." ".$tab2['prenom_enseignant'].'</a>';?></td>
						<td><?php echo $tab['numero_jury'];?></td>
						<td><a href=<?php echo "modif_jury.php?code_jury=".$tab['code_enseignant'].'&code_memoire='.$tab['code_memoire'];?>><img src="IMG/modifie_icone.png"></img></a><a href=<?php echo "supp.php?type=jury&code=".$tab['code_enseignant'].'|'.$tab['code_memoire'];?>><img src="IMG/supp_icone.png"></img></a></td></td>
						</tr>
						<?php
										if($class=="paire"){
										$class=="impaire";
										}else{
										$class=="paire";
										}
							}
						?>
						</table>
						<?php
						}else{
						?>
						<div class="erreur">Aucun jury trouv� .</div>
						<?php
						}
					?>
	</div>
	</div>
		<?php 
				}else{
				echo '<div id="corp_page">'.memoire::get_msg_erreur(3).'</div>';
				}
			}else{
			echo '<div id="corp_page">'.memoire::get_msg_erreur(0).'</div>';
			}
		}else{
		echo '<div id="corp_page">'.autentif::get_msg_acces().'</div>';
		}
		include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
