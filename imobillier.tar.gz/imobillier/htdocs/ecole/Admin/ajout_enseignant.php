<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des enseignants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");		?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
			<?php 
			$err=true;
			if((isset($id_user))&&(($level=="222")||($level="333"))){
			$acces=true;
			if((isset($_POST['code_enseignant']))&&(isset($_POST['nom_enseignant']))&&(isset($_POST['prenom_enseignant']))&&(isset($_POST['grade_enseignant']))&&(isset($_POST['lieu_exercice_enseignant']))){
			$code=$_POST['code_enseignant'];
			$nom=$_POST['nom_enseignant'];
			$prenom=$_POST['prenom_enseignant'];
			$grade=$_POST['grade_enseignant'];
			$lieu=$_POST['lieu_exercice_enseignant'];
				if(($code<>'')&&($nom<>'')&&($prenom<>'')&&($grade<>'')&&($lieu<>'')){
					if(!(mysql_num_rows(mysql_query("SELECT `code_enseignant` FROM `enseignant` WHERE `code_enseignant` =\"$code\"",$id_user)))){
						mysql_query("INSERT INTO `ed2c`.`enseignant` (`code_enseignant` ,`nom_enseignant` ,`prenom_enseignant` ,`grade_enseignant` ,`lieu_exercice_enseignant` )
						VALUES (\"$code\", \"$nom\", \"$prenom\", \"$grade\", \"$lieu\");",$id_user);
						echo enseignant::get_msg_ajout($nom,$prenom);
						$err=false;
					}else{
					echo enseignant::get_msg_erreur(1);
					//code_enseignant deja existant dans la base
					}
				}else{
				echo formulaire::get_msg(1);
				//il manque des infos (recharger page avec infos dans formulaire)
				}
			}else{
			echo formulaire::get_msg(0);
			// afficher le formulaire vide
			}
		}else{
		echo autentif::get_msg_acces();
		$acces=false;
		// acces refus�e
		}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des enseignants</a> > <a>Ajouter un(e) enseignant(e)</a></p> 
		<form action="ajout_enseignant.php" method="post" class="formulaire" >
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Ajouter un(e) enseignant(e) </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Matricule (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="code_enseignant" value=<?php if(isset($_POST['code_enseignant'])&&($_POST['code_enseignant']<>'')){ echo $_POST['code_enseignant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="nom_enseignant" value=<?php if(isset($_POST['nom_enseignant'])&&($_POST['nom_enseignant']<>'')){ echo $_POST['nom_enseignant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="prenom_enseignant" value=<?php if(isset($_POST['prenom_enseignant'])&&($_POST['prenom_enseignant']<>'')){ echo $_POST['prenom_enseignant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Grade (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="grade_enseignant" value=<?php if(isset($_POST['grade_enseignant'])&&($_POST['grade_enseignant']<>'')){ echo $_POST['grade_enseignant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Lieu d'exercice (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="lieu_exercice_enseignant" value=<?php if(isset($_POST['lieu_exercice_enseignant'])&&($_POST['lieu_exercice_enseignant']<>'')){ echo $_POST['lieu_exercice_enseignant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
								</td>
								<td class="case_droite">
									<input type="submit" value="Ajouter" class="bouton_form"/>
									<input type="reset" value="Effacer" class="bouton_form"/>
								</td>
							</tr>
						</table>
					</fieldset>
				</div>
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>