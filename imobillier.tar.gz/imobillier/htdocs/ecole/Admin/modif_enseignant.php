<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des enseignants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if((isset($id_user))&&(($level=="222")||($level="333"))){
			$acces=true;
			if(isset($_GET['code'])){
			$ancien_code=$_GET['code'];
				if(mysql_num_rows(mysql_query("SELECT `code_enseignant` FROM `enseignant` WHERE `code_enseignant` =\"$ancien_code\""))){
					if((isset($_POST['code_enseignant']))&&(isset($_POST['nom_enseignant']))&&(isset($_POST['prenom_enseignant']))&&(isset($_POST['grade_enseignant']))&&(isset($_POST['lieu_exercice_enseignant']))){
					$code=$_POST['code_enseignant'];
					$nom=$_POST['nom_enseignant'];
					$prenom=$_POST['prenom_enseignant'];
					$grade=$_POST['grade_enseignant'];
					$lieu=$_POST['lieu_exercice_enseignant'];
						if(($code<>'')&&($nom<>'')&&($prenom<>'')&&($grade<>'')&&($lieu<>'')){
							if(($ancien_code==$code)||(!(mysql_num_rows(mysql_query("SELECT `code_enseignant` FROM `enseignant` WHERE `code_enseignant` =\"$code()\""))))){
								@mysql_query("UPDATE `ed2c`.`enseignant` SET `code_enseignant` = \"$code\",`nom_enseignant` = \"$nom\",`prenom_enseignant` = \"$prenom\",`grade_enseignant` = \"$grade\",`lieu_exercice_enseignant` = \"$lieu\"
								WHERE `enseignant`.`code_enseignant` = \"$ancien_code\";",$id_user);
								$err=false;
								echo enseignant::get_msg_modif();
							}else{
							echo enseignant::get_msg_erreur(1);
							// code_enseignant deja existant dans la base
							}
						}else{
						echo formulaire::get_msg(1);
						//il manque des infos (recharger page avec infos dans formulaire)
						}
					}else{
					echo formulaire::get_msg(0);
					$code=$_GET['code'];
					$resultat=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant` =\"$code\""));
					$nom=$resultat['nom_enseignant'];
					$prenom=$resultat['prenom_enseignant'];
					$grade=$resultat['grade_enseignant'];
					$lieu=$resultat['lieu_exercice_enseignant'];
					// afficher le formulaire avec les infos de la base ($ancien_code)
					}
				}else{
				echo enseignant::get_msg_erreur(4);
				$err=false;
				// code_enseignant existe pas dans la base
				}
			}else{
			echo enseignant::get_msg_erreur(0);
			$err=false;
			//l'enseignant n'a pas ete choisie
			}
		}else{
		echo autentif::get_msg_acces();
		$acces=false;
		// acces refus�e
		}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des enseignants</a> > <a>Modifier un(e) enseignant(e)</a></p> 
		<form action=<?php echo '"modif_enseignant.php?code='.$code.'"'; ?> method="post" class="formulaire" >
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Modifier l'enseignant(e) <?php echo @$nom." ".@$prenom;?></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Matricule (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="code_enseignant" value=<?php if(isset($code)&&($code<>'')){ echo $code;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="nom_enseignant" value=<?php if(isset($nom)&&($nom<>'')){ echo $nom;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="prenom_enseignant" value=<?php if(isset($prenom)&&($prenom<>'')){ echo $prenom;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Grade (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="10" name="grade_enseignant" value=<?php if(isset($grade)&&($grade<>'')){ echo $grade;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Lieu d'exercice (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="lieu_exercice_enseignant" value=<?php if(isset($lieu)&&($lieu<>'')){ echo '"'.$lieu.'"';}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
								</td>
								<td class="case_droite">
									<input type="submit" value="Modifier" class="bouton_form"/>
									<input type="reset" value="Effacer" class="bouton_form"/>
								</td>
							</tr>
						</table>
					</fieldset>
				</div>
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>