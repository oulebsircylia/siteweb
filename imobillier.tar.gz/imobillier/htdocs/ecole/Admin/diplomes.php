<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Liste des dipl�mes </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
function adapter_date($date){
	$jj = substr($date, 8, 2);
	$mm = substr($date, 5, 2);
	$aa = substr($date, 0, 4);
	return $jj."/".$mm."/".$aa;
}
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
			<?php 
			if(isset($id_user)){?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Listes des dipl�mes</a></p> 
			<?php
			@session_start();
				if(isset($_SESSION['code_annee_univ'])){
				$code_annee=$_SESSION['code_annee_univ'];
				$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `annee_univ` WHERE `code_annee_univ`=\"$code_annee\""));
				$annee_debut=$result['annee_debut'];
				$result=mysql_query("SELECT * FROM `diplome` WHERE year( `date_obtention` )= '".($annee_debut+1)."'");
					if(mysql_num_rows($result)){
			?>
			<table class="affichage_table">
						<thead class="entete_tableau">
						<th>Obtenu par</th>
						<th>Option</th>
						<th>le</th>
						<th>Nature dipl�me</th>
						<th>Action</th>
						</thead>
						<?php
						$class="paire";
						while($tab=mysql_fetch_assoc($result)){
						$code_etudiant=$tab['code_etudiant'];
						$code_cycle=$tab['code_cycle'];
						$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code_etudiant\""));
						$nom=$tab2['nom_etudiant'];
						$prenom=$tab2['prenom_etudiant'];
						$code_cycle=$tab['code_cycle'];
						$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `cycle` WHERE `code_cycle`=\"$code_cycle\""));
						$nature=$tab2['designation_cycle'];
						$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `inscription` WHERE `code_etudiant`=\"$code_etudiant\" AND `code_cycle`=\"$code_cycle\" ORDER BY `date_inscription` DESC"));
						$code_option=$tab2['code_option'];
						$tab2=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$code_option\"",$id_user));
						$option=$tab2['designation_option'].'('.$tab2['systeme_option'].')';
						?>
						<tr class=<?php echo "tableau_ligne_".$class;?>>
							<td><?php echo '<a href="info_etudiant.php?code='.$code_etudiant.'">'.$nom." ".$prenom.'</a>';?></td>
							<td><?php echo $option;?></td>
							<td><?php echo adapter_date($tab['date_obtention']);?></td>
							<td><?php echo $nature;?></td>
							<td><a href=<?php echo "modif_diplome.php?code=".$tab['code_diplome'];?>><img src="IMG/modifie_icone.png"></img></a><a href=<?php echo "supp.php?type=diplome&code=".$tab['code_diplome'];?>><img src="IMG/supp_icone.png"></img></a></td>
						</tr>
				<?php	
								if($class=="paire"){
								$class=="impaire";
								}else{
								$class=="paire";
								}
						} ?>
			</table>
			<?php
					}else{
					echo etudiant::get_msg_erreur(8);
					}
				}else{
				echo '<div class="erreur">'."Vous n'avez pas encore selectionn� une ann�e universitaire de travail.</div>";
				}
			}else{
			echo autentif::get_msg_acces();
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
