<?php 

function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	//$nombre_de_ln=0;
	$chaineResultat=substr($chaine, 0, $val);
	if (strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}
				
	mysql_connect("localhost", "ed2c_level_3", "6ubReBncfU9yp9vZ"); 
	mysql_select_db("ed2c");
	$reponse = mysql_query("SELECT * from news ORDER BY code_news DESC LIMIT 30 ");

?>
			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des m�moires </title>
<?php 
$chemin = "../";
$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php") ?>
		 	<div id="corp_page">
				<p style="text-indent:0px;">
					Pour voir, modifier ou supprimer un m�moire faites une recherche : 
				</p>
				<form action="recherche.php" method="post" class="formulaire">
						<div class="titre_formulaire">
							<div class="titre_form_cgauche"></div>
							<div class="titre_form_text"> Rechercher un m�moire </div>					
							<div class="titre_form_cdroite"></div>
						</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<input type="text" size="20" name="mots_recherche" class="champ_form" />
						<label for="pays">Par : </label>
							<select name="champ" class="champ_form">
								<option value="intitule_memoire" select="selected">Intitul� </option>
								<option value="nature_memoire">Nature </option>
								<option value="mots_cles_memoire">Mots cl�s </option>
							</select>
							<input type="submit" value="Rechercher" class="bouton_form"/>
							<input type="hidden" name="rech_dans" value="memoire">
					</fieldset>
				</div>
			</form>				
			</div>	
		<?php include ($chemin."pied_page.php") ?>
	</div>
</body>
</html>