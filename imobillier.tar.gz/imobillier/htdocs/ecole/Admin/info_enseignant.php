<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des enseignants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
function adapter_date($date){
	$jj = substr($date, 8, 2);
	$mm = substr($date, 5, 2);
	$aa = substr($date, 0, 4);
	return $jj."/".$mm."/".$aa;
}
function extraire_chaine($chaine, $val){
	$i = 0;
	$chaineResultat="";
	//$nombre_de_ln=0;
	$chaineResultat=substr($chaine, 0, $val);
	if (strlen($chaine)>$val){
		while($chaine[$i]!=' '){
			$chaineResultat = $chaineResultat.$chaine[$i];
			$i++;
		}
		$chaineResultat=$chaineResultat."... ";
	}
	return $chaineResultat;
}	
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php");
		include($chemin."msg.php");
		include($chemin."acces.php");
		if(isset($id_user)){
			if(isset($_GET['code'])){
			$code=$_GET['code'];
			$resultat=mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code\"",$id_user);
				if(mysql_num_rows($resultat)){
					if(!(isset($_GET['option']))){
					$tab=mysql_fetch_assoc($resultat);
					$nom=$tab['nom_enseignant'];
					$prenom=$tab['prenom_enseignant'];
					$grade=$tab['grade_enseignant'];
					$lieu=$tab['lieu_exercice_enseignant'];
					$nb_promoteur=mysql_num_rows(mysql_query("SELECT * FROM `memoire` WHERE `code_promoteur`=\"$code\"",$id_user));
					$nb_co_promoteur=mysql_num_rows(mysql_query("SELECT * FROM `memoire` WHERE `code_co_promoteur`=\"$code\"",$id_user));
					$nb_jury=mysql_num_rows(mysql_query("SELECT * FROM `jury` WHERE `code_enseignant`=\"$code\"",$id_user));
		?>
			<div id="corp_page">
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des enseignants</a> > <a>Informations sur un(e) enseignant(e)</a></p> 
			<div class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Informations sur un(e) enseignant(e) </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Code : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $code;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nom : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $nom;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�nom : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $prenom;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Grade : </label>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $grade;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Lieu d'exercice : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo $lieu;?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nombre de m�moire assur�s : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo ($nb_promoteur+$nb_co_promoteur+$nb_jury);?></label>
								</td>
							</tr>
							<tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">- en tant que promoteur : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo '<a href="info_enseignant.php?code='.$code.'&option=pro">'.$nb_promoteur.'</a>';?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">- en tant que co-promoteur : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo '<a href="info_enseignant.php?code='.$code.'&option=co">'.$nb_co_promoteur.'</a>';?></label>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">- en tant que jury : </label><br/>
								</td>
								<td class="case_droite">
									<label for="ident"><?php echo '<a href="info_enseignant.php?code='.$code.'&option=jury">'.$nb_jury.'</a>'?></label>
								</td>
							</tr>							
						</table>
					</fieldset>
				</div>
		</div>
	</div>
		<?php 
					}else{
						$option=$_GET['option'];
						$tab=mysql_fetch_assoc($resultat);
					?>
		<div id="corp_page">
		<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des enseignants</a> > <a>Informations sur un(e) enseignant(e)</a></p> 
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> <a href=<?php echo "info_enseignant.php?code=".$code;?>>Informations sur les m�moires assur�s par <?php echo $tab['nom_enseignant']." ".$tab['prenom_enseignant'].' en tant que ';switch($option){ case 'pro':echo 'promoteur';break; case 'co':echo 'co promoteur';break; case 'jury':echo 'jury';break; }?></a></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset>
					<p style="text-indent:0px;">
					<?php switch($option){
					case 'pro':?>
					Pour ajouter l'enseignant(e) en tant que promoteur clicker sur : <a href=<?php echo '"ajout_memoire.php?code_promoteur='.$code.'"';?>><input type="button" value="Ajouter en tant que promoteur" class="bouton_form"/></a>
					<?php break;
					case 'co':?>
					Pour ajouter l'enseignant(e) en tant que co promoteur clicker sur : <a href=<?php echo '"ajout_memoire.php?code_co_promoteur='.$code.'"';?>><input type="button" value="Ajouter en tant que co promoteur" class="bouton_form"/></a>
					<?php break;
					case 'jury':?>
					Pour ajouter l'enseignant(e) en tant que jury clicker sur : <a href=<?php echo '"ajout_jury.php?code='.$code.'"';?>><input type="button" value="Ajouter en tant que jury" class="bouton_form"/></a>
					
						<?php
						break;
						?>
					</p>
					<?php
						}
						switch($option){
						case 'pro':$resultat=mysql_query("SELECT * FROM `memoire` WHERE `code_promoteur`=\"$code\"",$id_user);
						break;
						case 'co':$resultat=mysql_query("SELECT * FROM `memoire` WHERE `code_co_promoteur`=\"$code\"",$id_user);
						break;
						case 'jury':$resultat=mysql_query("SELECT * FROM `jury`,`memoire` WHERE `jury`.`code_enseignant`=\"$code\" AND `jury`.`code_memoire`=`memoire`.`code_memoire`",$id_user);
						break;
						}
						if(mysql_num_rows($resultat)){
						?>
						<table class="affichage_table">
						<thead class="entete_tableau">
						<th>Intitule m�moire</th>
						<th>Pr�par� par</th>
						<th>Date soutenance</th>
						<th>Action</th>
						<?php if($option=='jury'){?><th>N� jury</th><?php } ?>
						</thead>
						<?php
							$class="paire";
							while($tab=mysql_fetch_assoc($resultat)){
							$code_etudiant=$tab['code_etudiant'];
							$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code_etudiant\""));
							$etudiant=$result['nom_etudiant']." ".$result['prenom_etudiant'];
						?>
						<tr class=<?php echo "tableau_ligne_".$class;?>>
							<td><?php echo '<a href="info_memoire.php?code='.$tab['code_memoire'].'">'.extraire_chaine($tab['intitule_memoire'],35).'</a>';?></td>
							<td><?php echo '<a href="info_etudiant.php?code='.$code_etudiant.'">'.$etudiant.'</a>';?></td>
							<td><?php if($tab['date_effective']<>''){ echo 'a soutenu le: '.adapter_date($tab['date_effective']);}else if($tab['date_prevue']<>''){ echo 'pr�vue pour le: '.adapter_date($tab['date_prevue']);}else{ echo 'avant le: '.adapter_date($tab['date_delai_soutenance']);}?></td>
							<td><a href=<?php echo "modif_memoire.php?code=".$tab['code_memoire'];?>><img src="IMG/modifie_icone.png"></img></a><a href=<?php echo "supp.php?type=memoire&code=".$tab['code_memoire'];?>><img src="IMG/supp_icone.png"></img></a></td>
							<?php if($option=='jury'){ echo '<td>'.$tab['numero_jury'].'</td>'; } ?>
						</tr>
					<?php	
								if($class=="paire"){
								$class=="impaire";
								}else{
								$class=="paire";
								}
							}?>
					
				<?php	}else{
						echo '<div align="center">'.etudiant::get_msg_erreur(7).'</div>';
						}?>
					</table>
					</fieldset>
				</div>
		</div>	
		<?php
					}
				}else{
				echo '<div id="corp_page">'.enseignant::get_msg_erreur(4).'</div>';
				}
			}else{
			echo '<div id="corp_page">'.enseignant::get_msg_erreur(0).'</div>';
			}
		}else{
		echo '<div id="corp_page">'.autentif::get_msg_acces().'</div>';
		}
		include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
