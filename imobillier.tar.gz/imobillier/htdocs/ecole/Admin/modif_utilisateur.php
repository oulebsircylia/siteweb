<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des utilisateurs </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if(isset($id_user)&&($level=="333")){
			$acces=true;
			if(isset($_GET['user'])){
			$old_user=$_GET['user'];
			$old_user_c=crypter($_GET['user'],$key,$iv);
			if((mysql_num_rows(mysql_query("SELECT `user` FROM `users` WHERE `user`=\"$old_user_c\"")))){
			$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `user`=\"$old_user_c\""));
			$user_d=decrypter($result['user'],$key,$iv);
								$l_iv=$result['user'];
								if(strlen($l_iv)>8){
								$l_iv=strsub($l_iv,0,8);
								}else{
									while(strlen($l_iv)<8){
									$l_iv=$l_iv.'x';
									}
								}
				$level_d=decrypter($result['level'],$key,$l_iv);
				if(isset($_POST['id'])&&isset($_POST['password'])&&isset($_POST['confirm_pwd'])&&isset($_POST['level'])){
					if(($_POST['id']<>'')&&($_POST['password']<>'')&&($_POST['confirm_pwd']<>'')){
						if($_POST['password']==$_POST['confirm_pwd']){
						$user=$_POST['id'];
						$user_c=crypter($_POST['id'],$key,$iv);
							if(($user_d==$user)||(!mysql_num_rows(mysql_query("SELECT `user` FROM `users` WHERE `user`=\"$user_c\"")))){
							$password=md5($_POST['password']);
							$l_iv=$user_c;
								if(strlen($l_iv)>8){
								$l_iv=strsub($l_iv,0,8);
								}else{
									while(strlen($l_iv)<8){
									$l_iv=$l_iv.'x';
									}
								}
							$level=crypter($_POST['level'],$key,$l_iv);
							$t=mysql_query("UPDATE `users` SET `user` = \"$user_c\" , `password` = \"$password\" , `level` = \"$level\" WHERE `user` = \"$old_user_c\";",$id_user);
							echo user::get_msg_modif($user);
							$err=false;
							}else{
							echo user::get_msg_erreur(0);
							}
						}else{
						echo formulaire::get_msg(3);
						}
					}else{
					echo formulaire::get_msg(1);
					}
				}else{
				echo formulaire::get_msg(0);
				}
			}else{
			$err=false;
			echo user::get_msg_erreur(1);
			}
			}else{
			$err=false;
			echo user::get_msg_erreur(2);
			}
			}else{
			$acces=false;
			echo autentif::get_msg_acces();
			}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des utilisateurs</a> > <a>Modifier un utilisateur</a></p> 
		<form action=<?php echo "modif_utilisateur.php?user=".$old_user; ?> method="post" id="form_ajout_utilisateur" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Modifier l'utilisateur <?php echo $user_d." (Niveau ".$level_d[0].")";?></div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Identifiant (*) :</label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="id" class="champ_form" value=<?php if(isset($_POST['id'])){ echo $_POST['id'];}else if(isset($result)){ echo $user_d; }else{ echo '""';} ?> />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Mot de passe (*) :</label>
								</td>
								<td class="case_droite">
									<input type="password" size="20" name="password" class="champ_form"/>		
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Confirmation mot de passe (*) :</label>
								</td>
								<td class="case_droite">
									<input type="password" size="20" name="confirm_pwd" class="champ_form"/>		
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="pays">Niveau (*) : </label></td>
								<td class="case_droite">
										<select name="level" class="champ_form">
											<option value="111" select="selected">Niveau 1 </option>
											<option value="222">Niveau 2 </option>
											<option value="333">Niveau 3 </option>
										</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
								</td>
								<td class="case_droite">
									<a href=""><input type="submit" value="Modifier" class="bouton_form"/></a>	
									<a href=""><input type="reset" value="Effacer" class="bouton_form"/></a>	
								</td>
							</tr>
						</table>
					</fieldset>
				</div>	
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>