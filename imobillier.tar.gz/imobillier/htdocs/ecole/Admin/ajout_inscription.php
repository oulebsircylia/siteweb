<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des inscriptions </title>
<?php 
$chemin = "../";
$page_courante = "administration";

include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if(isset($id_user)&&($level=="333")){
			$acces=true;
			if(isset($_GET['code'])){
			$code=$_GET['code'];
			$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code\"",$id_user));
			$nom=$result['nom_etudiant'];
			$prenom=$result['prenom_etudiant'];
				if(mysql_num_rows(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code\""))){
				if(isset($_POST['date_inscription'])&&isset($_POST['code_annee'])&&isset($_POST['code_option'])&&isset($_POST['code_niveau'])&&isset($_POST['code_cycle'])){
					$annee=$_POST['code_annee'];
					$option=$_POST['code_option'];
					$niveau=$_POST['code_niveau'];
					$cycle=$_POST['code_cycle'];
					$date=$_POST['date_inscription'];
						if(($annee<>'')&&($date<>'')){
						$jj=substr($date,0,2);	$mm=substr($date,3,2);	$aa=substr($date,6,4);
						if(@checkdate($mm,$jj,$aa)){
						$date=$aa.'-'.$mm.'-'.$jj;
						mysql_query("INSERT INTO `inscription` (`code_etudiant`,`code_annee_univ`,`code_option`,`code_niveau`,`code_cycle`,`date_inscription`) VALUES (\"$code\",\"$annee\",\"$option\",\"$niveau\",\"$cycle\",\"$date\");",$id_user);
						$err=false;
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$option\"",$id_user));
						$op=$result['designation_option'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `niveau` WHERE `code_niveau`=\"$niveau\"",$id_user));
						$ni=$result['designation_niveau'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `cycle` WHERE `code_cycle`=\"$cycle\"",$id_user));
						$cy=$result['designation_cycle'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `annee_univ` WHERE `code_annee_univ`=\"$annee\"",$id_user));
						$an=$result['annee_debut'];
						echo insc::get_msg_ajout_inscr($nom,$prenom,$an,$op,$ni,$cy);
						}else{
						echo formulaire::get_msg(2);
						}
						}else{
						echo formulaire::get_msg(1);
						}
				}else{
				echo formulaire::get_msg(0);
				}
				}else{
				$err=false;
				}
			}else{
			$err=false;
			}
			}else{
			$acces=false;
			}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des inscriptions</a> > <a>Ajouter une inscription</a></p> 
		<form action="ajout_inscription.php?code=<?php echo $code; ?>" method="post" id="form_ajout_utilisateur" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Inscrire l'�tudiant(e) <?php echo $nom." ".$prenom;?> dans une nouvelle ann�e universitaire</div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Ann�e univeristaire (*) :</label>
								</td>
								<td class="case_droite">
								<select name="code_annee" class="champ_form">
									<?php
								$result=(mysql_query("SELECT * FROM `annee_univ` WHERE `code_annee_univ` NOT IN (SELECT `code_annee_univ` FROM `inscription` WHERE `code_etudiant`=\"$code\")"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_annee_univ'].'">'.$tab['annee_debut'].'/'.($tab['annee_debut']+1).'</option>';
									}
								?>
								</select>
								</td>
							</tr>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Option (*) :</label>
								</td>
								<td class="case_droite">
								<select name="code_option" class="champ_form">
								<?php
								$result=(mysql_query("SELECT * FROM `option` ORDER BY `designation_option`"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_option'].'">'.$tab['designation_option'].'('.$tab['systeme_option'].')</option>';
									}
								?>
								</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Niveau (*) :</label>
								</td>
								<td class="case_droite">
								<select name="code_niveau" class="champ_form">
								<?php
								$result=(mysql_query("SELECT * FROM `niveau` ORDER BY `designation_niveau`"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_niveau'].'">'.$tab['designation_niveau'].'</option>';
									}
								?>
								</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Cycle (*) :</label>
								</td>
								<td class="case_droite">
								<select name="code_cycle" class="champ_form">
								<?php
								$result=(mysql_query("SELECT * FROM `cycle` ORDER BY `code_cycle`"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_cycle'].'">'.$tab['designation_cycle'].'</option>';
									}
								?>
								</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date d'inscription (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="10" name="date_inscription" value=<?php if(isset($date)&&($date<>'')){ echo $date;}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
								</td>
								<td class="case_droite">
									<a href=""><input type="submit" value="Ajouter" class="bouton_form"/></a>	
									<a href=""><input type="reset" value="Effacer" class="bouton_form"/></a>	
								</td>
							</tr>
						</table>
					</fieldset>
				</div>	
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>