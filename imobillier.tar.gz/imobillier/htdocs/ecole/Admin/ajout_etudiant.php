<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des �tudiants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");		?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if((isset($id_user))&&(($level=="222")||($level="333"))){
			$acces=true;
			echo '<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des �tudiants</a> > <a>Ajouter un(e) �tudiant(e)</a></p>';
			if((isset($_POST['code_etudiant']))&&(isset($_POST['nom_etudiant']))&&(isset($_POST['prenom_etudiant']))&&(isset($_POST['date_naiss_etudiant']))&&(isset($_POST['lieu_naiss_etudiant']))&&(isset($_POST['adresse_etudiant']))&&(isset($_POST['nationalite_etudiant']))&&(isset($_POST['diplome_acces_etudiant']))&&(isset($_POST['labo_rech_etudiant']))){
			$code=$_POST['code_etudiant'];
			$nom=$_POST['nom_etudiant'];
			$prenom=$_POST['prenom_etudiant'];
			$dn=$_POST['date_naiss_etudiant'];
			$lieu=$_POST['lieu_naiss_etudiant'];
			$adresse=$_POST['adresse_etudiant'];
			$nationalite=$_POST['nationalite_etudiant'];
			$diplome=$_POST['diplome_acces_etudiant'];
			$labo=$_POST['labo_rech_etudiant'];
				if(($code<>'')&&($nom<>'')&&($prenom<>'')&&($dn<>'')&&($lieu<>'')&&($adresse<>'')&&($nationalite<>'')&&($diplome<>'')){
					if(!(mysql_num_rows(mysql_query("SELECT `code_etudiant` FROM `etudiant` WHERE `code_etudiant` =\"$code\"",$id_user)))){
						$jj=substr($dn,0,2);	$mm=substr($dn,3,2);	$aa=substr($dn,6,4);
						if(@checkdate($mm,$jj,$aa)){
						$date=$aa.'-'.$mm.'-'.$jj;
						mysql_query("INSERT INTO `ed2c`.`etudiant` (`code_etudiant` ,`nom_etudiant` ,`prenom_etudiant` ,`date_naiss_etudiant` ,`lieu_naiss_etudiant` ,`adresse_etudiant` ,`nationalite_etudiant` ,`diplome_acces_etudiant` ,`labo_rech_etudiant`)
						VALUES (\"$code\", \"$nom\", \"$prenom\", \"$date\", \"$lieu\", \"$adresse\", \"$nationalite\", \"$diplome\", \"$labo\");",$id_user);
						echo etudiant::get_msg_ajout($nom,$prenom);
						$err=false;
						}else{
						echo formulaire::get_msg(2);
						//date incorrect (recharger page avec infos dans formulaire)
						}
					}else{
					echo etudiant::get_msg_erreur(1);
					//code_etudiant deja existant dans la base
					}
				}else{
				echo formulaire::get_msg(1);
				//il manque des infos (recharger page avec infos dans formulaire)
				}
			}else{
			echo formulaire::get_msg(0);
			// afficher le formulaire vide
			}
		}else{
		echo autentif::get_msg_acces();
		$acces=false;
		// acces refus�e
		}
			if(($acces)&&($err)){
			?>
		<form action="ajout_etudiant.php" method="post" class="formulaire" >
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Ajouter un(e) �tudiant(e) </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Matricule (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="code_etudiant" value=<?php if(isset($_POST['code_etudiant'])&&($_POST['code_etudiant']<>'')){ echo $_POST['code_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="nom_etudiant" value=<?php if(isset($_POST['nom_etudiant'])&&($_POST['nom_etudiant']<>'')){ echo $_POST['nom_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Pr�nom (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="prenom_etudiant" value=<?php if(isset($_POST['prenom_etudiant'])&&($_POST['prenom_etudiant']<>'')){ echo $_POST['prenom_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Date de naissance (*) : </label>
								</td>
								<td class="case_droite">
									<input type="text" size="10" name="date_naiss_etudiant" value=<?php if(isset($_POST['date_naiss_etudiant'])&&($_POST['date_naiss_etudiant']<>'')){ echo $_POST['date_naiss_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Lieu de naissance (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="lieu_naiss_etudiant" value=<?php if(isset($_POST['lieu_naiss_etudiant'])&&($_POST['lieu_naiss_etudiant']<>'')){ echo $_POST['lieu_naiss_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
									<label for="ident">Adresse (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="30" name="adresse_etudiant" value=<?php if(isset($_POST['adresse_etudiant'])&&($_POST['adresse_etudiant']<>'')){ echo $_POST['adresse_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
								<tr>
								<td class="case_gauche">
									<label for="ident">Nationalit� (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="nationalite_etudiant" value=<?php if(isset($_POST['nationalite_etudiant'])&&($_POST['nationalite_etudiant']<>'')){ echo $_POST['nationalite_etudiant'];}else{ echo '"Alg�rienne"'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Dipl�me d�acc�s (*) : </label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="diplome_acces_etudiant" value=<?php if(isset($_POST['diplome_acces_etudiant'])&&($_POST['diplome_acces_etudiant']<>'')){ echo $_POST['diplome_acces_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Laboratoire de recherche :</label><br/>
								</td>
								<td class="case_droite">
									<input type="text" size="30" name="labo_rech_etudiant" value=<?php if(isset($_POST['labo_rech_etudiant'])&&($_POST['labo_rech_etudiant']<>'')){ echo $_POST['labo_rech_etudiant'];}else{ echo '""'; }?> class="champ_form" />
								</td>
							</tr>
							<tr class="case_gauche">
								<td>
								</td>
								<td class="case_droite">
									<input type="submit" value="Ajouter" class="bouton_form"/>
									<input type="reset" value="Effacer" class="bouton_form"/>
								</td>
							</tr>
						</table>
					</fieldset>
				</div>
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>