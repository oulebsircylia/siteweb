<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des etudiants </title>
<?php 
$chemin = "../";
$page_courante = "administration";
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
			<p style="text-indent:0px;">
				Pour ajouter un nouveau �tudiant(e) clisquez sur : <a href="ajout_etudiant.php"><input type="button" value="Ajouter un �tudiant(e)" class="bouton_form"/></a>
			</p>
			<p style="text-indent:0px;">
				Pour voir, modifier ou supprimer un �tudiant(e) faites une recherche : 
			</p>
			<form action="recherche.php" method="post" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Rechercher un �tudiant(e) </div>					
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<input type="text" size="20" name="mots_recherche" class="champ_form" />
						<label for="pays">Par : </label>
							<select name="champ" class="champ_form">
								<option value="code_etudiant" select="selected">Matricule </option>
								<option value="nom_etudiant">Nom </option>
								<option value="prenom_etudiant">Pr�nom </option>
							</select>
							<input type="submit" value="Rechercher" class="bouton_form"/>
							<input type="hidden" name="rech_dans" value="etudiant">
					</fieldset>
				</div>
			</form>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
