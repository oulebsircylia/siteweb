<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des utilisateurs </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."acces.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
				<?php if(isset($id_user)&&($level=="333")){
				$reponse = mysql_query("SELECT * from users ORDER BY user DESC LIMIT 20 ");
				?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des utilisateurs</a></p> 
			<p style="text-indent:0px;">
				Pour ajouter un nouveau utilisateur clickez sur : <a href="ajout_utilisateur.php"><input type="button" value="Ajouter utilisateur" class="bouton_form"/></a>
			</p>
			<table class="affichage_table">
						 <thead class="entete_tableau">
						    <tr>
								<th>Utilisateur</th>
								<th>Privil�ge</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody> 
							<?php 
								$bool = true; 
								while ($utilisateur = mysql_fetch_array($reponse)){
								if($bool){
									echo '<tr class="tableau_ligne_paire">';
								}else{
									echo'<tr class="tableau_ligne_impaire">';
								
								}
								$bool = !$bool;
								?>
								
								<td>
									<?php
										$user=decrypter($utilisateur['user'],$key,$iv);
										echo $user;
									?>
								</td>
								<td>
									<?php
										$liv=$utilisateur['user'];
										if(strlen($liv)>8){
										$liv=strsub($liv,0,8);
										}else{
										while(strlen($liv)<8){
										$liv=$liv.'x';
										}
										}
										$level=decrypter($utilisateur['level'],$key,$liv);
										echo "Niveau ".$level[0];
									?>
								</td>
								<td> 
										<a href=<?php echo "modif_utilisateur.php?user=".$user;?>><img src="IMG/modifie_icone.png"/></a>
										<a href=<?php echo "supp.php?type=user&code=".$user;?>><img src="IMG/supp_icone.png"/></a>
								</td>
							</tr>
						<?php } mysql_close();?>	
						</tbody>
				</table>
				<?php }else{
				include($chemin."msg.php");
				echo autentif::get_msg_acces();
				}?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>
