<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Suppression </title>
<?php 
$chemin = "../";
$page_courante = "administration";
include($chemin."msg.php");
include($chemin."acces.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php") ?>
		<?php include($chemin."menu_ver.php");
			if((isset($id_user))&&(($level=="222")||($level=="333"))){
				if((isset($_GET['type']))&&(isset($_GET['code']))){
					switch ($_GET['type']){
						case 'user':
						$code=crypter($_GET['code'],$key,$iv);
						$query="SELECT * FROM `users` WHERE `user`='".$code."'";
						$result=mysql_fetch_assoc(mysql_query($query));
						@$user=$result['user'];
						@$user_d=decrypter($result['user'],$key,$iv);
						$query_del[0]="DELETE FROM `ed2c`.`users` WHERE `users`.`user` = '".$code."'";
						@$msg=supp::get_msg_avert(0,$user_d);
						@$msg_confirm=supp::get_msg(0,$user_d);
						@$msg_erreur=user::get_msg_erreur(1);
						break;
						case 'etudiant':
						$code=$_GET['code'];
						$query="SELECT * FROM `etudiant` WHERE `code_etudiant`='".$code."'";
						$result=@mysql_fetch_assoc(mysql_query($query));
						@$etudiant=$result['nom_etudiant']." ".$result['prenom_etudiant'];
						$query_del[0]="DELETE FROM `ed2c`.`etudiant` WHERE `etudiant`.`code_etudiant` = '".$code."'";
						$query_del[1]="DELETE FROM `ed2c`.`memoire` WHERE `memoire`.`code_etudiant` = '".$code."'";
						$query_del[2]="DELETE FROM `ed2c`.`inscription` WHERE `inscription`.`code_etudiant` = '".$code."'";
						$query_del[3]="DELETE FROM `ed2c`.`diplome` WHERE `diplome`.`code_etudiant` = '".$code."'";
						$query_del[4]="DELETE FROM `ed2c`.`note` WHERE `note`.`code_etudiant` = '".$code."'";
						@$msg=supp::get_msg_avert(1,$etudiant);
						@$msg_confirm=supp::get_msg(1,$etudiant);
						@$msg_erreur=etudiant::get_msg_erreur(4);;
						break;
						case 'enseignant':
						$code=$_GET['code'];
						$query="SELECT * FROM `enseignant` WHERE `code_enseignant`='".$code."'";
						$result=@mysql_fetch_assoc(mysql_query($query));
						@$enseignant=$result['nom_enseignant']." ".$result['prenom_enseignant'];
						$query_del[0]="DELETE FROM `ed2c`.`enseignant` WHERE `enseignant`.`code_enseignant` = '".$code."'";
						$query_del[1]="DELETE FROM `ed2c`.`memoire` WHERE `memoire`.`code_promoteur` = '".$code."'";
						$query_del[2]="DELETE FROM `ed2c`.`memoire` WHERE `memoire`.`code_co_promoteur` = '".$code."'";
						$query_del[3]="DELETE FROM `ed2c`.`jury` WHERE `jury`.`code_enseignant` = '".$code."'";
						@$msg=supp::get_msg_avert(2,$enseignant);
						@$msg_confirm=supp::get_msg(2,$enseignant);
						@$msg_erreur=enseignant::get_msg_erreur(4);;
						break;
						case 'memoire':
						$code=$_GET['code'];
						$query="SELECT * FROM `memoire` WHERE `code_memoire`='".$code."'";
						$result=@mysql_fetch_assoc(mysql_query($query));
						@$memoire=$result['intitule_memoire'];
						$query_del[0]="DELETE FROM `ed2c`.`memoire` WHERE `memoire`.`code_memoire` = '".$code."'";
						$query_del[1]="DELETE FROM `ed2c`.`prorogation` WHERE `prorogation`.`code_memoire` = '".$code."'";
						$query_del[2]="DELETE FROM `ed2c`.`jury` WHERE `jury`.`code_memoire` = '".$code."'";
						@$msg=supp::get_msg_avert(3,$memoire);
						@$msg_confirm=supp::get_msg(3,$memoire);
						@$msg_erreur=memoire::get_msg_erreur(3);
						break;
						case 'inscription':
						$code=$_GET['code'];
							$i=0;
							while(($code[$i]<>'|')&&($i<strlen($code))){
							$i++;
							}
						$code_etudiant=substr($code,0,$i);
						$code_annee=substr($code,$i+1,strlen($code)-1-strlen($code_etudiant));
						$query="SELECT * FROM `inscription` WHERE `code_etudiant`='".$code_etudiant."' AND `code_annee_univ`='".$code_annee."'";
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code_etudiant\""));
						@$nom=$result['nom_etudiant'];
						@$prenom=$result['prenom_etudiant'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `annee_univ` WHERE `code_annee_univ`=\"$code_annee\""));
						@$annee_debut=$result['annee_debut'];
						$result=@mysql_fetch_assoc(mysql_query($query));
						$query_del[0]="DELETE FROM `ed2c`.`inscription` WHERE `inscription`.`code_etudiant` = '".$code_etudiant."' AND `code_annee_univ`='".$code_annee."'";
						$query_del[1]="DELETE FROM `ed2c`.`note` WHERE `note`.`code_etudiant` = '".$code_etudiant."' AND `code_annee_univ`='".$code_annee."'";
						@$msg=supp::get_msg_avert(4,($nom." ".$prenom." dans l'ann�e universitaire ".$annee_debut."/".($annee_debut+1)));
						@$msg_confirm=supp::get_msg(4,($nom." ".$prenom." dans l'ann�e universitaire ".$annee_debut."/".($annee_debut+1)));
						@$msg_erreur=insc::get_msg_erreur(0);;
						break;
						case 'jury':
						$code=$_GET['code'];
							$i=0;
							while(($code[$i]<>'|')&&($i<strlen($code))){
							$i++;
							}
						$code_ens=substr($code,0,$i);
						$code_mem=substr($code,$i+1,strlen($code)-1-strlen($code_ens));
						$query="SELECT * FROM `jury` WHERE `code_enseignant`='".$code_ens."' AND `code_memoire`=".$code_mem;
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `enseignant` WHERE `code_enseignant`=\"$code_ens\""));
						@$nom=$result['nom_enseignant'];
						@$prenom=$result['prenom_enseignant'];
						$result=@mysql_fetch_assoc(mysql_query($query));
						$tab=mysql_fetch_assoc(mysql_query("SELECT * FROM `memoire` WHERE `code_memoire`=".$code_mem));
						@$memoire=$tab['intitule_memoire'];
						$query_del[0]="DELETE FROM `ed2c`.`jury` WHERE `jury`.`code_enseignant` = '".$code_ens."' AND `code_memoire`='".$code_mem."'";
						@$msg=supp::get_msg_avert(5,($nom." ".$prenom." en tant que membre du jury du m�moire ".$memoire));
						@$msg_confirm=supp::get_msg(5,($nom." ".$prenom." (en tant que membre du jury du m�moire ".$memoire.")"));
						@$msg_erreur=jury::get_msg_erreur(0);;
						break;
						case 'news':
						$code=$_GET['code'];
						$query="SELECT * FROM `news` WHERE `code_news`='".$code."'";
						$result=mysql_fetch_assoc(mysql_query($query));
						@$titre=$result['titre_news'];
						$query_del[0]="DELETE FROM `ed2c`.`news` WHERE `news`.`code_news` = '".$code."'";
						@$msg=supp::get_msg_avert(6,$titre);
						@$msg_confirm=supp::get_msg(6,$titre);
						@$msg_erreur=news::get_msg_erreur(0);
						break;
						case 'diplome':
						$code=$_GET['code'];
						$query="SELECT * FROM `diplome` WHERE `code_diplome`='".$code."'";
						$result=mysql_fetch_assoc(mysql_query($query));
						@$code_etudiant=$result['code_etudiant'];
						$tab=mysql_fetch_assoc(mysql_query("SELECT * FROM `etudiant` WHERE `code_etudiant`=\"$code_etudiant\""));
						@$nom=$tab['nom_etudiant'];
						@$prenom=$tab['prenom_etudiant'];
						$code_cycle=$result['code_cycle'];
						$tab=mysql_fetch_assoc(mysql_query("SELECT * FROM `cycle` WHERE `code_cycle`=\"$code_cycle\""));
						@$nature=$tab['designation_cycle'];
						$query_del[0]="DELETE FROM `ed2c`.`diplome` WHERE `diplome`.`code_diplome` = '".$code."'";
						@$msg=supp::get_msg_avert(7,($nature." de l'�tudiant(e) ".$nom." ".$prenom));
						@$msg_confirm=supp::get_msg(7,($nom." ".$prenom." en ".$nature));
						@$msg_erreur=diplome::get_msg_erreur(0);
						break;
						case 'module':
						$code=$_GET['code'];
						$query="SELECT * FROM `module` WHERE `code_module`='".$code."'";
						$result=mysql_fetch_assoc(mysql_query($query));
						@$module=$result['designation_module'];
						$query_del[0]="DELETE FROM `ed2c`.`module` WHERE `module`.`code_module` = '".$code."'";
						$query_del[1]="DELETE FROM `ed2c`.`note` WHERE `note`.`code_module` = '".$code."'";
						$query_del[2]="DELETE FROM `ed2c`.`inclusion` WHERE `inclusion`.`code_module` = '".$code."'";
						@$msg=supp::get_msg_avert(8,$module);
						@$msg_confirm=supp::get_msg(8,$module);
						@$msg_erreur=op_mod::get_msg_erreur(1);
						break;
						case 'option':
						$code=$_GET['code'];
						$query="SELECT * FROM `option` WHERE `code_option`='".$code."'";
						$result=mysql_fetch_assoc(mysql_query($query));
						@$option=$result['designation_option'];
						$query_del[0]="DELETE FROM `ed2c`.`option` WHERE `option`.`code_option` = '".$code."'";
						$query_del[1]="DELETE FROM `ed2c`.`inscription` WHERE `inscription`.`code_option` = '".$code."'";
						$query_del[2]="DELETE FROM `ed2c`.`inclusion` WHERE `inclusion`.`code_option` = '".$code."'";
						$result=mysql_query("SELECT * FROM `inscription` WHERE `code_option`='".$code."'");
							$i=3;
							while($r=mysql_fetch_assoc($result)){
							$query_del[$i]="DELETE FROM `ed2c`.`note` WHERE `code_etudiant` = '".$r['code_etudiant']."' AND `code_annee_univ`='".$r['code_annee_univ']."'";
							$i++;
							}
						@$msg=supp::get_msg_avert(9,$option);
						@$msg_confirm=supp::get_msg(9,$option);
						@$msg_erreur=op_mod::get_msg_erreur(2);
						break;
						case 'inclusion':
						$code=$_GET['code'];
							$i=0;
							while(($code[$i]<>'|')&&($i<strlen($code))){
							$i++;
							}
						$code_option=substr($code,0,$i);
						$code_module=substr($code,$i+1,strlen($code)-1-strlen($code_option));
						$query="SELECT * FROM `inclusion` WHERE `code_option`='".$code_option."' AND `code_module`=".$code_module;
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$code_option\""));
						@$option=$result['designation_option'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `module` WHERE `code_module`=\"$code_module\""));
						@$module=$result['designation_module'];
						$result=@mysql_fetch_assoc(mysql_query($query));
						$query_del[0]="DELETE FROM `ed2c`.`inclusion` WHERE `inclusion`.`code_option` = '".$code_option."' AND `code_module`='".$code_module."'";
						$result=mysql_query("SELECT * FROM `inscription` WHERE `code_option`='".$code_option."'");
							$i=1;
							while($r=mysql_fetch_assoc($result)){
							$query_del[$i]="DELETE FROM `ed2c`.`note` WHERE `code_etudiant` = '".$r['code_etudiant']."' AND `code_annee_univ`='".$r['code_annee_univ']."' AND `code_module`='".$code_module."'";
							$i++;
							}
						@$msg=supp::get_msg_avert(10,($module." de l'option ".$option));
						@$msg_confirm=supp::get_msg(10,($module." a �t� supprim� de l'option ".$option));
						@$msg_erreur=jury::get_msg_erreur(0);;
						break;
						case 'annee':
						$code=$_GET['code'];
						$query="SELECT * FROM `annee_univ` WHERE `code_annee_univ`=".$code."";
						$result=mysql_fetch_assoc(mysql_query($query));
						@$annee=$result['annee_debut'];
						$query_del[0]="DELETE FROM `ed2c`.`annee_univ` WHERE `annee_univ`.`code_annee_univ` = '".$code."'";
						$query_del[1]="DELETE FROM `ed2c`.`inscription` WHERE `inscription`.`code_annee_univ` = '".$code."'";
						$query_del[2]="DELETE FROM `ed2c`.`note` WHERE `note`.`code_annee_univ` = '".$code."'";
						@$msg=supp::get_msg_avert(11,$annee);
						@$msg_confirm=supp::get_msg(11,$annee);
						@$msg_erreur=op_mod::get_msg_erreur(2);
						break;

					}
					if(@mysql_num_rows(mysql_query($query,$id_user))){
						if((isset($_GET['confirm']))&&(sha1(crypter($_GET['code'],$key,$iv))==$_GET['confirm'])){
							$i=0;
							while(isset($query_del[$i])){
							mysql_query($query_del[$i],$id_user);
							$i++;
							}
						echo '<div id="corp_page">'.$msg_confirm.'</div>';
						}else{
						
		?>
			<div id="corp_page">
			<div class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Confirmation de suppression </div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
						<div align="left"><?php echo $msg;?></div>
						<tr>
							<td class="case_gauche">
							<a href=<?php echo "supp.php?type=".$_GET['type']."&code=".$_GET['code']."&confirm=".sha1(crypter($_GET['code'],$key,$iv));?>><input type="button" value="Oui" class="bouton_form"/></a>
							</td>
							<td class="case_droite">
							<a href=<?php echo "administration.php";?>><input type="button" value="Non" class="bouton_form"/></a>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
			</div>
		</div>
		<?php
						}
					}else{
					echo '<div id="corp_page">'.@$msg_erreur.'</div>';
					}
				}else{
				echo '<div id="corp_page">Choix incorrect !</div>';
				}
			}else{
			echo '<div id="corp_page">'.autentif::get_msg_acces().'</div>';
			}
		include($chemin."pied_page.php"); ?>
</div>
</body>
</html>
