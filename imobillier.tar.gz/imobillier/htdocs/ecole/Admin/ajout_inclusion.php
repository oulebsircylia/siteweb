<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title> Gestion des utilisateurs </title>
<?php 
$chemin = "../";
$page_courante = "administration";

include($chemin."msg.php");
?>
<link rel="stylesheet" media="screen" type="text/css" title="Design" href="<?php echo ($chemin);?>css/design.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/entete.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/menu_ver.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/form.css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo ($chemin);?>css/affichage_news.css" />
<script language="javascript" src="<?php echo ($chemin);?>JS/jquery-1.6.1.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script_mv.js"></script>
<script language="javascript" src="<?php echo ($chemin);?>JS/script.js"></script>
</head>
<body>
	<div id="site"> 
		<?php include($chemin."entete.php");
			include($chemin."acces.php");?>
		<?php include($chemin."menu_ver.php") ?>
		<div id="corp_page">
		
			<?php 
			$err=true;
			if(isset($id_user)&&($level=="333")){
			$acces=true;
				if(isset($_POST['option'])&&isset($_POST['module'])&&isset($_POST['coef'])){
					$option=$_POST['option'];
					$module=$_POST['module'];
					$coef=$_POST['coef'];
					if($coef<>''){
						if(!(mysql_num_rows(mysql_query("SELECT * FROM `inclusion` WHERE `code_option`=\"$option\" AND `code_module`=\"$module\"")))){
						mysql_query("INSERT INTO `inclusion` (`code_option`,`code_module`,`coefficient`) VALUES (\"$option\",\"$module\",\"$coef\");",$id_user);
						$err=false;
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `option` WHERE `code_option`=\"$option\"",$id_user));
						$op=$result['designation_option'];
						$result=mysql_fetch_assoc(mysql_query("SELECT * FROM `module` WHERE `code_module`=\"$module\"",$id_user));
						$mo=$result['designation_module'];
						echo op_mod::get_msg_ajout_inclusion($mo,$op);
						}else{
						echo op_mod::get_msg_erreur(3);
						}
					}else{
					echo formulaire::get_msg(1);
					}
				}else{
				echo formulaire::get_msg(0);
				}
			}else{
			$acces=false;
			}
			if(($acces)&&($err)){
			?>
			<p style="text-indent:0px;"><a>Administration</a> > <a>Gestion des options/modules</a> > <a>Inclure un module dans une option</a></p> 
		<form action="ajout_inclusion.php" method="post" id="form_ajout_utilisateur" class="formulaire">
				<div class="titre_formulaire">
					<div class="titre_form_cgauche"></div>
					<div class="titre_form_text"> Inclure un module dans une option</div>
					<div class="titre_form_cdroite"></div>
				</div>
				<div class="formulaire_contenu">
					<fieldset> 
						<table class="tab_align_form">
							<tr>
								<td class="case_gauche">
									<label for="ident">Option (*) :</label>
								</td>
								<td class="case_droite">
								<select name="option" class="champ_form">
								<?php
								$result=(mysql_query("SELECT * FROM `option` ORDER BY `designation_option`"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_option'].'">'.$tab['designation_option'].'('.$tab['systeme_option'].')'.'</option>';
									}
								?>
								</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Module (*) :</label>
								</td>
								<td class="case_droite">
								<select name="module" class="champ_form">
									<?php
								$result=(mysql_query("SELECT * FROM `module` ORDER BY `designation_module`"));
									while($tab=mysql_fetch_assoc($result)){
									echo '<option value="'.$tab['code_module'].'">'.$tab['designation_module'].'</option>';
									}
								?>
								</select>
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
									<label for="ident">Coefficient (*) :</label>
								</td>
								<td class="case_droite">
									<input type="text" size="20" name="coef" class="champ_form" value=<?php if(isset($coef)&&($coef<>'')){ echo $coef;}else{ echo '""';} ?> />
								</td>
							</tr>
							<tr>
								<td class="case_gauche">
								</td>
								<td class="case_droite">
									<a href=""><input type="submit" value="Ajouter" class="bouton_form"/></a>	
									<a href=""><input type="reset" value="Effacer" class="bouton_form"/></a>	
								</td>
							</tr>
						</table>
					</fieldset>
				</div>	
			</form>
			<?php
			}
			?>
		</div>
		<?php include($chemin."pied_page.php") ?>
	</div>
</body>
</html>