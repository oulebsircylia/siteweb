<?php require_once('../connexion.php'); ?>
<?php
mysql_select_db($nom_db, $connexion);
$req_actu = "SELECT * FROM actualit�";
$res_actu = mysql_query($req_actu, $connexion) or die(mysql_error());
$row_res_actu = mysql_fetch_array($res_actu);
$totalRows_res_actu = mysql_num_rows($res_actu);

$client="select * from client";
$res_client=mysql_query($client, $connexion) or die(mysql_error());
$totalRow_res_client=mysql_num_rows($res_client);
?>
<html>
<head>
<style type="text/css">
.ejs_scroll {
	font-size:14px;
	font-family:Verdana;
	color:#2B3D8F;
	font-weight:normal;
}
</style>
<style type="text/css">
.ejs_scroll {
	font-size:13px;
	font-family:Verdana;
	color:#2B3D8F;
	font-weight:normal;
}
</style>
<title>ABC - Listes des devis</title>
<style type="text/css">
<!--
table {
	font-family:"Verdana,arial", sans-serif;
	font-size: 13px;
	color: #000000;
}
body {
	color: #000000;
	background-image: url('file:///D|/wampserver/www/Deco/fond/fg3.png');
	background-repeat: repeat-yx;
	font-family: "Times New Roman", Times, serif;
	font-size: 14px;
}
#holderdiv {
	width: 200px;
	margin: 0px 5px 0px 0px;
}
#holderdiv2 {
	width: 200px;
	padding-right: 0px;
	padding-left: 0px;
}
.coldiv {
	margin: 0px 0;
	background-color: #faf9f5;
	color: #333333;
	border: 1px solid #435ccc;
	width: 1002px;
}
.leftcoldiv {
	margin: 0px 0 0px 0;
	background-color: #7591FF;
	color: #333333;
	width: 200px;
	border: 1px solid #435ccc;
	padding: 1px;
}
.leftcoldiv2 {
	margin: 5px 0 10px 5;
	background-color: #faf9f5;
	color: #333333;
	width: 178px;
	border: 1px solid #435ccc;
	padding: 1px;
}
.rightcoldiv {
	margin: 5px 0 10px;
	width: 180px;
	background-color: #e6ebff;
	color: #333333;
	border: 1px solid #2b3d8f;
	float: right;
	padding: 1px;
}
.rightcoldiv2 {
	margin: 5px 0 10px;
	width: 180px;
	background-color: #faf9f5;
	color: #333333;
	border: 1px solid #2b3d8f;
	float: right;
	padding: 1px;
}
.hnav {
	margin: 10px 0 0px;
	width: 1002px;
	background-color: #2b3d8f;
	border-right-width: 1px;
	border-left-width: 1px;
	border-right-style: solid;
	border-left-style: solid;
	border-right-color: #2b3d8f;
	border-left-color: #2b3d8f;
}
/*sets margins to 0*/  
p {
	margin-top: 0px;
	margin-bottom: 0px;
}
/*style the text */
#wrapper p {
	margin-top: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
	font-size: 80%;
	line-height: 1.5em;
	padding-right: 5px;
	padding-left: 5px;
}
h1 {
	font-size: 100%;
	margin: 0px 210px 5px 200px;
	padding-top: 20px;
	font-weight: bold;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #6273bf;
	padding-bottom: 2px;
	padding-left: 0px;
}
.coldiv h2 {
	margin: 0 20 5;
	background-color: #e6ebff;
	font-size: 200px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #6273bf;
	padding-top: 1px;
	padding-bottom: 3px;
	padding-left: 5px;
	padding-right: 20px;
}
.coldiv h3 {
	margin: 0 210 5 200;
	background-color: #6273bf;
	font-size: 90%;
	padding: 1px 20px 3px 5px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #FFFFFF;
}
.leftcoldiv h2 {
	background-color: #6273bf;
	font-size: 100%;
	padding: 1px 1px 3px 7px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #FFFFFF;
	margin-top: 0;
	margin-bottom: 5;
	margin-right: 0;
	margin-left: 0;
}
.leftcoldiv h3 {
	background-color: #2b3d8f;
	font-size: 90%;
	padding: 1px 1px 3px 7px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #FFFFFF;
	margin-top: 0;
	margin-bottom: 5;
	margin-right: 0;
	margin-left: 0;
}
.rightcoldiv h2 {
	margin: 0 0 5;
	background-color: #6273bf;
	font-size: 90%;
	padding: 3px 0px 3px 10px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #ffffff;
}
.rightcoldiv h3 {
	margin: 0 0 5;
	background-color: #2b3d8f;
	font-size: 90%;
	padding: 3px 0px 3px 10px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #ffffff;
}
.rightcoldiv2 h3 {
	margin: 0 0 5;
	background-color: #2b3d8f;
	font-size: 90%;
	padding: 3px 0px 3px 10px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #ffffff;
}
.rightcoldiv2 h2 {
	margin: 0 0 5;
	background-color: #6273bf;
	font-size: 90%;
	padding: 3px 0px 3px 10px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #e27901;
	color: #ffffff;
}
ol {
	margin-top: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
ul {
	margin-top: 0px;
	margin-bottom: 0px;
	font-weight: normal;
	padding-left: 0px;
	padding-bottom: 10px;
	font-size: 100%;
	list-style-image: url('file:///D|/wampserver/www/th1_files/th1_bullet.gif');
	list-style-position: inside
}
.left {
	float: left;
}
.right {
	float: right;
}
a:link {
	color: #2b3d8f;
}
a:visited {
	color: #6273bf;
}
a:link:hover {
	color: #e27901;
}
.divider {
	border-top-width: 1px;
	border-top-style: solid;
	border-top-color: #6273bf;
	padding-top: 4px;
	padding-bottom: 4px;
}
-->
</style>
<link rel="stylesheet" href="../Styles/construction.css" type="text/css">
<link rel="stylesheet" href="../Styles/construction_files/menu_horizontal.css" type="text/css">
<link rel="stylesheet" href="../Style/menu_horizontal.css" type="text/css">
</head>

<body leftmargin="0" topmargin="10">
<div align="center">
  <table id="table2" width="1002" border="0" cellpadding="0" cellspacing="0" height="110">
    <tbody>
      <tr>
        <td valign="top"><table id="table3" width="1002" border="0" cellpadding="0" cellspacing="0" height="100">
            <tbody>
              <tr>
                <td width="203"><p align="center">
                    <object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" id="obj1" width="200" border="0" height="100">
                      <param name="movie" value="../images/logo.swf">
                      <param name="quality" value="High">
                      <embed src="../images/logo.swf" type="application/x-shockwave-flash" name="obj1" width="200" height="100">
                    </object>
                  </p></td>
                <td><img src="../images/heading.png" width="232" height="100"></td>
                <td width="560"><p align="center">
                    <object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" width="569" height="102" align="absmiddle" border="0" id="obj3">
                      <param name="movie" value="../images/abc.swf">
                      <param name="quality" value="High">
                      <embed src="../images/abc.swf" width="569" height="102" align="absmiddle" type="application/x-shockwave-flash" name="obj3">
                    </object>
                  </p></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>
  <div align="center">
    <table id="table4" width="1004" border="0" cellpadding="0" cellspacing="0" height="30">
      <tbody>
        <tr>
          <td valign="bottom"><table id="table12" width="100%" border="0" cellpadding="0" cellspacing="0" height="25">
              <tbody>
                <tr>
                  <td width="790" background="../images/fond_menu.png"><p>
                      <noscript>
                      </noscript>
                    
                    <div class="AJXMenuEcdNeTD"><!-- AJXFILE:Style/menu_horizontal.css -->
                      <div class="ajxmw1">
                        <div class="ajxmw2">
                          <ul>
                            <li><a href="../qui_somme_nous.php">Qui&nbsp;sommes-nous</a></li>
                            <li><a href="listes_des_clients.php">Nos clients</a></li>
                            <li><a href="nos_realisation.php">Nos&nbsp;r�alisations</a></li>
                            <li><a href="remplire_un_devis.php">Remplire un devis</a></li>
                            <li><a href="liste_des_devis.php">Devis</a></li>
                            <li><a href="nous_contacter.php">Nous&nbsp;contacter</a></li>
                          </ul>
                        </div>
                      </div>
                      <br >
                    </div>
                    </p></td>
                </tr>
              </tbody>
            </table></td>
        </tr>
      </tbody>
    </table>
    <div align="center">
      <div align="center">
        <table id="table14" style="border-left-style: solid; border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-bottom-style: solid; border-bottom-width: 1px;" width="1002" bgcolor="#FAF9F5" bordercolor="#435CCC" cellpadding="0" cellspacing="0">
          <tbody>
            <tr>
              <td><div align="center">
                  <table id="table15" width="1002" bgcolor="#FAF9F5" border="0" cellpadding="4" cellspacing="0">
                    <tbody>
                      <tr>
                        <td width="198" valign="top" bgcolor="#0066CC"><img src="../images/actu.png" width="174" height="28">
                          <h3><font color="#FFFFFF"><?php echo $row_res_actu['titre_actu']; ?></font></h3>
                          <p> <font color="#CCCCCC"><?php echo $row_res_actu['texte_actu']; ?></font> <a href="<?php echo $row_res_actu['lien_actu']; ?>" 
                          title="<?php echo $row_res_actu['titre_actu']; ?>" target="_new">en savoir plus...</a> <font color="#660000"><?php echo $row_res_actu['date_actu']; ?></font></p>
                          <p>&nbsp;</p>
                          <p>&nbsp;</p></td>
                        <td valign="top" width="10000"><table id="table16" width="100%" border="0" cellpadding="4">
                            <tbody>
                              <tr>
                                <td width="320">&nbsp;</td>
                                <td width="180"></td>
                                <td><p align="center"> <img src="../images/NA.png" width="137" border="0" height="24"></p></td>
                              </tr>
                              <tr>
                                <td colspan="2" valign="top" width="500" height="453">
                                <table width="600" border="1" cellspacing="0" cellpadding="5">
                                  <tr>
                                    <td><strong>Nom client</strong></td>
                                    <td><strong>Prenom client</strong></td>
                                    <td><strong>Les devis</strong></td>
                                  </tr>
                                  <?php while($client=mysql_fetch_array($res_client))  { ?>
                                  <tr>
                                    <td><?php echo $client['nom_cl']; ?></td>
                                    <td><?php echo $client['prenom_cl']; ?></td>
                                    <td><a href="fiches_client.php?id_cl=<?php echo $client['id_cl']; ?>" >Voir</a></td>
                                  </tr>
                                  <?php } ?>
                                </table>
                              	</td>
                                <td valign="top"><table id="table19" width="100%" border="0" cellpadding="3" cellspacing="3">
                                    <tbody>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF">Travaux <font face="Verdana">&amp; 
                                          coordination tous corps d'�tats</font></font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> Diagnostique &amp; �tude de 
                                          faisabilit�</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF">S<font face="Verdana">uivi 
                                          de chantier &amp; ma�tre d'&#339;uvre</font></font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana">Neuf &amp; 
                                          r�novation</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> Extension - Modification - 
                                          Cr�ation</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> Projections de fa�ade sur tous 
                                          support</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> B�timents industriels</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> Sp�cialiste de la r�novation</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> R�alisations de toitures</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> Sp�cialiste de la cr�ation 
                                          d'ouvertures</font></td>
                                      </tr>
                                      <tr>
                                        <td width="18" align="center"><img src="../images/bullet1.png" width="20" border="0" height="16"></td>
                                        <td><font color="#6273BF" face="Verdana"> R�alisations de toutes finitions</font></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <p align="center"><img src="../images/osn.png" width="250" height="28"> </p>
                                  <iframe width="300" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&amp;source=s_q&amp;hl=fr&amp;geocode=&amp;q=bejaia+4+rue+des+fr%C3%A8res+chikirou&amp;aq=&amp;sll=36.753155,5.07938&amp;sspn=0.002471,0.004136&amp;ie=UTF8&amp;hq=&amp;hnear=Rue+Fr%C3%A8res+Chikirou,+B%C3%A9ja%C3%AFa,+Alg%C3%A9rie&amp;ll=36.753052,5.078773&amp;spn=0.020631,0.025749&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe>
                                  <br />
                                  <small><a href="http://maps.google.fr/maps?f=q&amp;source=embed&amp;hl=fr&amp;geocode=&amp;q=bejaia+4+rue+des+fr%C3%A8res+chikirou&amp;aq=&amp;sll=36.753155,5.07938&amp;sspn=0.002471,0.004136&amp;ie=UTF8&amp;hq=&amp;hnear=Rue+Fr%C3%A8res+Chikirou,+B%C3%A9ja%C3%AFa,+Alg%C3%A9rie&amp;ll=36.753052,5.078773&amp;spn=0.020631,0.025749&amp;z=14&amp;iwloc=A" style="color:#0000FF;text-align:left">Agrandir le plan</a></small>
                              </tr>
                              <tr>
                                <td colspan="2" width="500"><p align="center"> <font color="#FAF9F5"> <span style="background-color: #C72B10"> <b><font size="3">&nbsp;Nous sommes 
                                    pr�sents sur toute la r�gion d'Alg&eacute;rie</font></b> </span></font> </p></td>
                                <td><p align="center"> clic sur la carte</p></td>
                              </tr>
                            </tbody>
                          </table></td>
                      </tr>
                    </tbody>
                  </table>
                </div></td>
            </tr>
            <tr>
              <td><div align="center">
                  <table id="table17" style="border-top-style: solid; border-top-width: 1px; padding: 1px 4px;" width="942" bordercolor="#435CCC" cellpadding="0" cellspacing="0" height="30">
                    <tbody>
                      <tr>
                        <td><table id="table18" width="100%" border="0" cellpadding="0" cellspacing="0">
                            <tbody>
                              <tr>
                                <td width="115"><span style="font-size: 9pt">Copyright � </span> <span style="font-size: 8pt">2011</span></td>
                                <td width="712"><p align="center"> <span style="font-size: 8pt">ABC. - 4 rue des fr&eacute;res chikirou- 06000 B&eacute;jaia - T�l. &amp; Fax : 034 20 00 00 00 / Gsm : 0773 47 44 06</span></p></td>
                                <td width="115"><p align="center">&nbsp;</p></td>
                              </tr>
                            </tbody>
                          </table></td>
                      </tr>
                    </tbody>
                  </table>
                </div></td>
            </tr>
          </tbody>
        </table>
        <p align="center">&nbsp;</p>
      </div>
    </div>
  </div>
  <p>&nbsp;</p>
</div>
</body>
</html>