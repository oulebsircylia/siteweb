<?php
$nomserveur = "localhost";
$nom_db = "construction";
$nom_utilisateur = "root";
$pass = "";
$connexion = mysql_pconnect($nomserveur, $nom_utilisateur, $pass) or trigger_error(mysql_error(),E_USER_ERROR); 
?>