<?php
include('connexion.php');
$nom=$_POST["nom_cont"];
$prenom=$_POST["prenom_cont"];
$mail=$_POST["e-mail_cont"];
$tel=$_POST["tel_cont"];
$fax=$_POST["fax_cont"];
$objet=$_POST["objet_cont"];
$connu=$_POST["connu_cont"];
$msg=$_POST["texte_cont"];
$code=$_POST["code_cont"];
if($code=='9')
{
$bd=connect_bd();
if($bd<>0)
{
	$requete="insert into contacte VALUES('','".$nom."','".$prenom."','".$mail."','".$tel."','".$fax."','".$objet."','".$connu."','".$msg."','".$code."')";
	$resultat=@mysql_query($requete,$bd);
	deconnect_bd($bd);
		if($resultat<>false)
		{
			header("location:../PHP/nous_contacter.php");
		}
		else
		{
			echo "Echec de l'enregistrement, d�sol�";
		}
}
}
else
{
	echo "Vous n'avez pas donn� le bon r�sultat";
}
?>