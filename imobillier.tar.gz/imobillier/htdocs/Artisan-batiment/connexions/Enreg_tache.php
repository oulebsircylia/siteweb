<?php
include('connexion.php');
$nom = $_POST["nom_tac"];
$num = $_POST["travail_id"];
$num_cl=$_POST["client_id"];
$bd=connect_bd();
if($bd<>0)
{
	$requete="insert into tache VALUES('','".$nom."','".$num."','".$num_cl."')";
	$resultat=@mysql_query($requete,$bd);
	deconnect_bd($bd);
	if($resultat<>false)
	{
		header("location:../PHP/remplire_un_devis.php");
	}
	else
	{
		echo "Echec de l'enregistrement, d�sol�";
	}
}
?>