<?php
function connect_bd()
{
	$nomserveur='localhost';
	$nombd='construction';
	$login='root';
	$pass='';
	$bd=mysql_connect($nomserveur,$login,$pass) or die("Erreur de connexion");
	mysql_select_db($nombd,$bd) or die("la base ne peut pas �tre trouv�e");
	return $bd;	
}
function deconnect_bd($bd)
{
	mysql_close($bd);
	$bd=0;
}
?>
