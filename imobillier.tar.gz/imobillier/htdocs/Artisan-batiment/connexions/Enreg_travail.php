<?php
include('connexion.php');
$nom_tra = $_POST["nom_tra"];
$num =$_POST["devis_id"];
$bd=connect_bd();
if($bd<>0)
{
	$requete_tra="insert into travail VALUES('','".$nom_tra."','".$num."')";
	$resultat=@mysql_query($requete_tra,$bd);
	deconnect_bd($bd);
	if($resultat<>false)
	{
		header("location:../PHP/remplire_un_devis.php");
	}
	else
	{
		echo "Echec de l'enregistrement, d�sol�";
	}
}
?>