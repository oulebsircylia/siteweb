<?php
include('connexion.php');
$nom = $_POST["nom_dev"];
$date = $_POST["date_dev"];
$num =$_POST["client_id"];
$bd=connect_bd();
if($bd<>0)
{
	$requete_dev="insert into devis VALUES('','".$nom."','".$date."','".$num."')";
	$resultat_dev=@mysql_query($requete_dev,$bd);
	deconnect_bd($bd);
	if($resultat_dev<>false)
	{
		header("location:../PHP/remplire_un_devis.php");
	}
	else
	{
		echo "Echec de l'enregistrement, d�sol�";
	}
}
?>