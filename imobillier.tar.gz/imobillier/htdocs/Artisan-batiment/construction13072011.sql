-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 13 Juillet 2011 à 21:35
-- Version du serveur: 5.5.8
-- Version de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `construction`
--

-- --------------------------------------------------------

--
-- Structure de la table `actualité`
--

DROP TABLE IF EXISTS `actualité`;
CREATE TABLE IF NOT EXISTS `actualité` (
  `id_actu` smallint(6) NOT NULL AUTO_INCREMENT,
  `titre_actu` varchar(100) NOT NULL,
  `texte_actu` text NOT NULL,
  `lien_actu` text NOT NULL,
  `date_actu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `etat_actu` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_actu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `actualité`
--

INSERT INTO `actualité` (`id_actu`, `titre_actu`, `texte_actu`, `lien_actu`, `date_actu`, `etat_actu`) VALUES
(1, 'Qu''est-ce qu''un château d''eau ?', 'Un château d''eau est une construction soutenant un réservoir surélevé par rapport aux points de consommation, et qui fournit ainsi de l''eau sous pression.', 'http://www.donnez_ladress_du_site.com', '2011-06-28 23:03:42', 1);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_cl` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom_cl` varchar(25) CHARACTER SET utf8 NOT NULL,
  `prenom_cl` varchar(25) CHARACTER SET utf8 NOT NULL,
  `adr_cl` text CHARACTER SET utf8 NOT NULL,
  `code_p` varchar(5) CHARACTER SET utf8 NOT NULL,
  `pays_cl` varchar(25) CHARACTER SET utf8 NOT NULL,
  `num_cl` varchar(10) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_cl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`id_cl`, `nom_cl`, `prenom_cl`, `adr_cl`, `code_p`, `pays_cl`, `num_cl`) VALUES
(1, 'NACERI', 'Bachir', '4 rue des frères chikirou', '06000', 'Algérie', '0773474406');

-- --------------------------------------------------------

--
-- Structure de la table `contacte`
--

DROP TABLE IF EXISTS `contacte`;
CREATE TABLE IF NOT EXISTS `contacte` (
  `id_cont` int(11) NOT NULL AUTO_INCREMENT,
  `nom_cont` varchar(50) CHARACTER SET utf8 NOT NULL,
  `prenom_cont` varchar(50) CHARACTER SET utf8 NOT NULL,
  `e-mail_cont` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tel_cont` varchar(10) CHARACTER SET utf8 NOT NULL,
  `fax_cont` varchar(10) CHARACTER SET utf8 NOT NULL,
  `objet_cont` varchar(100) CHARACTER SET utf8 NOT NULL,
  `connu_cont` varchar(100) CHARACTER SET utf8 NOT NULL,
  `texte_cont` text CHARACTER SET utf8 NOT NULL,
  `code_cont` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_cont`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `contacte`
--


-- --------------------------------------------------------

--
-- Structure de la table `devis`
--

DROP TABLE IF EXISTS `devis`;
CREATE TABLE IF NOT EXISTS `devis` (
  `id_dev` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom_dev` varchar(60) CHARACTER SET utf8 NOT NULL,
  `date_dev` date NOT NULL,
  `client_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_dev`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `devis`
--

INSERT INTO `devis` (`id_dev`, `nom_dev`, `date_dev`, `client_id`) VALUES
(1, 'Démolition ancienne maison', '2011-06-30', 1);

-- --------------------------------------------------------

--
-- Structure de la table `materiel`
--

DROP TABLE IF EXISTS `materiel`;
CREATE TABLE IF NOT EXISTS `materiel` (
  `id_mat` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom_mat` varchar(50) CHARACTER SET utf8 NOT NULL,
  `contitee` int(11) NOT NULL,
  `prix_mat` decimal(10,2) NOT NULL,
  `tache_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  PRIMARY KEY (`id_mat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `materiel`
--

INSERT INTO `materiel` (`id_mat`, `nom_mat`, `contitee`, `prix_mat`, `tache_id`, `client_id`) VALUES
(1, 'Cable delectricite', 20, '2400.00', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `tache`
--

DROP TABLE IF EXISTS `tache`;
CREATE TABLE IF NOT EXISTS `tache` (
  `id_tac` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom_tac` varchar(25) CHARACTER SET utf8 NOT NULL,
  `temps_tac` int(11) NOT NULL,
  `travail_id` int(10) unsigned NOT NULL,
  `client_id` int(11) NOT NULL,
  PRIMARY KEY (`id_tac`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `tache`
--

INSERT INTO `tache` (`id_tac`, `nom_tac`, `temps_tac`, `travail_id`, `client_id`) VALUES
(1, 'Installation des cables', 15, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `travail`
--

DROP TABLE IF EXISTS `travail`;
CREATE TABLE IF NOT EXISTS `travail` (
  `id_tra` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom_tra` varchar(25) CHARACTER SET utf8 NOT NULL,
  `devis_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_tra`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `travail`
--

INSERT INTO `travail` (`id_tra`, `nom_tra`, `devis_id`) VALUES
(1, 'Coulage de la dalle', 1);
