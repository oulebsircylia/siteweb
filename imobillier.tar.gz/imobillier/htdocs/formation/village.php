<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style1 {
	font-size: xx-large;
	color: #00FFFF;
}
.Style2 {color: #00FFFF}
.Style4 {color: #00FFFF; font-size: large; }
body {
	background-color: #999999;
}
.Style5 {color: #CCCCCC; font-size: large; font-style: italic; }
-->
</style></head>

<body>
<table width="1053">
  <tr bgcolor="#333333">
    <th height="66" align="left" scope="row"><span class="Style1">Village Iabdounene </span></th>
  </tr>
</table>
<table width="1050" bgcolor="#666666">
  <tr>
    <td width="171" height="32"><span class="Style4"><a href="village.php">Accueil</a></span></td>
    <td width="171"><span class="Style4"><a href="esssai.php">Actualit&eacute;s</a></span></td>
    <td width="171"><span class="Style4">Lettres</span></td>
    <td width="171"><span class="Style4">Appels</span></td>
    <td width="170"><span class="Style4">Photos</span></td>
    <td width="168"><span class="Style2">Vid&eacute;os</span></td>
  </tr>
</table>
<table width="1053">
  <tr>
    <td width="250" height="145" rowspan="4"><img src="image/319c06984f4040e91c881ea56670345e.jpg" width="250" height="130" alt="" /></td>
    <td width="600" rowspan="4" valign="top" class="Style5"> Faisons les repr&eacute;sentations tout de suite: je suis M@teo21, je serai votre guide tout au long de ce cour. Je vais vous faire d&eacute;couvrir PHP dans cette premi&egrave;re partie, et je veillerai pour &agrave; ce que tout ce que je dit soit le plus clair possible .Si vous me suivez bien, je vous garantie que PHP n'aura bient&ocirc;t plus de secret pour vous... </td>
    <td width="187" height="32" bgcolor="#666666"><span class="Style2">Photos</span></td>
  </tr>
  <tr>
    <td height="33" bgcolor="#666666"><span class="Style2">Vid&eacute;os</span></td>
  </tr>
  <tr>
    <td height="38" bgcolor="#666666"><span class="Style2">El-Khabar</span></td>
  </tr>
  <tr>
    <td height="45" bgcolor="#666666"><span class="Style2">EL-Shourouk</span></td>
  </tr>
</table>
<table width="1051">
  <tr>
    <td width="857" height="225" rowspan="3"><img src="image/75b0a921eef163f4eecd4d4a5abba701.jpg" width="857" height="314" alt="" /></td>
    <td width="182" height="25" bgcolor="#666666"><span class="Style2">Facebook</span></td>
  </tr>
  <tr>
    <td height="26" bgcolor="#666666"><span class="Style2">Twitter</span></td>
  </tr>
  <tr>
    <td height="86">&nbsp;</td>
  </tr>
</table>
<table width="1048">
  <tr>
    <td height="145">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
