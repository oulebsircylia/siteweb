<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>
<?php
	$login=" ";
	session_start();
	require('/conf.php');
	if ( isset ( $_POST['login'] ) && isset ( $_POST['mdp'] ) ) 
	{
		$login = $_POST['login']; // a proteger
		$mdp = $_POST['mdp']; // a proteger
		$req = " SELECT * FROM user WHERE login = ' ".$login." ' ";
		$result = mysql_query ( $req ) or die ( mysql_error() );
		$donnees = mysql_fetch_array($reesult);
		if ( mysql_num_rows($result) != 0 )
			{
				if ( $donnees['mdp'] == $mdp )
					{
						$_SESSION['user'] = $donnees['login'];
						header ( 'Location: acceuil_adm.php' );
					}
					else
						{
							$_SESSION['user'] = "-1"; // mdp faux
						}
			}
		else
			{
				$_SESSION['user'] = "-2"; // user inexit
			}
	}
?>
<body> 
	<div id="gauche">
 		<div id="logo"></div>
 		<div i"menu"></div>
	</div>
	<div id="droite">
 		<div id="banniere"> <!-- <div id="cache"> </div> --> </div>
 		<div id="contenu">
  			<form id="auth_form" method="post" action="file:///C|/Users/Alpha-Info/Contacts/Desktop/index.php">
				<fieldset>
  					<legend> Authentification: </legend>
 			 		<br/>
					<label for="login">Login :<br/>
  					<input tabindex="10" type="text" name="login" id="login" value="<?php echo $login; ?>" /> <br/>
		   			<input id="submit" type="submit" value="connexion" tabindex="50" />
  				</fildset>
  			</form>
  			<?php 
  				if (isset($_POST['login']) && isset($_POST['mdp']))
  					{
						if ($_SESSION['user'] == "-1")
							{
								echo '<script type="text/javascript">alert(\'Mot de passe errone\'); </script>';
							}
	 						if ($_SESSION['user'] == "-2")
	 							{
	 							echo '<script type="text/javascript">alert(\'Utilisateur incorrect\'); </script>';
								}
					}
		?>
		</div>
	</div>
<div id="pied">
	<p>  </p>
</div>	
 
</body>
</html>
