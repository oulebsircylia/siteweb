<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
<table width="1297" height="308">
  <tr>
    <th width="1143" height="302" scope="col"><img src="image/319c06984f4040e91c881ea56670345e.jpg" width="1084" height="300" alt="" /></th>
    <th width="142" scope="col">&nbsp;</th>
  </tr>
</table>
<table width="1296">
  <tr>
    <th height="277" scope="col"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="550" height="400">
      <param name="movie" value="MO.SWF" />
      <param name="quality" value="high" />
      <embed src="MO.SWF" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="550" height="400"></embed>
    </object></th>
  </tr>
</table>
<table width="1300">
  <tr>
    <th width="168" height="41" align="left" scope="col">Acceuil</th>
    <th width="199" align="left" scope="col">Cotacts</th>
    <th width="917" scope="col">&nbsp;</th>
  </tr>
</table>
</body>
</html>
