<?php require_once('Connections/lamia.php'); ?>

<?php

$colname_appartement = "-1";
if (isset($_GET['lieu'])) {
  $colname_appartement = (get_magic_quotes_gpc()) ? $_GET['lieu'] : addslashes($_GET['lieu']);
}
mysql_select_db($database_ag, $ag);
$query_appartement = sprintf("SELECT * FROM appartement WHERE lieu = '%s'", $colname_appartement);
$appartement = mysql_query($query_appartement, $ag) or die(mysql_error());
$row_appartement = mysql_fetch_assoc($appartement);
$totalRows_appartement = mysql_num_rows($appartement);







?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<title>Document sans titre</title>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('t').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('t_a').style.display= 'inline';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'inline';
	    document.getElementById('n_e').style.display= 'inline';
         document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		  document.getElementById('ca').style.display= 'none';
		  document.getElementById('n_f').style.display= 'none';
		  document.getElementById('n_�').style.display= 'none';
        } 
		  if (a == "terrain"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'inline';
			document.getElementById('n_f').style.display= 'inline';
			document.getElementById('n_�').style.display= 'none';
        } 
	if (a == "entrepot"){ 
		document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'inline';
		  document.getElementById('lo').style.display= 'inline';
		   document.getElementById('la').style.display= 'inline';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'none';
        } 
	
	
		
		   }
</script>

<style>
body {
	background-color: #FFFFFF;
	background-image:url();
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;<?php echo $row_recherch_bien['superficie']; ?>
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:nth-child(4) li{
background:#9F391A;
}
#menu li:nth-child(5) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(7):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	

	
</style>
</head>

<body>
<div id="conteneur">
	<div id="header">
 		<div id="slogon" align="center">
				<img src="images/logopaint.jpg" width="160" height="150" />
				<img src="images/naima3.jpg" width="960" height="150" />
		</div>
		<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
		</div>
	
			

		<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
	</li>	
		
		<li><a href="apropos.php">A propos</a>
		
	</li>
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
	<div id="corps">
		<div id="droite">
		</div>
		<div id="gauche">
			
		</div>
		<div id="milieu">
			<h1 align="center">Recherche d'un bien: </h1>
				<form action="wardarecherch.php" method="POST"  name="bien">
							<table align="center" border="0">
								<tr>
									<td width="143">
									<input type="hidden" name="id_bien" />
								  <label for="bien"><span class="Style40">Bien:    </span></label>									</td>
    							  <td width="681"><select id="type" name="type" onchange="Changer()" >
                                      <option value="vide"></option>
                                      <option value="appartement">Appartement</option>
                                      <option value="villa">Villa</option>
                                      <option value="terrain">Terrain</option>
                                      <option value="entrepot">Entrepot</option>
                                    </select>
    	
								<tr>
									<td>
										<label for="lieu" class="Style40">Lieu: </label></td>
									<td>
										<input type="text" name="li" id="li" />	</td>
								</tr>
						
						<td>
							<input type="submit" value="Lancer la recherche" name="ok"/>
						</td>
					</tr>
				</table>
			</form>
			<table width="682" border="1">
            </table><table width="1" border="1">
			<tr>
    <td>&nbsp;description</td>
    <td>&nbsp;prix</td>
    <td>&nbsp;num_etge</td>
    <td>&nbsp;type</td>
    <td>&nbsp;superficie</td>
    <td>&nbsp;lieu</td>
  </tr>
  <tr>
    <td>&nbsp;<?php echo $row_appartement['description']; ?></td>
    <td>&nbsp;<?php echo $row_appartement['prix']; ?></td>
    <td>&nbsp;<?php echo $row_appartement['num_etge']; ?></td>
    <td>&nbsp;<?php echo $row_appartement['type']; ?></td>
    <td>&nbsp;<?php echo $row_appartement['superficie']; ?></td>
    <td>&nbsp;<?php echo $row_appartement['lieu']; ?></td>
  </tr>
</table>


			
	  </div>
	</div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9">05-51-57-24-99</p>    </th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">E-mail:</p>
    <p align="center" class="Style9">chalal.immobilier@hotmail.fr</p></th>
  </tr>
</table>
	</div>
    
</div>
</body>
</html>



<?php ?>

<?php mysql_free_result($appartement);
?>