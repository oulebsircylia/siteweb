<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
  <link rel="stylesheet"  href="calendrier/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="calendrier/calendar.js"></script>
<script type="text/javascript" src="calendrier/FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<script>
var imgs=new Array();
imgs[0]="images/8321_20090110051149img_1150.jpg";
imgs[1]="images/maison-positive.jpg";
imgs[2]="images/img-8222-pour-le-web-7266.jpg";
imgs[3]="images/trisor-interieur-appartement-03.jpg";
imgs[4]="images/images (11).jpg";

var cpt=0;
function changeimages()
{
	document.getElementById("ima").src=imgs[cpt];
	cpt++;
	if(cpt>=imgs.length) cpt=0;
	setTimeout("changeimages()",2500);
}
</script>


<style>
body {
	background-color: #FFFFFF;
	background-image:url(images/imageaa.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #0000CC 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0000CC 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #0000FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0000FF 0%, #2A2333 100%);
}

#menu li:nth-child(7){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}

#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}
#menu li:nth-child(7):hover, #menu li:nth-child(7) li:hover{
background:#729EBF;
}

#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:270px;
	height:750px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:270px;
	height:750px;
	border-left: 1px solid black;
	}	
.Style2 {color: #FFFFFF}
.Style3 {
	font-size: 18px;
	font-style: italic;
}
.Style16 {font-family: Georgia, "Times New Roman", Times, serif}
.Style7 {	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
	font-style: italic;
	font-weight: bold;
}
</style>

</head>

<body onLoad="changeimages()" >
<div id="conteneur">
<div id="header">
		
			<div id="slogon" align="center"><img src="images/warda.jpg" width="149" height="151" /><img src="images/naima3.jpg" width="960" height="150" />			</div>
			<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col"> <span class="Style2">
				    <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();">
				      <em>Agence Immobili&eacute;re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
			        </marquee>
					  </span> </th>
   				</tr>
 			</table>
			</div>
			
		<nobr>
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="nos_biens.php">Nos biens</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
		
		</li>
	<li><a href="apropos.php">A propos</a>
		
	</li>
		
		
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	
	</ul></nobr>
  </div>
		<div id="corps">
		
		<div id="droite">
	  <br />
		  <br />
		   <br />
		 <center> 
		   <span class="Style2 Style5"><strong>Recherche rapide:</strong></span>
		 </center>
		  <br />
		 
		   
		  <form method="POST"  name="bien" action="recherche rapid1.php">
				<fieldset style="border:#FFFFFF 1px black;padding:5px;width:80px;color:#FFFFFF;">
						  <table  border="0" >
                            <tr>
                              <td width="96" height="24"><input type="hidden" name="id_bien" />
                                <strong>
                                <label for="bien">Bien: </label>
                                </strong> </td>
                              <td width="144"><select id="t" name="t" >
                                <option value="vide"></option>
                                <option value="appartement">&nbsp;&nbsp;Appartement&nbsp;&nbsp;</option>
                                <option value="villa">&nbsp;&nbsp;Villa&nbsp;&nbsp;</option>
                                <option value="terrain">&nbsp;&nbsp;Terrain&nbsp;&nbsp;</option>
                                <option value="entrepot">&nbsp;&nbsp;Entrepot&nbsp;&nbsp;</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td height="42"><label for="cat&eacute;gorie" class="Style40"><strong>Type transaction: </strong></label>                              </td>
                              <td><select name="type" id="type" placeholder="Type de bien">
                                <option value="vide"></option>
                                <option value="achat">&nbsp;&nbsp;&nbsp;&nbsp;Achat&nbsp;&nbsp&nbsp;</option>
                                <option value="location">&nbsp;&nbsp;&nbsp;&nbsp;Location&nbsp;&nbsp;&nbsp;</option>
                                <option value="echange">&nbsp;&nbsp;&nbsp;&nbsp;Echange&nbsp;&nbsp;&nbsp;</option>
								 <option value="vente">&nbsp;&nbsp;&nbsp;&nbsp;Vente&nbsp;&nbsp;&nbsp;</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td height="26"><label for="lieu" class="Style40"><strong>Lieu: </strong></label></td>
                              <td><input type="text" name="lieu" id="lieu" /></td>
                            </tr>
                            <tr>
                              <td height="28"><label for="prix" class="Style40"></label>                              </td>
                              <td><input name="submit" type="submit" value="Lancer la recherche"/></td>
                            </tr>
                        </table>
			</fieldset>
          </form>
		  <br />
		 
		 	<?php

if(!isset($_SESSION['pseudo']))
{ ?>
	<center>      <span class="Style2 Style5"><strong>Connexion</strong></span>
	</center>
		  
		  <br />
		  
		  <form method="POST" name="connexion" action="connection.php">
		<center><fieldset style="border:#FFFFFF 1px black;padding:20px;width:60px;color:#FFFFFF;" >
		<label for="login" ><strong>Login</strong></label>
		<input type="text" name="l_cl" id="l_cl" placeholder="Nom utilisateur" /><br/>
		<label for="mot de passe"><strong>Mot de passe</strong></label>
		<input type="password" name="mdp" id="mdp" placeholder="Mot de passe" />
		<center><input type="submit" name="submit"   value="Connexion" /></center>
		</fieldset></center>
	  </form> 
	  
	  <?php
	  }else{ ?>
	  <a href="deconecter.php"><img src="images/d�connexion.JPG"  /></a>
	  
	  
	  <br/>
	  <br/>
	  <a href="member.php"><img src="images/conte.jpg"  /></a> 
	  <?php }
	  ?>
	  <br />
	  <center>	<P><img src="images/cnep.jpg" width="180" height="116" /></P></center>
	  
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
	
		</div>
		<div id="gauche">
		
 <br />
		 	<p>&nbsp;</P>
		
		<center><p><div id="updates" class="boxed">
			<div class="title">
			<div id="sidebar">
			<div id="div2" class="boxed">
			<div class="title">
				<center>
				  <span class="Style2 Style5"><strong> Calendrier				  </strong></span>
				 
				</center>
				 <br />
			</div>
			<div class="content">
			<div id="div3"></div>
			</div>
			</div>
			</div>
			</div>
			<div class="content">
		<div id="cal1Container" ></div>
	
			</div>
		</div></P></center>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
	<center>	<P><img src="images/fnai.jpg" width="180" height="116" /></P></center>
		
	  
	  
		
          	
	
	  

		</div>
		<div id="milieu">
		  <center>
		 
	        <h1>Notre politique </h1>
	        <p align="left" class="Style3">Notre agence est cr&eacute;&eacute;e en2003, par l'actuel g&eacute;rant Mr chalal rabia,et elle est bas&eacute; sur plusieur valeur qui sont:</p>
	        <p align="left" class="Style3"> Innovation: des id&eacute;e toujour neuf,c'est la base de notre agence.</p>
	        <p align="left" class="Style3">Qualit&eacute;: c'est la base du notre succ&egrave;s.</p>
	        <p align="left" class="Style3">Assistance: fait d'etre toujours a l'&eacute;coute .</p>
	        <p align="left" class="Style3">Rapidit&eacute;:professionalisme et cmp&eacute;tence,avant tout.</p>
	        <p align="left" class="Style3">Fiabilit&eacute;:Le client est unique .</p>
	        <p align="left" class="Style3">  Discr&eacute;tion:C'est le secret de notre r&eacute;ussite,c'est la cl&eacute;s de notre continuit&eacute;. </p>
	        <p align="left" class="Style3">Pers&eacute;v&eacute;rance:Sentiment, toujours &agrave; atteindre le sommet du but. </p>
	        <p class="Style3"><strong>NOS METHODE: </strong></p>
	        <p align="left" class="Style3">Comment s'effectue la transaction?</p>
	        <p align="left" class="Style3">Les conseils d'abord!L'agent immobilier se doit de renseigner le client sur les modalit&eacute;s de la transaction (achat ,vente ,location et autres) ainsi que les risques encourus et les cons&eacute;quences de la signature d'un contrat de location, ou d'une promesse de vente. </p>
	        <p align="left" class="Style3">Il peut &eacute;galement renseigner son client sur la valeur de son immeuble,il peut etre d&eacute;clar&eacute; responsable s'il a &eacute;t&eacute; sous-&eacute;valu&eacute;.</p>
	        <p align="left" class="Style3">De la meme fa&ccedil;on ,l'agent immobilier sera  responsable si le terrain batir qu'il a vendu se r&eacute;v&egrave;lenon constructible avec BIP votre maison prend de la valeur ,du style ...lad&eacute;coration,c'est &agrave; vous d'en d&eacute;cider mais demandez l'avis de BIP: Nous vous proposerons des valeurs surs qui embelliront et valoriseront votre habitat! </p>
			
			
	        <p align="left">&nbsp;</p>
          </center>
		  
		  
	      <center>
	      </center>
		</div>
	
		</div>
	
  <div id="footer" >
	    <table width="1219" height="178" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#000000">
	  
  <tr bgcolor="#666666">
    <th width="392" height="174" align="center" valign="top" bgcolor="#FFFFFF" scope="col"><p class="Style9"><img src="images/icone_recrutement.jpg" alt="1" width="377" height="167" /></p>    </th>
    <th width="392"  valign="top" bgcolor="#FFFFFF" scope="col"><img src="images/Nouveau dossier (2)/maison-moderne-realiste-vecteur-icone_279-9647.jpg"width="50" height="48"/><span class="Style7"> Rue Aissat Idir Akbou -W.B&eacute;jaia</span>.<br />
      <img src="images/Nouveau dossier (2)/11.JPG" width="50" height="48" /><span class="Style16"> 07.72.24.62.97<strong> / </strong>05.51.57.24.99</span><br />
      <img src="images/Nouveau dossier (2)/14.JPG" alt="1" width="46" height="52" /><span class="Style16">chalal.immobilier@hotmail.fr</span></th>
     
    <th width="421" align="center" valign="top" bgcolor="#FFFFFF" scope="col"><table width="361" border="0">
      <tr>
        <td width="173"><a href="index.php"> Acceuil</a></td>
        <td width="178"><a href="inscription3.php">Inscreption</a></td>
      </tr>
      <tr>
        <td><a href="recherche1.php">Recherche</a></td>
        <td><a href="contact.php"></a>	<a href="apropos.php">A propos</a></td>
      </tr>
      <tr>
        <td><a href="proposer1.php">Proposer</a></td>
        <td><a href="mondat.php">Mondat</a></td>
      </tr>
      <tr>
     <td height="49" align="center"> <img src="images/Nouveau dossier (2)/communication_icon.png" alt="4"width="52" height="36"/>
	 <a href="contact.php">Contactez-nous</a><a href="apropos.php"></a></td>
      </tr>	
    </table>	</th>
  </tr>
</table>
  </div>
	
</div>
</body>
</html>

