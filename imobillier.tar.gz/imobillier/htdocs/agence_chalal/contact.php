<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet"  href="calendrier/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="calendrier/calendar.js"></script>
<script type="text/javascript" src="calendrier/FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />

<title>Document sans titre</title>
<style>
body {
	background-color: #FFFFFF;
	background-image:url(images/imageaa.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #0000CC 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0000CC 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #0000FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0000FF 0%, #2A2333 100%);
}

#menu li:nth-child(7){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}
#menu li:nth-child(7):hover, #menu li:nth-child(7) li:hover{
background:#729EBF;
}

#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;

text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
.Style1 {font-size: xx-large}
.Style3 {color: #FFFFFF}
.Style16 {font-family: Georgia, "Times New Roman", Times, serif}
.Style7 {	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
	font-style: italic;
	font-weight: bold;
}
</style>
</head>
<body>
<nobr>
<div id="conteneur">
	<div id="header">
		
			<div id="slogon" align="center"><img src="images/warda.jpg" width="149" height="151" /><img src="images/naima3.jpg" width="960" height="150" />			</div>
			<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">				      <span class="Style3">
					  <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();">
				      <em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
			          </marquee>
					</span>				      </th>
   				</tr>
 			</table>
			</div>
			
		<nobr>
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="nos_biens.php">Nos biens</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
	<li><a href="apropos.php">A propos </a>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</nobr>
	</div>
	<div id="corps">
		
		<div id="droite">
		   <br />
		  <br />
		   <br />
		
		  <br />
		 
		 	<?php

if(!isset($_SESSION['pseudo']))
{ ?>
	<center>      <span class="Style3 Style2"><strong>Connexion</strong></span>
	</center>
		  
		  <br />
		  
		  <form method="POST" name="connexion" action="connection.php">
		<center><fieldset style="border:#FFFFFF 1px black;padding:20px;width:60px;color:#FFFFFF;" >
		<label for="login" ><strong>Login</strong></label><br />
		<input type="text" name="l_cl" id="l_cl" placeholder="Nom utilisateur" /><br/>
		<label for="mot de passe"><strong>Mot de passe</strong></label><br />
		<input type="password" name="mdp" id="mdp" placeholder="Mot de passe" />
		<center><input type="submit" name="submit"   value="Connexion" /></center>
		</fieldset></center>
	  </form>
	  <?php
	  }else{ ?>
	  <a href="deconecter.php"><img src="images/d�connexion.JPG"  /></a>
	  
	  
	  
	  <br/>
	  <br/>
	  <a href="member.php"><img src="images/conte.jpg"  /></a> 
	
	    <?php }
	  ?> 
	  <br />
	  <center>	<P><img src="images/cnep.jpg" width="50" height="25" /></P></center>
	  
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
	    </div>
	  <div id="gauche">
		
		  <p>&nbsp;</p>
		<center>  <p class="Style3 calheader"><strong>Nos coordonner</strong></p>
		</center>
		  <marquee behavior="scroll" height="300" onmousemove="this.stop();" onmouseout="this.start();">
		  <p align="center" class="Style3"><img src="images/Nouveau dossier (2)/appel-telephone-telephone-icone-7124-96.png" width="50" height="48" /></p>
		  <p align="center" class="Style3">+213 (0)34 35 73 68 </p>
		  <p align="center" class="Style3">07-72-24-62-97</p>
		  <p align="center" class="Style3"> 05-51-57-24-99</p>
		  <p align="center" class="Style3"><img src="images/Nouveau dossier (2)/7.gif" width="50" height="48" /></p>
		  <p align="center" class="Style3">chalal.immobilier@hotmail.fr</p>
		  <p align="center" class="Style3"><img src="images/Nouveau dossier (2)/icone_maison.jpg" width="50" height="48" /></p>
		  <p align="center" class="Style3">Rue AISSAT Idir &agrave; 300m des 4 Chemins</p>
		  <p><span class="Style3">Guendouza Akbou 06001 B&eacute;jaia Alg&eacute;rie </span></p>
		  </marquee>
	  </div>
	    <p>&nbsp;</p>
      <div id="milieu">
	<nobr>
					<form id="form1" name="form1" method="post" action"vir�f.php">
					
					     <div align="center" class="Style1">
					       <p class="Style3"> Contctez-nous					     </p>
				         </div>
				     <center><fieldset style="border:#FFFFFF 1px black;padding:40px;width:90px;color:#FFFFFF;" >
 <table align="center">
 <tr>
 <td><strong>Nom :</strong> </td>
 <td> <input type="text" name="nom" id="Nom" /></td>
 
  </tr>
  <tr>
  <td><strong>Votre email :</strong></td>
  <td>  <input type="text" name="votre email"id="Votre email" /></td>

  </tr>
  <tr>
  <td><strong>Sujet :</strong> </td>
   <td> <input type="text" name="sujet"id="Sujet" /></td>
  
  </tr>
  <tr>
  <td><strong>Votre message :</strong> </td>
   <td>  <textarea name="message"></textarea>
   </td>
  
  </tr>
  </table>
   
  &nbsp;&nbsp;  &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;  &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;  &nbsp;&nbsp;  
   <input type="submit" name="Submit" value="Envoyer" /> 
   
    <input type="reset" name="Submit2" value="R�initialiser" />
    
  </fieldset></center>
</form>
						
	                <p>&nbsp;</p>
	                <p>&nbsp;</p>
                  <p>&nbsp;</p>
	                <p>&nbsp;</p>
	                <p>&nbsp;</p>
	                <p>&nbsp;</p>
      </div>
		<div id="footer" >
  <table width="1219" height="178" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#000000">
	  
  <tr bgcolor="#666666">
    <th width="391" height="174" align="center" valign="top" bgcolor="#FFFFFF" scope="col"><p class="Style9"><img src="images/icone_recrutement.jpg" alt="1" width="377" height="167" /></p>    </th>
    <th width="393"  valign="top" bgcolor="#FFFFFF" scope="col"><img src="images/Nouveau dossier (2)/maison-moderne-realiste-vecteur-icone_279-9647.jpg"width="50" height="48"/><span class="Style7"> Rue Aissat Idir Akbou -W.B&eacute;jaia</span>.<br />
      <img src="images/Nouveau dossier (2)/11.JPG" width="50" height="48" /><span class="Style16"> 07.72.24.62.97<strong> / </strong>05.51.57.24.99</span><br />
      <img src="images/Nouveau dossier (2)/14.JPG" alt="1" width="46" height="52" /><span class="Style16">chalal.immobilier@hotmail.fr</span></th>
     
    <th width="418" align="center" valign="top" bgcolor="#FFFFFF" scope="col"><table width="361" border="0">
      <tr>
        <td width="173"><a href="index.php"> Acceuil</a></td>
        <td width="178"><a href="inscription3.php">Inscreption</a></td>
      </tr>
      <tr>
        <td><a href="recherche1.php">Recherche</a></td>
        <td><a href="contact.php"></a>	<a href="apropos.php">A propos</a></td>
      </tr>
      <tr>
        <td><a href="proposer1.php">Proposer</a></td>
        <td><a href="mondat.php">Mondat</a></td>
      </tr>
      <tr>
     <td height="49" align="center"> <img src="images/Nouveau dossier (2)/communication_icon.png" alt="4"width="52" height="36"/>
	 <a href="contact.php">Contactez-nous</a><a href="apropos.php"></a></td>
      </tr>	
    </table>	</th>
  </tr>
</table>
	</div>
</div>
</body>
</html>
