
<?php require_once('connexion.php'); ?>

<?php
session_start();

$resultf2="";
$affich=0;
$show=0 ;

if ( $_SESSION['privilege'] == "admin"){ 
}
else {
header("Location:index.php?erreur=intru"); // redirection en cas d'echec
}
?>


<?php
$reqnb = "SELECT num_b_c_i  FROM bon_c_i  " ;
$rnbcint= mysql_query($reqnb);
?>
<?php
if (isset($_POST['import'])) {
$nbit=$_POST['nbcint'];
$selectt0 = "SELECT * FROM ligne_bcint WHERE num_bcint = '$nbit' ORDER BY n_ord ASC ";
mysql_select_db($database_dbprotect, $dbprotect);
$resultf0 = mysql_query($selectt0,$dbprotect)or die(mysql_error());
//inserer la numero de bon entre  dans table virtuelle 
	$tablv="INSERT INTO  variablebs VALUES('$nbit','1')  " ;
	mysql_select_db($database_dbprotect, $dbprotect);
	$resultf00 = mysql_query($tablv,$dbprotect)or die(mysql_error());
$affich=1 ;
$show=0 ;
}
?>

<?php 
if(isset($_POST['enregistrer'])){
//renitialisation de table
$sql="TRUNCATE TABLE `variablebs`";
$vider=mysql_query($sql);
$show=0 ;
$affich=0 ;
header("location:BS.php");
}
?>



<?php
$nrd="" ;
$desig="" ;
$qtt="" ;
$num_ivt="" ;

if (isset($_POST['ajouter']))
{
	$design=$_POST['article'] ;
	$datebs=$_POST['element_2_3']."-".$_POST['element_2_1']."-".$_POST['element_2_2'] ;
	//selection la numero bon de sortie
	$selectt22 = "SELECT * FROM variablebs ";
	mysql_select_db($database_dbprotect, $dbprotect);
$resultf22 = mysql_query($selectt22,$dbprotect)or die(mysql_error());	
	$variabl =mysql_fetch_array($resultf22) ;
	$nu_bsr=$variabl['numbs'] ;
	//selectionner numero ordre
$selectt2 = "SELECT * FROM ligne_bcint WHERE ((ds_ar = '$design') &&( num_bcint='$nu_bsr')) ";
mysql_select_db($database_dbprotect, $dbprotect);
$resultf2 = mysql_query($selectt2,$dbprotect)or die(mysql_error());
$art =mysql_fetch_array($resultf2) ;
$desig=$art['ds_ar'] ;
$nrd=$art['n_ord'] ;
$qtt=$_POST['qtts'] ;
$num_bs=$art['num_bcint'] ;
$observ=$_POST['obsr'] ;




//ajout une ligne de bon de sortie
$insert1= "INSERT INTO   ligne_bs VALUES('$qtt','$observ','$num_bs','$design')  ";
$resultinser1= mysql_query($insert1,$dbprotect)or die(mysql_error());

//replissaaaaage  de bon de sortie une seul fois 
if ($nrd==1){
$insert2 = "INSERT INTO  b_sortie   VALUES('$num_bs','$datebs')  ";
$resultinser2= mysql_query($insert2,$dbprotect)or die(mysql_error());
} //desactiver  le varible $inser apres premiere insersion
 
// mise a jour de quantite des articles 
$selectt4 = "SELECT qtt_articl  FROM   article WHERE design_art='$desig'  ";
$resultf4= mysql_query($selectt4,$dbprotect)or die(mysql_error());
$respp4=mysql_fetch_array($resultf4);

$ancqtt=$respp4['qtt_articl'] ;
$ancqt=($ancqtt)-($qtt) ;
$insert3 = "UPDATE article SET qtt_articl='$ancqt' WHERE design_art='$design' ";
mysql_select_db($database_dbprotect, $dbprotect);
$resultinser3= mysql_query($insert3,$dbprotect)or die(mysql_error());


$affich=1 ;
 $selectt0 = "SELECT * FROM ligne_bcint WHERE num_bcint = '$nu_bsr' ORDER BY n_ord ASC ";
mysql_select_db($database_dbprotect, $dbprotect);
$resultf0 = mysql_query($selectt0,$dbprotect)or die(mysql_error());

//requet pour affiche les resultats  sur le tableau
$selectt5 = "SELECT * FROM ligne_bcint WHERE num_bcint = '$nu_bsr' ORDER BY n_ord ASC ";
$resultf5= mysql_query($selectt5,$dbprotect)or die(mysql_error());

$show=1 ;
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Imprission</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">

<script type="text/javascript" src="calendar.js"></script>
<style type="text/css">
<!--
#entete {
	background-image: url(images/IMPR/BSBTT.jpg);
	height: 140px;
	width: 960px;
	margin: 0px;
}
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 955px;
	vertical-align: middle;
	padding-left: 5px;
	font-weight: bold;
	color: #FFF;
	font-style: normal;
	font-family: calibri;
	text-align: left;
	font-size: 16px;
}
#CONTNN #Stau ul {
	margin: 0px;
	list-style-type: none;
	padding: 2px;
	display: inline;
}
#CONTNN #Stau ul li {
	vertical-align: middle;
	display: inline;
	text-align: left;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: auto;
	width: 960px;
	background-repeat: repeat-y;
	margin: 0px;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
}
#CONTNN {
	width: 976px;
	margin-right: auto;
	margin-left: auto;
	margin-top: 0px;
	height: auto;
}
#MENU {
	background-image: url(images/img06.gif);
	background-repeat: repeat-x;
	height: 44px;
	width: 960px;
	text-align: center;
}
#CONTNN #MENU table tr {
	text-align: center;
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	padding-left: 225px;
}
#CONTNN #Stau table tr th {
	text-align: left;
	color: #FFF;
}
#CONTNN #Stau table tr th a {
	color: #FFF;
	text-decoration: none;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
#CONTNN #CORP table tr th {
	text-align: center;
	vertical-align: bottom;
}
#CONTNN #CORP table tr th p a {
	font-family: calibri;
	font-weight: bold;
	color: #333;
	text-decoration: none;
	font-size: 18px;
}
.ttre {
	font-family: calibri;
	font-size: 24px;
}
.tttr {
	font-weight: bold;
}
#CONTNN #CORP div p .tttr {
	font-family: calibri;
}
#CONTNN #CORP div p .tttr {
	font-size: 24px;
}
#CONTNN #CORP div form center table tr td {
	font-family: calibri;
	font-size: 16px;
}
-->
</style>
<script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>


</head>
<body onload="MM_preloadImages('images/B32 .jpg','images/B3i2.jpg','images/B3c2.jpg','images/IMG/gtk-refresh.png','images/gs1.jpg')">
<div id="CONTNN">
  <div id="entete"></div>
  <div id="Stau">
    <table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="54" height="34" scope="col"><img src="images/MSN Messenger.png" width="28" height="28" /></th>
        <th width="771" scope="col">Bienvenue  .:: <span><?php echo $_SESSION['prenom']; ?><span> </span><?php echo $_SESSION['nom']; ?> ::.</span></th>
        <th width="125" scope="col"><a href="index.php?erreur=logout"><strong>Se Dconnecter</strong></a></th>
      </tr>
    </table>
  </div>
  <div id="MENU">
    <table width="677" height="44" border="0" align="center" cellspacing="0">
      <tr>
        <th width="170" height="40" scope="col"><a href="Gestion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','images/B32 .jpg',1)"><img src="images/B31 .jpg" name="Image2" width="170" height="40" border="0" id="Image2" /></a></th>
        <th width="170" scope="col"><a href="imprission.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','images/B3i2.jpg',1)"><img src="images/imprission.jpg" name="Image3" width="170" height="40" border="0" id="Image3" /></a></th>
        <th width="170" scope="col"><a href="Consultation.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','images/B3c2.jpg',1)"><img src="images/B3c1 .jpg" name="Image4" width="170" height="40" border="0" id="Image4" /></a></th>
        <th width="159" scope="col"><a href="admin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','images/gs1.jpg',1)"><img src="images/gs.jpg" name="Image5" width="170" height="40" border="0" id="Image5" /></a></th>
      </tr>
    </table>
  </div>
  <div id="CORP">
    <div align="center">
      <br />
      <p>
        <span class="tttr">Les Sorties du Stock </span></p>
        <form action="" method="Post">
        <center>
        <table width="906" border="0" cellspacing="0" cellpadding="5">
  <tr bgcolor="#FBFBFB">
    <td  align="right">N de bon de Cmd associe:</td>
    <td width="248" scope="col">
    
     <select name="nbcint" id="nbcint"><option></option>
			  <?php
			  while($bcmnd=mysql_fetch_array($rnbcint)){ ?>
            <option value="<?php  echo $bcmnd['num_b_c_i']; ?>"> <?php  echo $bcmnd['num_b_c_i'];  ?> </option>

             <?php } ?>
			  
              </select>
      </td>
    <td width="160" scope="col">Date de bon de sortie:</td>
    <th width="236" scope="col"><span>
      <input id="element_2_2" name="element_2_2" class="element text" size="2" maxlength="2" value="" type="text" />
/
<label for="element_2_2">J</label>
    </span> <span>
    <input id="element_2_1" name="element_2_1" class="element text" size="2" maxlength="2" value="" type="text" />
/
<label for="element_2_1">M</label>
    </span> <span>
    <input id="element_2_3" name="element_2_3" class="element text" size="4" maxlength="4" value="" type="text" />
    <label for="element_2_3">A</label>
    </span> <span id="calendar_2"> <img id="cal_img_2" class="datepicker" src="calendar.gif" alt="Pick a date." /> </span>
    <script type="text/javascript">
			Calendar.setup({
			inputField	 : "element_2_3",
			baseField    : "element_2",
			displayArea  : "calendar_2",
			button		 : "cal_img_2",
			ifFormat	 : "%B %e, %Y",
			onSelect	 : selectDate
			});
		</script></th>
  </tr>
  <tr bgcolor="#E9E9E9">
    <td>&nbsp;</td>
    <td colspan="2" align="center"><input type="submit" name="import" id="import" value="Importer le Bon " /></td>    
    <td>&nbsp;</td>
  </tr>
</table>
       
      <br /> <?php if($affich==1){?> 
        <table width="905" border="0" cellspacing="0" cellpadding="10" bgcolor="#EEFFFF">
          <tr bgcolor="#BEDEEB">
    <td width="156"  align="right">Selection l'article:</td>
    <td width="345" align="justify"><select name="article" id="article" style="width:auto">
      <option></option>

     <?php   while($responce=mysql_fetch_array($resultf0) ) {  ?>
      <option value="<?php echo $responce['ds_ar'] ; ; ?>"><?php echo $responce['ds_ar'] ;;?> </option>
    <?php } ?>
    </select></td>
    <td width="116" align="right">La quantit Servie:</td>
    <td width="208" align="center"><input type="text" name="qtts" id="qtts" /></td>
  </tr>
  <tr>
    
   
    <td></td>
    <td align="left"><label>
      <input type="submit" name="ajouter" value="Ajouter une ligne" />
    </label></td>
    <td align="right">&nbsp;observation :</td>
    <td align="right"><textarea name="obsr" cols="19" rows="3"></textarea></td>
  </tr>
</table>
        <?php } ?>   <br /><br />
          
   
        <table width="936" border="1" cellspacing="0" cellpadding="5" bgcolor="#EEFFFF">
          <tr bgcolor="#BEDEEB">
    <td width="80"  align="center">Nord</td>
    <td width="300" align="center">Dsignation</td>
    <td width="160" align="center">Qtt Servie</td>
 
    <td width="156" align="center">Observation</td>
  </tr>
<?php if ($show==1){ ?>
  <tr>
    <?php  $j=0 ;
	
	while(($respp5=mysql_fetch_array($resultf5))&&( $j<$nrd) ){ ?>
   
    <td><?php  echo $respp5['n_ord'];?></td>
    <td><?php echo $respp5['ds_ar'];?></td>
    <td>&nbsp;<?php 
	// l'affichage de la quantite dans le tableau 
	
	$selectt7 = "SELECT  qtt_serv,obs FROM ligne_bs WHERE ds_art = '".$respp5['ds_ar']."'  ";
$resultf7 = mysql_query($selectt7,$dbprotect)or die(mysql_error());
$respp7 =mysql_fetch_array($resultf7) ;

	
	  echo $respp7['qtt_serv'] ;?></td>

    <td>&nbsp;<?php
		$selectt8= "SELECT obs FROM ligne_bs WHERE ds_art = '".$respp5['ds_ar']."'  ";
$resultf8= mysql_query($selectt8,$dbprotect)or die(mysql_error());
$respp8 =mysql_fetch_array($resultf8) ;

	
	
	 echo $respp8['obs']; ?></td>
	
  </tr>
    <?php $j++ ; } ?>      
     <?php } ?>    
</table>
 
<br /><input align="middle" name="imprimer" type="button"  value="imprimer"  onclick="window.location='imprimerbs.php'"/>
<input align="middle" name="enregistrer" type="submit"  value="Enregistrer" />
        </center>
        <BR /><BR />
      </form>
    </div>
  </div>

  <div id="PIED"></div>
</div>


</body>
</html>
