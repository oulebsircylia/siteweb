
<?php require_once('connexion.php'); ?>
<?php


session_start(); // On relaye la session
if ( $_SESSION['privilege'] == "admin"){ 
}
else {
header("Location:index.php?erreur=intru"); // redirection en cas d'echec
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Gestion</title>
<style type="text/css">
<!--
#entete {
	background-image: url(images/Gest/btgestion.jpg);
	height: 140px;
	width: 960px;
}
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 955px;
	vertical-align: middle;
	padding-left: 5px;
	font-weight: bold;
	color: #FFF;
	font-style: normal;
	font-family: calibri;
	text-align: left;
}
#CONTNN #Stau ul {
	margin: 0px;
	list-style-type: none;
	padding: 2px;
	display: inline;
}
#CONTNN #Stau ul li {
	vertical-align: middle;
	display: inline;
	text-align: left;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: 430px;
	width: 960px;
	background-repeat: repeat-y;
	text-align: center;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
}
#CONTNN {
	width: 960px;
	margin-right: auto;
	margin-left: auto;
}
#MENU {
	background-image: url(images/img06.gif);
	background-repeat: repeat-x;
	height: 44px;
	width: 960px;
	text-align: center;
}
#CONTNN #MENU table tr {
	text-align: center;
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	padding-left: 225px;
}
#CONTNN #Stau table tr th {
	text-align: left;
	color: #FFF;
	margin: 15px;
}
#CONTNN #CORP table {
	padding: 20px;
	width: auto;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 20px;
	margin-left: auto;
}
#CONTNN #CORP table tr {
	text-align: center;
	vertical-align: bottom;
}
#CONTNN #CORP table tr th p a {
	font-family: calibri;
	color: #242424;
	text-decoration: none;
	font-size: 18px;
}
#CONTNN #Stau table tr th a {
	color: #FFF;
	text-decoration: none;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
#CONTNN #CORP table tr td p a {
	font-family: calibri;
	font-size: 18px;
	color: #202020;
	text-decoration: none;
	font-weight: bold;
}
#CONTNN #CORP table tr {
	vertical-align: bottom;
	text-align: center;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('images/B32 .jpg','images/B3i2.jpg','images/B3c2.jpg','images/IMG/gtk-refresh.png','images/gs1.jpg','images/Gest/article.png','images/Gest/Fournisseu1r.png','images/Gest/Demandeur.png','images/Gest/entree1.png','images/Gest/FAMIL.png','images/Gest/1257432389_application-x-archive.png')">
<div id="CONTNN">
  <div id="entete"></div>
  <div id="Stau">
    <table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="54" height="34" scope="col"><img src="images/MSN Messenger.png" width="28" height="28" /></th>
        <th width="771" scope="col">Bienvenue .:: <span><?php echo $_SESSION['prenom']; ?><span> </span><?php echo $_SESSION['nom']; ?> ::.</span></th>
        <th width="125" scope="col"><a href="index.php?erreur=logout"><strong>Se Déconnecter</strong></a></th>
      </tr>
    </table>
  </div>
  <div id="MENU">
    <table width="677" height="44" border="0" align="center" cellspacing="0">
      <tr>
       <?php if($_SESSION['privilege'] == "admin") { ?> <th width="170" height="40" scope="col"><a href="Gestion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','images/B32 .jpg',1)"><img src="images/Gestion .jpg" name="Image2" width="170" height="40" border="0" id="Image2" /></a></th> <?php } ?>
        <th width="170" scope="col"><a href="imprission.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','images/B3i2.jpg',1)"><img src="images/B3i1.jpg" name="Image3" width="170" height="40" border="0" id="Image3" /></a></th>
        <th width="170" scope="col"><a href="Consultation.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','images/B3c2.jpg',1)"><img src="images/B3c1 .jpg" name="Image4" width="170" height="40" border="0" id="Image4" /></a></th>
        <?php if($_SESSION['privilege'] == "admin") { ?><th width="159" scope="col"><a href="admin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','images/gs1.jpg',1)"><img src="images/gs.jpg" name="Image5" width="170" height="40" border="0" id="Image5" /></a></th><?php } ?>
      </tr>
    </table>
  </div>
  <div id="CORP">
    <table width="719" border="0" align="center">
      <tr>
        <th width="220" height="127" scope="col"><p>&nbsp;</p>
        <p><a href="Articles.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','images/Gest/article.png',1)"><img src="images/Gest/article1.png" name="Image6" width="80" height="80" border="0" id="Image6" /></a></p>
        <p><a href="Articles.php">Articles</a></p></th>
        <th width="265" scope="col"><p><a href="Fournisseur.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','images/Gest/Fournisseu1r.png',1)"><img src="images/Gest/Fournisseur.png" name="Image7" width="103" height="111" border="0" id="Image7" /></a></p>
        <p><a href="Fournisseur.php">Fournisseurs</a></p></th>
        <th width="220" scope="col"><p><a href="Demandeurs.PHP" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','images/Gest/Demandeur.png',1)"><img src="images/Gest/Demandeur1.png" name="Image8" width="87" height="91" border="0" id="Image8" /></a></p>
        <p><a href="Demandeurs.PHP">S.Demandeurs</a></p></th>
      </tr>
      <tr>
        <td height="135"><a href="familles.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image12','','images/Gest/FAMIL.png',1)"><img src="images/Gest/FAMILE.png" alt="familles.php" name="Image12" width="106" height="106" border="0" id="Image12" /></a><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','images/IMG/gtk-refresh.png',1)"><center>
          <p><a href="familles.php"><a href="Familles.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image10','','images/Gest/FAMIL.png',1)">Famille d'articles</a></p>
<p><a href="Entrée.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image9','','images/Gest/entree1.png',1)"></p></td>
        <td><p><a href="entree.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image9','','images/Gest/entree1.png',1)"><img src="images/Gest/entree.png" name="Image9" width="106" height="106" border="0" id="Image9" /></a></a></p>
          <p><a href="entree.php">Entrée de Stock</a></p>
        <center><center></td>
        <td><p><a href="rangement.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image11','','images/Gest/1257432389_application-x-archive.png',1)"><img src="images/Gest/1257432218_archive.png" name="Image11" width="80" height="80" border="0" id="Image11" /></a></p>
        <p><a href="rangement.php">Rangement</a></p></td>
      </tr>
    </table>
  </div>
  <div id="PIED"></div>
</div>
</body>
</html>
