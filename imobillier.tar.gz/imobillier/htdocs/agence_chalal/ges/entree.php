

<?php require_once('connexion.php'); ?>
<?php




session_start(); // On relaye la session
if ( $_SESSION['privilege'] == "admin")
{ 
}
else {
header("Location:index.php?erreur=intru"); // redirection en cas d'echec
}


?>
<?php
$reqa = "SELECT design_art FROM article" ;
mysql_select_db($database_dbprotect, $dbprotect);
$resul3= mysql_query($reqa,$dbprotect)or die(mysql_error()) ;
?>

<?php

$i=0;
$activ="" ;
$n=0 ;
 if(isset($_POST['ajouter'])){

$datbe =$_POST['element_2_3']."-".$_POST['element_2_1']."-".$_POST['element_2_2'] ;
$datfct =  $_POST['ann_d']."-".$_POST['mois_d']."-".$_POST['jour_d'] ;
$datbcxt =   $_POST['ann_b']."-".$_POST['mois_b']."-".$_POST['jour_b'] ;

$nbn=  $_POST['nbe'];
$articl =  $_POST['artic'];

$nfcp=  $_POST['nfc'];
$frnp=  $_POST['frn'];
$nbcxp=  $_POST['nbcx'];
$qttp=  $_POST['qtt'];
$prix=  $_POST['prix'];

$observationp=  $_POST['observation'];
//requet d'insertion dans table inventaire


//requet de test map
$req1 = "SELECT *  FROM map" ;
$res1= mysql_query($req1);
$resp=mysql_fetch_array($res1) ;
if  ($resp['val']!=1){
//requet d'insertion numero de facture dans bons dans table map 
$addmap = sprintf(" INSERT INTO map VALUES ('$nbn','1','$nfcp','$frnp', '$qttp','$articl','$datfct' ) ");
mysql_select_db($database_dbprotect, $dbprotect);
$ajmap = mysql_query($addmap, $dbprotect) or die(mysql_error());



//requet d'insertion dans bon  entree

$addbentre = sprintf(" INSERT INTO `gestock`.`bentree` ( `num_be` ,`date_be` ) VALUES ('$nbn', '$datbe')");
$ajbentre = mysql_query($addbentre, $dbprotect) or die(mysql_error());
//requet d'insertion dans bon commande externe
$addbcext = sprintf(" INSERT INTO `gestock`.`bcext` ( `num_bcext` ,`date_bcext` ,`num_f`)VALUES ('$nbcxp', '$datbcxt', '$nfcp')");
$ajbcext = mysql_query($addbcext, $dbprotect) or die(mysql_error()); 
		//requet d'insertion dans facture
$addfacture = sprintf(" INSERT INTO facture (num_fact,date_fact,r_social  ) VALUES ('$nfcp', '$datfct', '$frnp')");
mysql_select_db($database_dbprotect, $dbprotect);
$ajfacture = mysql_query($addfacture, $dbprotect) or die(mysql_error());			

	

}else {
$addmap = sprintf(" INSERT INTO map VALUES ('$nbn','1','$nfcp','$frnp', '$qttp','$articl','$datfct' ) ");
mysql_select_db($database_dbprotect, $dbprotect);
$ajmap = mysql_query($addmap, $dbprotect) or die(mysql_error());
}


//**************************************************
//requet de slelection lle numero de bon entrre et le numero facture
$recref11= sprintf(" SELECT  * FROM map  ");
	mysql_select_db($database_dbprotect, $dbprotect);
$apelref11= mysql_query($recref11,$dbprotect) or die(mysql_error());
$resp11=mysql_fetch_array($apelref11);
$nmbe=$resp11['nub'] ;
$nmfact=$resp11['nfact'] ;

//requet d'insertion dans ligne bon  entree	
$addlgbe = sprintf(" INSERT INTO ligne_e VALUES ('$qttp' ,'$prix' ,'$observationp','$nmbe','$nmfact','$articl') ");
	$ajlgbc = mysql_query($addlgbe, $dbprotect) or die(mysql_error());
	

	
	//selection de reference d'une article 
	$recref= sprintf(" SELECT  ref_art FROM article WHERE design_art = '$articl' ");
	mysql_select_db($database_dbprotect, $dbprotect);
$apelref= mysql_query($recref,$dbprotect) or die(mysql_error());
$resp=mysql_fetch_array($apelref);
$rfp=$resp['ref_art'];

//requet d'insertion dans ligne bon commande externe voire base de donne num_bcext remplacer par num_bcextr

$addlgbext = sprintf(" INSERT INTO `gestock`.`ligne_bcext` VALUES ('$qttp', '$nbcxp', '$rfp')");
$ajlgnexct = mysql_query($addlgbext, $dbprotect) or die(mysql_error());

//requet d'insertion  quantite dans article 

$recqtt= sprintf(" SELECT  qtt_articl FROM article WHERE  ref_art= '$rfp' ");
	mysql_select_db($database_dbprotect, $dbprotect);
$apelqtt= mysql_query($recqtt,$dbprotect) or die(mysql_error());
$respqtt=mysql_fetch_array($apelqtt);
$qtt=$qttp+($respqtt['qtt_articl']) ;
$addqtt = " UPDATE article SET qtt_articl='$qtt' WHERE  ref_art= '$rfp' ";
$ajbqtt = mysql_query($addqtt, $dbprotect) or die(mysql_error());

//**********************************************************************************







	

header("Location:entree.PHP");






}

?>
<?php

$req2 = "SELECT *  FROM map  " ;
$res2= mysql_query($req2);
 


?>


<?php
//requet permet d'afficher les list de fornisseurs 
$reqf = "SELECT rais_social  FROM fournisseur  " ;
$resulf= mysql_query($reqf);

 
			
?>
<?php
//requet permet de faire le test pour désactiver les champ  
$req5 = "SELECT *  FROM map  " ;
$res5= mysql_query($req5);
$repon=mysql_fetch_array($res5) ;
$valeur=$repon['val'] ;
$num=$repon['nub'] ;

?>

<?php  
if(isset($_POST['enregestrer'])){
//renitialisation de table map 
$requete2="TRUNCATE TABLE `map`";             
mysql_query($requete2);
header("location:entree.php");

}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>entree</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="calendar.js"></script>
<style type="text/css">
<!--
#entete {
	background-image: url(images/Gest/entreebt.jpg);
	height: 140px;
	width: 960px;
}
#Stau {
	background-image: url(images/bordeur1.jpg);
	background-repeat: repeat-x;
	height: 36px;
	width: 955px;
	vertical-align: middle;
	padding-left: 5px;
	font-weight: bold;
	color: #FFF;
	font-style: normal;
	font-family: calibri;
	text-align: left;
	font-size: 16px;
}
#CONTNN #Stau ul {
	margin: 0px;
	list-style-type: none;
	padding: 2px;
	display: inline;
}
#CONTNN #Stau ul li {
	vertical-align: middle;
	display: inline;
	text-align: left;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
#CORP {
	background-image: url(images/CORP2.jpg);
	height: auto;
	width: 960px;
	background-repeat: repeat-y;
	text-align: center;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
	padding-top: 10px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}
#CONTNN #CORP center #form1 {
	font-family: calibri;
}
#PIED {
	height: 15px;
	width: 960px;
	background-image: url(images/PIED.jpg);
}
#CONTNN {
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	margin-top: 8px;
}
#MENU {
	background-image: url(images/img06.gif);
	background-repeat: repeat-x;
	height: 44px;
	width: 960px;
	text-align: center;
}
#CONTNN #MENU table tr {
	text-align: center;
	width: 960px;
	margin-right: auto;
	margin-left: auto;
	padding-left: 225px;
}
#CONTNN #Stau table tr th {
	text-align: left;
	color: #FFF;
}
#CONTNN #Stau table tr th a {
	color: #FFF;
	text-decoration: none;
}
body {
	background-image: url(images/motif.gif);
	background-repeat: repeat;
}
.P {
	font-family: calibri;
}
-->
</style>

<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>


</head>

<body onload="MM_preloadImages('images/B32 .jpg','images/B3i2.jpg','images/B3c2.jpg','images/IMG/gtk-refresh.png','images/gs1.jpg')">
<div id="CONTNN">
  <div id="entete"></div>
  <div id="Stau">
    <table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="54" height="34" scope="col"><img src="images/MSN Messenger.png" width="28" height="28" /></th>
        <th width="771" scope="col">Bienvenue .:: <span><?php echo $_SESSION['prenom']; ?><span> </span><?php echo $_SESSION['nom']; ?> ::. </span></th>
        <th width="125" scope="col"><a href="index.php?erreur=logout"><strong>Se Déconnecter</strong></a></th>
      </tr>
    </table>
  </div>
  <div id="MENU">
    <table width="677" height="44" border="0" align="center" cellspacing="0">
      <tr>
        <th width="170" height="40" scope="col"><a href="Gestion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','images/B32 .jpg',1)"><img src="images/Gestion .jpg" name="Image2" width="170" height="40" border="0" id="Image2" /></a></th>
        <th width="170" scope="col"><a href="imprission.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','images/B3i2.jpg',1)"><img src="images/B3i1.jpg" name="Image3" width="170" height="40" border="0" id="Image3" /></a></th>
        <th width="170" scope="col"><a href="Consultation.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','images/B3c2.jpg',1)"><img src="images/B3c1 .jpg" name="Image4" width="170" height="40" border="0" id="Image4" /></a></th>
        <th width="159" scope="col"><a href="admin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','images/gs1.jpg',1)"><img src="images/gs.jpg" name="Image5" width="170" height="40" border="0" id="Image5" /></a></th>
      </tr>
    </table>
  </div>
  <div id="CORP">
    <h2>
      <centre>
      <span class="P"><strong>LES ENTREES DE STOCK</strong></span><strong>
</center>
    </strong></h2>
   
    <center>
      <form id="form1" name="form1" method="post" action="entree.php">
       <CENTER> <table width="874" border="0" cellspacing="10" cellpadding="0" bgcolor="#E1EBF0">
          <tr align="center">
      <td width="135"align="RIGHT">N° Bon d'entrée </td>
      <td width="238"align="LEFT">
	 <?php if ($valeur !=1)  {                     ?>
	   <input type="text" name="nbe" style="background:#F9F9F9"  />
	 <?php  } else { ?>
	  <input type="text" name="nbe" style="background:#F9F9F9" value="<?php echo $num ; ?>"  disabled="disabled" />
	<?php  } ?>
	  </td>
      <td width="200"align="RIGHT">Date Bon d'entrée </td>
       <td width="251"align="LEFT">
          <?php if ($valeur!=1)  {                     ?>
       <span>
			<input id="element_2_2" name="element_2_2" class="element text" size="2" maxlength="2" value="" type="text"> /
			<label for="element_2_2">J</label>
		</span>
		<span>
			<input id="element_2_1" name="element_2_1" class="element text" size="2" maxlength="2" value="" type="text"> /
			<label for="element_2_1">M</label>
		</span>
		<span>
	 		<input id="element_2_3" name="element_2_3" class="element text" size="4" maxlength="4" value="" type="text">
			<label for="element_2_3">A</label>
		</span>
	
		<span id="calendar_2">
			<img id="cal_img_2" class="datepicker" src="calendar.gif" alt="Pick a date.">	
		</span>
		<script type="text/javascript">
			Calendar.setup({
			inputField	 : "element_2_3",
			baseField    : "element_2",
			displayArea  : "calendar_2",
			button		 : "cal_img_2",
			ifFormat	 : "%B %e, %Y",
			onSelect	 : selectDate
			});
		</script> 
		<?php }else {  ?>
		<span>
			<input id="element_2_2" name="element_2_2" class="element text" size="2" maxlength="2" value="" type="text"  disabled="disabled" > /
			<label for="element_2_2">J</label>
		</span>
		<span>
			<input id="element_2_1" name="element_2_1" class="element text" size="2" maxlength="2" value="" type="text"  disabled="disabled" > /
			<label for="element_2_1">M</label>
		</span>
		<span>
	 		<input id="element_2_3" name="element_2_3" class="element text" size="4" maxlength="4" value="" type="text"  disabled="disabled"  >
			<label for="element_2_3">A</label>
		</span>
	
		<span id="calendar_2">
			<img id="cal_img_2" class="datepicker" src="calendar.gif" alt="Pick a date." disabled="disabled">	
		</span>
		
		<?php }  ?>
		
		
        </td>
          </tr>
        </table></CENTER>
        <br>
         <CENTER> <table width="870" border="0" cellspacing="10" cellpadding="0" bgcolor="#E3F9F0">
          <tr align="center">
      <td width="147" align="RIGHT">Désignation</td>
      <td width="229"align="LEFT"><select name="artic" id="artic"   >
	  <option> </option>
    <?php 
			  while($article=mysql_fetch_array($resul3)){ ?>
    <option   value="<?php  echo $article['design_art'];  ?> "    > <?php  echo $article['design_art']; ?> </option>
    
    <?php        }    ?>
    
  </select></td>
      <TD align="right">Quantité:</TD>
      <TD align="left"><input type="text" name="qtt" /></TD>
          </tr>
           <tr align="center">
		   
      <td width="147" align="RIGHT">&nbsp;</td>
     <?php if (1==1) { ?>
     <br/> <td width="229"align="left">
      
     </td>
	  <?php } ?>
      <td align="right" colspan="1"></td>
      <td align="left"> 
 
     </td>
          </tr>
             <tr align="center">
			 
      <td width="147" align="RIGHT">N° Facture:</td>
      <td width="229"align="LEFT"><input type="text" name="nfc">
	 
	  
	  </td>
      <td width="194" align="RIGHT">Date-Facture:</td>
      <td width="250"align="LEFT" >
      
        <p>
          <select  name="jour_d" autocomplete="off">
            <option value="-1">Jour</option>
            <option value="01">01</option> 
            <option value="02">02</option>
            <option value="03">03</option>
            <option value="04">04</option>
            <option value="05">05</option>
            <option value="06">06</option>
            <option value="07">07</option>
            <option value="08">08</option>
            <option value="09">09</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
            
          </select>
          <select name="mois_d"autocomplete="off"><option value="-1">Mois</option>
										<option value="01">01</option> 
										<option value="02">02</option>
										<option value="03">03</option>
										<option value="04">04</option>
										<option value="05">05</option>
										<option value="06">06</option>
										<option value="07">07</option>
										<option value="08">08</option>
										<option value="09">09</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										</select>
										<select  name="ann_d" autocomplete="off"><option value="-1">Année</option>
										<option value="2010">2010</option> 
										<option value="2011">2011</option>
										<option value="2012">2012</option>
										<option value="2013">2013</option>
										<option value="2014">2014</option>
										<option value="2015">2015</option>
										<option value="2016">2016</option>
										<option value="2017">2017</option>
										<option value="2018">2018</option>
										<option value="2019">2019</option>
										<option value="2020">2020</option>
										<option value="2021">2021</option>
										</select>
        </p>
       </td>
          </tr>
            <tr align="center">
      <td width="147" align="RIGHT">Fournisseur:</td>
      <td width="229"align="LEFT"> <select name="frn" id="frn">
			  <?php
			  while($fournisseur=mysql_fetch_array($resulf)){ ?>
            <option value="<?php  echo $fournisseur['rais_social']; ?>"> <?php  echo $fournisseur['rais_social']; ?> </option>

<?php        }    ?>
			  
              </select></td>
      <td width="194" align="RIGHT">Prix:</td>
      <td width="250"align="LEFT"><input type="text" name="prix"></td>
          </tr>
           <tr align="center">
      <td width="147" align="RIGHT">N° BC Externe:</td>
      <td width="229"align="LEFT"><input type="text" name="nbcx" /></td>
      <td width="194" align="RIGHT" ROWSPAN ="2">Observation</td>
      <td width="250"ROWSPAN ="2"align="LEFT"><textarea name="observation" id="observation" cols="25" rows="2"></textarea></td>
          </tr>
        <tr align="center">
      <td width="147" align="RIGHT">Date BC Externe:</td>
      <td width="229"align="LEFT">
      <select  name="jour_b" autocomplete="off">
            <option value="-1">Jour</option>
            <option value="01">01</option> 
            <option value="02">02</option>
            <option value="03">03</option>
            <option value="04">04</option>
            <option value="05">05</option>
            <option value="06">06</option>
            <option value="07">07</option>
            <option value="08">08</option>
            <option value="09">09</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
            
          </select>
          <select name="mois_b"autocomplete="off"><option value="-1">Mois</option>
										<option value="01">01</option> 
										<option value="02">02</option>
										<option value="03">03</option>
										<option value="04">04</option>
										<option value="05">05</option>
										<option value="06">06</option>
										<option value="07">07</option>
										<option value="08">08</option>
										<option value="09">09</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										</select>
										<select  name="ann_b" autocomplete="off"><option value="-1">Année</option>
										<option value="2010">2010</option> 
										<option value="2011">2011</option>
										<option value="2012">2012</option>
										<option value="2013">2013</option>
										<option value="2014">2014</option>
										<option value="2015">2015</option>
										<option value="2016">2016</option>
										<option value="2017">2017</option>
										<option value="2018">2018</option>
										<option value="2019">2019</option>
										<option value="2020">2020</option>
										<option value="2021">2021</option>
										</select>
			</td>
              </tr>
         
        </table></CENTER>
        <br>
        <CENTER> <table width="874" border="0" cellspacing="10" cellpadding="0" bgcolor="#F8F8F8">
          <tr align="center">
          <td width="50%"align="RIGHT"><label for="button"></label>
            
            <input type="submit" name="ajouter" id="ajouter"   value="Ajouter" /></td>
          <td width="50%"align="LEFT"><label for="button2"></label>
            <input type="submit" name="button2" id="button2" value="Rénitialiser" />

			</td>
     
          </tr>
         
        </table></CENTER>
     
	
    </center>
  
    <CENTER>
    <table width="874" border="1" cellspacing="0" cellpadding="10" bgcolor="#F8F8F8">
              <tr align="center" style="background-color:#8EC6FD; color: #000;" >
                <td width="">N°ord</td>
                <td width="">N° facture</td>
                <td width="">Date facture</td>
                <td width="">Fournisseur</td>
                <td width="">Qtt livré</td>
                <td width="">Désignation</td>
              </tr>
 

            <tr> 
	

			 		
			
			<?php 
					while ( $resp2=mysql_fetch_array($res2)) {          ?>
						<td width="" align="left"> <?php echo $i=($i+1) ; ?></td>
                <td width=""><?php echo $resp2['nfact']; ?> </td>
				<td width=""><?php echo  $resp2['dat_var'] ; ?></td>
			 
				<td width=""><?php echo $resp2['nfour']; ?></td>
				<td width=""><?php echo $resp2['qttvar']  ; ?></td>
				<td width=""><?php echo $resp2['designation'] ; ?></td>
				
               
                
             
			  
	 </tr> 
	<?php } ?>
          </table>
		         <br />
     
              <input type="button" name="imp" id="imp" onclick="window.location='Imprission.php'"value="imprimer"   />
			  			<input type="submit" name="enregestrer" id="enregestrer" value="rénitialiser le tableau" /> 
<br />
    </CENTER>

   </form>
   <br />
   </div>
   
  <div id="PIED"> </div>
</div>
</body>
</html>
