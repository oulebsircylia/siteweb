<?php require_once('connexion.php'); ?>
<?php


session_start(); 

?>
<?php
$date = getdate(); 
$i=0 ;
$req2 = "SELECT *  FROM map  " ;
$res2= mysql_query($req2);
 


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style media="print" type="text/css">   
.noImpr {   display:none;   } .ttt {
	font-family: calibri;
}
#form1 #entete table tr td strong {
	font-family: calibri;
}
#form1 #entete table tr td {
	font-family: calibri;
}
#form1 #corp center table tr td {
	font-family: calibri;
}
</style>
</head>

<body>

 <form id="form1" name="form1" method="post" action="imprbnentre.php">
   <div id="entete">  <table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td width="41%" align="center">   <font face="Times New Roman, Times, serif"><strong>MINISTÉRE DE L'ENSEIGNEMENT SUPÉRIEUR 
<br/>ET DE LA RECHERCHE SCIENTIFIUE	</strong></font> <br />
<img align="center" width="15%" src="images/trait.jpg" />
			  <font face="Times New Roman, Times, serif"><br/><b>UNUVERSITE A.MIRA-BEJAIA</b> <br/>
			  <span class="ttt"><strong>Faculte Des Sciences Exactes </strong></span></font><br/>
			     </td>
    <td width="29%"><font face="Times New Roman, Times, serif"><br /><br /><br /><br /> </font></td>
    <td width="30%"> <BR /> BEJAIA ,le <?php echo date_format($date, 'Y-m-d'); ?>  <br/><br /><br /></td>
  </tr>
  <tr>
  <TD></TD>
  <td align="center" style="font:calibri" ><strong>BON D'ENTREE </strong></td>
  <TD align="left">N°:</TD>
  </tr>
  
</table><br/><br/><br/><br/><br/><br/>
               </div>
 
<div id="corp"> <CENTER>
 
    <table width="90%" border="1" cellspacing="0" cellpadding="10" bgcolor="#CCCCCC">
              <tr align="center"  style="font-family:calibri; font color:#006; background-color:#EBEBEB  " >
                <td width="7%" height="42">N°ord</td>
                <td width="14%">N° facture</td>
                <td width="16%">Date facture</td>
                <td width="16%">Fournisseur</td>
                <td width="13%">Qtt livré</td>
                <td width="34%">Désignation</td>
              </tr>
 

            <tr bgcolor="#FFFFFF" style="font:calibri"> 
	

			 		
			
			<?php 
					while ( $resp2=mysql_fetch_array($res2)) {          ?>
				<td width="7%" align="left"  bgcolor="#FFFFFF" style="font:calibri"> <?php echo $i=($i+1) ; ?></td>
                <td width="14%"  bgcolor="#FFFFFF" style="font:calibri"><?php echo $resp2['nfact']; ?> </td>
				<td width="16%"  bgcolor="#FFFFFF" style="font:calibri"><?php echo  $resp2['dat_var'] ; ?></td>
			 
				<td width="16%"  bgcolor="#FFFFFF" style="font:calibri"><?php echo $resp2['nfour']; ?></td>
				<td width="13%"  bgcolor="#FFFFFF" style="font:calibri"><?php echo $resp2['qttvar']  ; ?></td>
				<td width="34%"  bgcolor="#FFFFFF" style="font:calibri"><?php echo $resp2['designation'] ; ?></td>
				
               
                
             
			  
	 </tr> 
	<?php } ?>
    </table><br/><br/>
   </CENTER></div>


<table width="100%" border="0" cellspacing="3" cellpadding="3">
  <tr>
    <td align="center"><font face="Times New Roman, Times, serif"><strong>LE MAGASINIER </strong></font><BR /><br/>
    Nom et Prénom :.............<br/><br/>SIGNATURE</td>
    <td align="center" valign="middle">  
    <div class="noImpr"><br/><br/>
	<input name="imprim" type="button"onClick="window.print()" value="Imprimrer"> 
    <?php if(isset($_POST['imprim'])){ header("Location:imprission.PHP");} ?>
    </div>
    </td>
    <td align="center"><font face="Times New Roman, Times, serif"><strong>L'ACHETUER</strong><br/><br/> </font> Nom et Prénom :...........<br/><br/> SIGNATURE</td>
  </tr>
  
</table>


</form>
  <div id="PIED"> </div>


</body>
</html>
