<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_ma_connexion = "localhost";
$database_ma_connexion = "agence";
$username_ma_connexion = "root";
$password_ma_connexion = "mimia";
$ma_connexion = mysql_pconnect($hostname_ma_connexion, $username_ma_connexion, $password_ma_connexion) or trigger_error(mysql_error(),E_USER_ERROR); 
?>