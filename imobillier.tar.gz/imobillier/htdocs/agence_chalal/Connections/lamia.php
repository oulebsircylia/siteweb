<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_lamia = "localhost";
$database_lamia = "lamia";
$username_lamia = "root";
$password_lamia = "mimia";
$lamia = mysql_pconnect($hostname_lamia, $username_lamia, $password_lamia) or trigger_error(mysql_error(),E_USER_ERROR); 
?>