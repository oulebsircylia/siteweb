<?php

$cnx = mysql_connect( "localhost", "root", "mimia" );
  //s�lection de la base de donn�es:
 

  $db  = mysql_select_db("lamia");
  
	//On v�rifie que le formulaire a �tait envoyer
	if(isset($_POST['n_cl'], $_POST['p_cl'], $_POST['a_cl'], $_POST['a_m_cl'], $_POST['num_tel'], $_POST['l_cl'], $_POST['mdp'], $_POST['mdp2']) and $_POST['l_cl']!='' and $_POST['mdp']!='' and $_POST['mdp2']!='') {
		//On enl�ne l'ecappement si get_magic_..... est active (je suppose pour la s�curit�)
		if(get_magic_quotes_gpc()){
			$_POST['n_cl'] = stripslashes($_POST['n_cl']);
			$_POST['p_cl'] = stripslashes($_POST['p_cl']);
			$_POST['a_cl'] = stripslashes($_POST['a_cl']);
			$_POST['a_m_cl'] = stripslashes($_POST['a_m_cl']);
			$_POST['num_tel'] = stripslashes($_POST['num_tel']);
			$_POST['l_cl'] = stripslashes($_POST['l_cl']);
			$_POST['mdp'] = stripslashes($_POST['mdp']);
			$_POST['mdp2'] = stripslashes($_POST['mdp2']);
			echo "kkkk";
		}
		//On v�rifie si le mot de passe et celui de la v�rification sont idantiques
		if($_POST['mdp'] == $_POST['mdp2']){
		
			//On v�rifie si le mot de passe a 6 caract�res au plus
			if(strlen($_POST['mdp']) >= 6){
			
				//On v�rifie si l'email est valide
				if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['a_m_cl'])){
				
					//On echappe les variables pour pouvoir les mettres dans une requ�te sql
					$n_cl = mysql_real_escape_string($_POST['n_cl']);
					$p_cl = mysql_real_escape_string($_POST['p_cl']);
					$a_cl = mysql_real_escape_string($_POST['a_cl']);
					$a_m_cl = mysql_real_escape_string($_POST['a_m_cl']);
					$num_tel = mysql_real_escape_string($_POST['num_tel']);
					$l_cl = mysql_real_escape_string($_POST['l_cl']);
					$mdp = mysql_real_escape_string($_POST['mdp']);
					
					//On v�rifie s'in n y a pas deja un utilisateur inscrit avec le pseudo choisi
					$dn = mysql_num_rows(mysql_query('select id from client where login="'.$l_cl.'"'));
					if($dn == 0){
						//On r�cup�re le nombre d'utilisateurs pour donner un identifiant � l'utilisateur actuel
						$dn2 = mysql_num_rows(mysql_query('select id from client'));
						$id_cl = $dn2+1;
						//On enregistre les informations dans la base de donn�es
						if (mysql_query("INSERT INTO client (id, nom, prenom, num_tel, adresse, adresse_mail, login, password) VALUES ('
					$id_cl', '$n_cl', '$p_cl', '$num_tel','$a_cl', '$a_m_cl', '$l_cl', '$mdp')")){
						
							//Si �a fonctionne, on affiche pas le formulaire
							$form = false;						
							?>
							
									<script type="text/javascript">
										window.alert("Le client a �t� bien inserer");
										window.location.replace("http://localhost/agence_immobiliere/admin/liste des client .php");
							
									</script><?php
						//	header('location:liste des client .php');
						 
								

						}
						else{
							//Sinon on dit qu'il y a une erreur
							$form = true;
							?>
							<script type="text/javascript">
								window.alert("Une erreur est survenue lors de l'inscription");
							</script>
							<?php
						}
					}
					else{
					    //sinon on dit que le pseudo voulu est deja pris
						$form = true;
						?>
						<script type="text/javascript">
								window.alert("Le pseudo voulu est deja pris");
							</script>
						<?php
					
					}
				}
				else {
				  //sinon on dit que l'email n'est pas valide
				  $form = true;
				  ?>
						<script type="text/javascript">
								window.alert("L'email que vous avez entrer n'est pas valide");
							</script>
						<?php
				}
				
			}
			else{
			  //sinon on dit que le mot de passe n'est pas assez long
			  $form = true;
			  ?>
						<script type="text/javascript">
								window.alert("Le mot de passe que vous avez entrer contient moins de 6 caract�re");
							</script>
						<?php
			}
		}
		else{
		 //sinon on dit que les mots de passse ne sont pas identique
		 $form = true;
		 ?>
						<script type="text/javascript">
								window.alert("Les mots de passe que vous avez entrer ne sont pas identique");
							</script>
						<?php
		}
	}
	else{
	
	  $form = true;
	  ?>
						
						<?php
		}
	
if($form){

 //on affiche le message
 	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
}
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
</style>
<style>

#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}

#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}


#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:550px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:550px;
	border-left: 1px solid black;
	}	
.Style39 {font-size: 16px}
</style>

</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#FFFFFF" scope="col"><div align="right"><img src="../images/Capture.JPG" width="232" height="151" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/naima3.jpg" width="960" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onMouseMove="this.stop();" onMouseOut="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>




<nobr>

<ul id="menu" >
	<li><a href="../index.php">Acceuil</a>	</li>
	<li><a href="../recherche1.php">Recherche</a>	</li>
	<li><a href="../proposer1.php">Proposer</a>	</li>
	<li><a href="../inscription3.php">Inscription</a>	</li>	
		<li><a href="../mondat.php">Mondat</a>	</li>	
		
		</li>
	<li><a href="../apropos.php">A propos</a>	</li>
		
		
		
	<li><a href="../contact.php">Contactez-nous</a></li>
</ul>
</nobr>
<table width="1211" height="535" border="0">
  <tr>
    <th width="256" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
<ul id ="menu-accordeon">
<li><a href ="#">Gestion des client </a>
<ul>
<li> <a href="ajouter client.php"> Ajouter</a></li>
<li><a href="modifie un client.php">Modifie</a> </li>
<li><a href="supprimer client.php">Supprimer</a> </li>
   </ul>
   </li>
   
   <li><a href ="#">Gestion des bien </a>
<ul>
<li> <a href="ajouter_un_bien.php">Ajouter</a></li>
<li><a href="liste_modifier_bien.php">Modifier</a></li>
<li><a href="supprimer_bien.php">Supprimer</a></li>
   </ul>
   </li>
   
    
 
   <li><a href="consulter.php">consulter les biens  </a>
<ul>
   </ul>
   </li>
   <li><a href="../deconecter.php">Deconnecter  </a> </li>
   </ul></th>
      </tr>
    </table>
    
      <p>&nbsp;</p>
    <p>&nbsp;</p>
   
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
    <th width="939" align="center" valign="top" class="Style37" scope="col"><p class="id_client Style38"><strong>Ajouter un client</strong></p>
    <table align="center">
		
		<form method="post" action="" name="form1"/>
  <tr>
    <td><span class="Style39 id_client"><strong>Nom:</strong></span>    </td>
    <td><input  type="text" name="n_cl" /> </td>
  </tr>
  <tr>
    <td><span class="id_client"> <span class="Style39">
      <label for="login"><strong>Pr&eacute;nom:</strong></label>
    </span> </span></td>
    <td><input type="text" name="p_cl" /> </td>
  </tr>
  <tr>
    <td><span class="id_client"> <span class="Style39">
      <label for="login"><strong>Adresse:</strong></label>
    </span> </span></td>
    <td> <input type="text" name="a_cl" /></td>
  </tr>
  <tr>
    <td><span class="id_client"> <span class="Style39">
      <label for="login"><strong>Adresse_mail:</strong></label>
    </span> </span></td>
    <td><input type="text" name="a_m_cl"  /></td>
  </tr>
  <tr>
    <td>
      <span class="Style39 id_client"><strong> Numero_tel:</strong></span>   </td>
   

    <td><input type="int" name="num_tel" /></td>
  </tr>
    <tr>
            
      <td><span class="id_client"> <span class="Style39">
        <label for="login"><strong>Nom de compte :</strong></label>
      </span> </span></td>
      <td><input type="text" name="l_cl" id="login_cl"/></td>
            
    </tr>
            
         <tr>
            
           <td><span class="id_client"> <span class="Style39">
             <label for="pass"><strong>Mot de passe :</strong></label>
           </span> </span></td>
           <td><input type="password" name="mdp" id="mot_de_passe"/></td>
            
       </tr>
            
        <tr>
         
          <td><span class="id_client"> <span class="Style39">
            <label for="pass2"><strong>Confirmez le mot de passe :</strong></label>
          </span> </span></td>
          <td><input type="password" name="mdp2" id="mot_de_passe2"/></td>
</tr>
          <tr><td></td><td> <input type="submit" name="submit" value="          Ajouter         "/></td></tr>
		
        </form>
  </table>

<?php
}


?>

</body>
</html>
