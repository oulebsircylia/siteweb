<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
</body>
</html>
	 $sql='select * from bien, appartement, villa, entrepot, terrain order by id desc limit 0, 10';
	 $conn =config::connectDB();

     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table  ");
	 	 echo $sql;
	if(!empty($oRow)){ 
	 while($rows = mysqli_fetch_array($oRow)){?>
  
  <center>order by id desc limit 0, 10
		 
		</center>
  <tr>
    <td width="250" height="204"><img src="./images/<?php echo $rows['image1'] ;?>"  name="image" width="250px" height="200px"/></td>
    <td width="460"> 
	<strong>Type de bien:</strong>	<?php echo $rows['type_bien'] ;?><strong>.</strong>	<br>
	<strong>Prix:</strong>	<?php echo $rows['prix'] ;?> <strong>DA.</strong>	<br>
	<strong>Superficie:</strong>	<?php echo $rows['superficie']  ;?> <strong>m�.</strong>	<br />
	<br /><br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="voir.php?id=<?php echo $rows['id_bien'] ;?>"> + <em><strong>DE DETAILS</strong> </em></a>	</td>
  </tr>
  <?php }}
  ?>