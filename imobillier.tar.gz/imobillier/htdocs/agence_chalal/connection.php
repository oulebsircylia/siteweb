<?php
session_start();
if(isset($_SESSION['pseudo']))
{
header('location:member.php');
exit;
}
if(isset($_POST['submit']))
{
$pseudo = htmlspecialchars(trim($_POST['l_cl']));
$password = htmlspecialchars(trim($_POST['mdp']));

if(empty($pseudo))
{ ?>
						<script type="text/javascript">
								window.alert("veuillez saisir votre pseudo");
							</script>
						<?php 
	
  


}else if(empty($password))
{                       ?>
						<script type="text/javascript">
								window.alert("veuillez saisir votre mot de passe ");
							</script>
						<?php 
  

}else
{
mysql_connect('localhost','root','mimia');
mysql_select_db('lamia');



$login = mysql_query("SELECT * FROM client WHERE login='$pseudo' AND password='$password'");
$rows =mysql_num_rows($login);
                    

if($rows == 1)
{                        ?>
						<script type="text/javascript">
						window.alert("Vous �tes connecter ");
						 window.location.replace("http://localhost/agence_immobiliere/member.php");
						</script>
						<?php 
  $_SESSION['pseudo'] = $pseudo;
  
 
 
}else{   ?>
						<script type="text/javascript">
								window.alert("Nom d'utilisateur ou mot de passe incorrecte");
							</script>
						<?php }
//header("location:");					
  
}
}
?>