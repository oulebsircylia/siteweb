<?php
define('PASS','mimia');
define('HOST','localhost');
define('DATA_BASE','lamia');
define('USER','root');

 






class config{
 

   static function get_Id(){
        return $dbhost;
    }
static function affich() {
	echo config::get_Id();
	}
public static function connectDB() {
	$conn = mysqli_connect(HOST, USER,  PASS,  DATA_BASE);

	if (!$conn)
		exit('Erreur de connexion: '.mysqli_connect_error());

	return $conn;}
public static function toAscii($str, $replace=array(), $delimiter='-') {
	if( !empty($replace) ) {
		$str = str_replace((array)$replace, ' ', $str);
	}
	$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
	$clean = strtolower(trim($clean, '-'));
	$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);

	return $clean;
}
	}

?>