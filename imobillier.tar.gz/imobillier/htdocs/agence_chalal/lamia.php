<?php
session_start();
?>
 <?php

require_once('config.php' );
if(isset($_POST['submit'])){
     if(isset($_POST['t']))	$t=  $_POST['t'];  else $t="";
     if(isset($_POST['lieu']))	$lieu=  $_POST['lieu'];else $lieu="";
	 if($_POST['prix_min']!=''){	$prixinf=  $_POST['prix_min'];
	 }else $prixinf="0";
	if($_POST['prix_max']){$prixsup=  $_POST['prix_max'];}else $prixsup="9999999999"; 
 if(isset($_POST['type']))$type_tran=  $_POST['type'];
 
 //La recherche a partir de prix
if ($_POST['prix_min'] || $_POST['prix_max'])
	 {
	 $sql="SELECT * FROM bien WHERE ( prix > '$prixinf' and prix < '$prixsup' )";

	 $conn =config::connectDB();
     $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
     }
else {	
    // La recherche a partir de  type de transaction
	//Pour l'achat 
    if ($_POST['type']=="achat"){
	   $sql="SELECT * FROM bien, transaction WHERE type_transaction='achat' AND bien.id_bien=transaction.id_bien ";
	   $conn =config::connectDB();
       $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
	}
	//pour les autres 
	else {
		//Pour la location
		if ($_POST['type']=="location"){
	 		$sql="SELECT * FROM bien, transaction WHERE (type_transaction='location' AND bien.id_bien=transaction.id_bien )";
	 
	 		$conn =config::connectDB();
    		 $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
     	}
		//pour les deux qui restent
		else {
			//pour l'echange
			if ($_POST['type']=="echange"){
     			$sql="SELECT * FROM bien, transaction WHERE (type_transaction='echange' AND bien.id_bien=transaction.id_bien )";    
	 			$conn =config::connectDB();
     			$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
     		}
			else {
				if ($_POST['type']=="vente"){
     				$sql="SELECT * FROM bien, transaction WHERE (type_transaction='vente' AND bien.id_bien=transaction.id_bien )";    
	 				$conn =config::connectDB();
     				$oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
     			}
			}
		}
	}
 
 }
 
 
 
 
}
?>