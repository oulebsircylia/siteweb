<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index_adm.css" />
<title>Document sans titre</title>
<style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.Style1 {
	color: #0066FF;
	font-style: italic;
	font-size: xx-large;
}
.Style2 {color: #0066FF}
-->
</style></head>

<body>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><div align="right"><img src="../images/logopaint.jpg" width="198" height="90" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/entete2.jpg" width="940" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em></marquee> 
	 </th>
	 
   </tr>
</table>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="720" border="0" align="center">
  <tr>
    <th width="342" scope="col"><div align="right" class="Style1"><center>
      Bienvenue a dans votre espace administrateur 
    </center></div></th>
  </tr>
</table>
<table width="713" height="293" border="0" align="center" bgcolor="#CCCCCC">
  <tr>
    <th width="642" align="center" valign="top" scope="col">
	<div>
	 <div class="bouton"><p><a href="gestion des client .php">Gestion des biens </a></p></div>
   <div class="bouton"><p><a href="gestion des biens.php">Gestion des client </a></p></div>
    <div class="bouton"><p><a href="modifie login/mot de passe.php">Modifie login/mot de passe</a></p></div>
	 <div class="bouton"><p><a href="consuler les biens .php">Consuler les biens  </a></p></div>
   <div>
	&nbsp;</th>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center">&nbsp;</p>
<table width="1218" height="138" border="0" align="center" bordercolor="#000000">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style2"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style2"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style2"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style2"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style2"><em>E-mail:</em></p>
    <p align="center" class="Style2"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>
<p align="center">&nbsp;</p>
</body>
</html>
