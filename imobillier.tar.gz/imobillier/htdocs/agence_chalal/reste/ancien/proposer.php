<?php require_once('../Connections/agence_chalal.php'); ?>
<?php
$type_Recordset1 = "-1";
if (isset($_GET['type'])) {
  $type_Recordset1 = (get_magic_quotes_gpc()) ? $_GET['type'] : addslashes($_GET['type']);
}
mysql_select_db($database_agence_chalal, $agence_chalal);
$query_Recordset1 = sprintf("SELECT * FROM bien INNER JOIN appartement ON bien.%s= appartement.%s  INNER JOIN villa ON bien.%s= villa.%s  INNER JOIN terrain ON bien.%s= terrain.%s  INNER JOIN entrepot ON bien.%s= entrepot.%s WHERE %s = '%s'", $type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1,$type_Recordset1);
$Recordset1 = mysql_query($query_Recordset1, $agence_chalal) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('t').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('t_a').style.display= 'inline';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'inline';
	    document.getElementById('n_e').style.display= 'inline';
         document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		  document.getElementById('ca').style.display= 'none';
		  document.getElementById('n_f').style.display= 'none';
		  document.getElementById('n_�').style.display= 'none';
        } 
		  if (a == "terrain"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'inline';
			document.getElementById('n_f').style.display= 'inline';
			document.getElementById('n_�').style.display= 'none';
        } 
	if (a == "entrepot"){ 
		document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'inline';
		  document.getElementById('lo').style.display= 'inline';
		   document.getElementById('la').style.display= 'inline';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'none';
        } 
	
	
		
		   }
</script>
<style>
body {
	background-color: #FFFFFF;
	background-image:url();
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;


max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}
#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:250px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:250px;
	height:600px;
	border-left: 1px solid black;
	}	
</style>
</head>

<body>
<div id="conteneur">
	<div id="header">
		<div id="slogon" align="center">
				<img src="images/slogan.jpg" width="160" height="150" />
				<img src="images/naima3.jpg" width="960" height="150" />
		</div>
		<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col">
	 					<marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
						</marquee> 
	 				</th>
 			  </tr>
 			</table>
		</div>
			
		
			<ul id="menu" >
	<li><a href="index2.php">Acceuil</a>
		
	</li>
	<li><a href="recherche2.php">Recherche</a>
		
	</li>
	<li><a href="proposer2.php">Proposer</a>
		
	</li>
	<li><a href="inscription.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
			<li><a href="apropos.php"> A propos</a>
		
	</li>	
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	</ul>
	</div>
	<div id="corps">
		
		<div id="droite">
		</div>
		<div id="gauche">
		
		</div>
		<div id="milieu" align="center">
			<h1 align="center">Proposer un bien: </h1>
						<center>
						<form method="POST"  name="bien" action="">
							<table align="center" border="0">
								<tr>
									<td width="143">
									<input type="hidden" name="id_bien" />
								  <label for="bien"><span class="Style40">Bien:    </span></label>									</td>
    							  <td width="681"><select id="t" name="t" onchange="Changer()">
                                      <option value="vide"></option>
                                      <option value="appartement">Appartement</option>
                                      <option value="villa">Villa</option>
                                      <option value="terrain">Terrain</option>
                                      <option value="entrepot">Entrepot</option>
                                    </select>
    							    <select name="t_a" id="t_a" style="display:none">
                                      <option value="vide">Type</option>
                                      <option value="F1">F1</option>
                                      <option value="F2">F2</option>
                                      <option value="F3">F3</option>
                                      <option value="F4">F4</option>
                                      <option value="F5">F5</option>
                                      <option value="F5">F5+</option>
                                    </select>
									<input name="n_�" type="text" value="" id="n_�" placeholder="saisir le numero d'�tage" style="display:none"/>
    							    <select name="n_e" id="n_e" style="display:none">
                                      <option value="vide">Nombre d'�tage</option>
                                      <option value="1_�tage">1 �tage</option>
                                      <option value="2_�tages">2 �tages</option>
                                      <option value="3_�tages">3 �tages</option>
                                      <option value="4_�tages">4 �tages</option>
                                      <option value="5_�tages">5 �tage</option>
                                      <option value="+_de_5">+ de5 �tages </option>
                                    </select>
   						 <input name="p" type="text" value="" id="p" placeholder="nombre de piece" style="display:none"/>
		<input name="h" type="text" value="" id="h" placeholder="saisir la hauteur" style="display:none"/>
	<input name="lo" type="text" value="" id="lo" placeholder="saisir la longueur" style="display:none"/>
	<input name="la" type="text" value="" id="la" placeholder="saisir la largeur" style="display:none"/>
	<input name="n_f" type="text" value="" id="n_f" placeholder="saisir le nombre de fa�ade" style="display:none"/>
	
  <select name="ca" id="ca" style="display:none">
                                      <option value="vide">cat�gorie</option>
                                      <option value="1">Terrain urbanisable</option>
                                      <option value="2">Terrain agricol</option>
                                      <option value="3">Terrain industriel</option>
                                     
                                    </select>
			
							      </td>
								</tr>
								<tr>
									<td>
										<label for="cat�gorie" class="Style40">Type transaction: </label>	</td>
									<td>
										<select name="bi" id="bi" placeholder="Type de bien">
	 										<option value="vide"></option> 
											<option value="achat">Achat</option>
											<option value="location">Location</option>
											<option value="location">Echange</option>
									  </select>	</td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">Localisation: </label></td>
									<td>
										<input type="text" name="loca" id="loca" />	</td>
								</tr>
								<tr>
									<td>
										<label for="lieu" class="Style40">Lieu: </label></td>
									<td>
										<input type="text" name="li" id="li" />	</td>
								</tr>
								<tr>
									<td>
										<label for="superficie" class="Style40">Superficie: </label>	</td>
								  <td>
										<input type="number" name="sup" id="sup" />
										<span class="Style40">m�</span> </td>
								</tr>
								<tr>
									<td>
										<label for="prix" class="Style40">Prix: </label>									</td>
								  <td>
										<input type="number" name="pri" id="pri" />
										<span class="Style40">DA</span> </td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 1: </label>									    </td>
									<td><label>
									  <input type="file" name="1" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 2: </label>									    </td>
									<td><label>
									  <input type="file" name="2" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 3: </label>									    </td>
									<td><label>
									  <input type="file" name="3" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 4: </label>									    </td>
									<td><label>
									  <input type="file" name="4" />
									</label></td>
								</tr>
								<tr>
									<td>
										<label for="description" class="Style40">Ajouter image 5: </label>									    </td>
									<td><label>
									  <input type="file" name="5" />
									</label></td>
								</tr>
								<tr>
									<td>									</td>
									<td>
										<input type="submit" value="Valider"/>									</td>
								</tr>
						</table>
                          
      </form>
	  </center>
	    </div>
	<div id="footer" >
	  <table width="1218" height="138" align="center" border="0">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">Agence immobili&egrave;re CHALAL</p>
    <p align="center" class="Style9">Rue Aissat Idir Akbou -B&eacute;jaia-</p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">T&eacute;l:07-72-24-62-97</p>
    <p align="center" class="Style9">05-51-57-24-99</p>    </th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style9">E-mail:</p>
    <p align="center" class="Style9">chalal.immobilier@hotmail.fr</p></th>
  </tr>
</table>
	</div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>