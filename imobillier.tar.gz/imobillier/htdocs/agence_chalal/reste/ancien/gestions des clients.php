<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #CCCCCC;
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
.Style7 {font-size: x-large; font-style: italic; color: #0066ff;}
.Style11 {font-size: 14px; color: #000000; }
.Style13 {font-size: 14; color: #000000; }
-->
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><div align="right"><img src="../images/logopaint.jpg" width="198" height="90" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/entete2.jpg" width="940" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em>Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em></marquee> 
	 </th>
	 
   </tr>
</table>







<table width="555" border="1" align="center">
  <tr>
    <th width="112" scope="col">acceuil</th>
    <th width="112" scope="col">ajout</th>
    <th width="112" scope="col">modification</th>
    <th width="97" scope="col">supprission</th>
  </tr>
</table>
<table width="1211" height="611" border="1">
  <tr>
    <th width="256" scope="col"><table width="256" height="293" border="0"  bgcolor="#CCCCCC">
      <tr>
        <th width="355" align="center" valign="top" scope="col"> <div>
            <div class="bouton">
              <p><a href="gestion des client .php">Gestion des biens </a></p>
            </div>
          <div class="bouton">
              <p><a href="gestion des biens.php">Gestion des client </a></p>
          </div>
          <div class="bouton">
              <p><a href="modifie login/mot de passe.php">Modifie login/mot de passe</a></p>
          </div>
          <div class="bouton">
              <p><a href="consuler les biens .php">Consuler les biens </a></p>
          </div>
          <div class="bouton">
              <p><a href="consuler les biens .php">D&eacute;connexion</a></p>
          </div>
          <div>
          &nbsp;</th>
      </tr>
    </table></th>
    <th width="939" align="center" valign="top" class="Style7" scope="col"><p>la liste des clients </p>
      <table width="917" border="1">
        <tr>
          <th width="91" scope="col"><span class="Style11">id client</span></th>
          <th width="104" scope="col"><span class="Style11">nom client </span></th>
          <th width="122" scope="col"><p align="left" class="Style11">pr&eacute;nomclient</p>
          </th>
          <th width="112" scope="col"><span class="Style11">adresse client</span></th>
          <th width="108" scope="col"><span class="Style11">E_mail client </span></th>
          <th width="104" scope="col"><p align="left" class="Style11">num&eacute;ro client </p>
          </th>
          <th width="106" scope="col"><span class="Style11">login client </span></th>
          <th width="118" scope="col"><span class="Style11">mot de passe client </span></th>
        </tr>
      </table>
    <p>&nbsp;</p></th>
  </tr>
</table>
<table width="1218" height="138" border="0" align="center" bordercolor="#000000">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>







</body>
</html>
