<?php
if(isset($_POST['submit']))
{
$nom_cl =htmlentities(trim($_POST['nom']));
$prenom_cl=htmlentities(trim($_POST['prenom']));
$adresse_cl=htmlentities(trim($_POST['adresse']));
$adresse_mail_cl=htmlentities(trim($_POST['adresse_mail']));
$num_tel=htmlentities(trim($_POST['num_tel']));
$login_cl=htmlentities(trim($_POST['login']));
$mot_de_passe=htmlentities(trim($_POST['password']));
$mot_de_passe2=htmlentities(trim($_POST['mot_de_passe2']));
 if($nom_cl&&$prenom_cl&&$adresse_cl&&$adresse_mail_cl&&$num_tel&&$login_cl&&$mot_de_passe&&$mot_de_passe2){
 
 if($mot_de_passe==$mot_de_passe2)
 {
 $mot_de_passe=md5($mot_de_passe);
 $connect = mysql_connect('localhost','root','benamara') or die ('erreur'); 
 mysql_select_db('agence_chaalal');
 $reg = mysql_query("SELECT * FROM client WHERE login='$login'");
 $rows = mysql_num_rows($reg);
 
 if($rows==0)
 {
 
 $query= mysql_query("INSERT INTO client VALUES ('','$nom','$prenom','$adresse','$adresse_mail','$num_tel','$login','$password')"); 
 
 die("Inscription t�rmin�e");
 }else echo "Ce nom de compte n'est pas disponible ";
 
 }else echo "Les deux mot de passe doivent �tre identique";

}else echo "Veuillez saisir tous les champs";

}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
<form method="POST" name="client" action="inscription1.php">
<p><label for="login"><strong>id_client</strong></label>
 <input type="hidden" name="id_client" /></p>

 <p>  <label for="login"><strong>Nom:</strong></label>
    <input  type="text" name="nom_cl" /></p>
	 <p><label for="login"><strong>Pr�nom:</strong></label>
  <input type="text" name="prenom_cl" /> </p>
<p><label for="login"><strong>Adresse:</strong></label>
     <input type="text" name="adresse_cl" /></p>
   <p> <label for="login"><strong>Adresse_mail:</strong></label>
    <input type="text" name="adresse_mail_cl"  /></p>
 
  <p> <label for="login"><strong>Numero_tel:</strong></label>
    <input type="int" name="num_tel" /></p>
 
   <p>  <label for="login"><strong>Nom de compte :</strong></label>
      <input type="text" name="login_cl" id="login_cl"/></p>
   <p>   <label for="pass"><strong>Mot de passe :</strong></label>
     <input type="password" name="password" id="mot_de_passe"/></p>
     <p><label for="pass2"><strong>Confirmez le mot de passe :</strong></label>
   <input type="password" name="mot_de_passe2" id="mot_de_passe2"/></p>
   <p><input type="submit"  value="S'inscrire" name="submit"/></p>
</form>
</body>
</html>
