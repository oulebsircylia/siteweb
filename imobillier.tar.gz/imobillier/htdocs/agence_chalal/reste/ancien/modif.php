<?php require_once('../Connections/connexion1.php'); ?>

<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "bien")) {
  $updateSQL = sprintf("UPDATE bien SET localisation=%s, superficie=%s, prix=%s, lieu=%s, type=%s, num_etage=%s, type_appar=%s, nbr_etage=%s, nbr_pieces=%s, hauteur=%s, longueur=%s, largeur=%s, nbr_fa�ade=%s, categorie=%s, image1=%s, image2=%s, image3=%s, image4=%s, image5=%s WHERE id_bien=%s",
                       GetSQLValueString($_POST['loca'], "text"),
                       GetSQLValueString($_POST['sup'], "double"),
                       GetSQLValueString($_POST['pri'], "double"),
                       GetSQLValueString($_POST['li'], "text"),
                       GetSQLValueString($_POST['t'], "text"),
                       GetSQLValueString($_POST['n_�'], "text"),
                       GetSQLValueString($_POST['t_a'], "text"),
                       GetSQLValueString($_POST['n_e'], "text"),
                       GetSQLValueString($_POST['p'], "int"),
                       GetSQLValueString($_POST['h'], "double"),
                       GetSQLValueString($_POST['lo'], "double"),
                       GetSQLValueString($_POST['la'], "double"),
                       GetSQLValueString($_POST['n_f'], "int"),
                       GetSQLValueString($_POST['ca'], "text"),
                       GetSQLValueString($_POST['1'], "text"),
                       GetSQLValueString($_POST['2'], "text"),
                       GetSQLValueString($_POST['3'], "text"),
                       GetSQLValueString($_POST['4'], "text"),
                       GetSQLValueString($_POST['5'], "text"),
                       GetSQLValueString($_POST['id_bien'], "int"));

  mysql_select_db($database_connexion1, $connexion1);
  $Result1 = mysql_query($updateSQL, $connexion1) or die(mysql_error());

  $updateGoTo = "liste des biens .php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_bien = "-1";
if (isset($_GET['id_bien'])) {
  $colname_bien = (get_magic_quotes_gpc()) ? $_GET['id_bien'] : addslashes($_GET['id_bien']);
}
mysql_select_db($database_connexion1, $connexion1);
$query_bien = sprintf("SELECT * FROM bien WHERE id_bien = %s", $colname_bien);
$bien = mysql_query($query_bien, $connexion1) or die(mysql_error());
$row_bien = mysql_fetch_assoc($bien);
$totalRows_bien = mysql_num_rows($bien);

$requete=" SELECT type FROM  bien";
$resultat=mysql_query($requete);
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<script type="text/javascript" >
function Changer(){
     var a = document.getElementById('t').value;
	 
	 if (a == "appartement"){
	 
	 document.getElementById('t_a').style.display= 'inline';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'inline';
        } 
      if (a == "villa"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'inline';
	    document.getElementById('n_e').style.display= 'inline';
         document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		  document.getElementById('ca').style.display= 'none';
		  document.getElementById('n_f').style.display= 'none';
		  document.getElementById('n_�').style.display= 'none';
        } 
		  if (a == "terrain"){
	 document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'none';
		  document.getElementById('lo').style.display= 'none';
		   document.getElementById('la').style.display= 'none';
		    document.getElementById('ca').style.display= 'inline';
			document.getElementById('n_f').style.display= 'inline';
			document.getElementById('n_�').style.display= 'none';
        } 
	if (a == "entrepot"){ 
		document.getElementById('t_a').style.display= 'none';
	  document.getElementById('p').style.display= 'none';
	    document.getElementById('n_e').style.display= 'none';
		 document.getElementById('h').style.display= 'inline';
		  document.getElementById('lo').style.display= 'inline';
		   document.getElementById('la').style.display= 'inline';
		    document.getElementById('ca').style.display= 'none';
			document.getElementById('n_f').style.display= 'none';
			document.getElementById('n_�').style.display= 'none';
        } 
	
	
		
		   }
</script>

<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
.Style40 {color: #000000; font-size: 14px; }
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><div align="right"><img src="../images/logopaint.jpg" width="198" height="90" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/entete2.jpg" width="940" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>







<table width="1211" height="611" border="0">
  <tr>
    <th width="367" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
              <ul id ="menu-accordeon">
                <li><a href ="#">Gestion des client </a>
                    <ul>
                      <li> <a href="ajouter client.php"> Ajouter</a></li>
                      <li><a href="modifie un client.php">Modifie</a> </li>
                      <li><a href="supprimer un client .php">Supprimer</a> </li>
                    </ul>
                </li>
                <li><a href ="#">Gestion des bien </a>
                    <ul>
                      <li> <a href="ajouter un bien.php">Ajouter</a></li>
                      <li><a href="modifie un bien.php">Modifie</a></li>
                      <li><a href="supprimer un bien.php">Supprimer</a></li>
                    </ul>
                </li>
                <li><a href="modifier le mot de passe.php">Modifie login et mot de passe </a> </li>
                <li><a href="consulter.php">consulter les biens </a>
                    <ul>
                    </ul>
                </li>
              </ul></th>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
    <th width="834" align="center" valign="top" class="Style37" scope="col"><p class="Style38">Modifie un bien </p>
	
       <form action="<?php echo $editFormAction; ?>" method="POST"  name="bien">
							<table align="center" border="0">
                            <tr>
                              <td width="143"><input type="hidden" name="id_bien" <?php echo $row_bien['id_bien']; ?>/>
                                  <?php echo $row_bien['id_bien']; ?>
                                  <label for="bien"><span class="Style40">Bien: </span></label>
                              </td>
                              <td width="681"><select id="t" name="t" onchange="Changer()">
                                <?php  while ($bien=mysql_fetch_array($resultat)){ ?>
                                  <option value=" <?php echo $bien['id_bien']; ?>" > <?php echo $bien['type']; ?></option>
								    
									<?php }?>
									
                                  <?php
do {  
?>
                                  <option value="<?php echo $row_bien['type']?>"<?php if (!(strcmp($row_bien['type'], $row_bien['id_bien']))) {echo "selected=\"selected\"";} ?>><?php echo $row_bien['type']?></option>
                                  <?php
} while ($row_bien = mysql_fetch_assoc($bien));
  $rows = mysql_num_rows($bien);
  if($rows > 0) {
      mysql_data_seek($bien, 0);
	  $row_bien = mysql_fetch_assoc($bien);
  }
?>
                                </select>
                                  <select name="t_a" id="t_a" style="display:none">
                            
                                    <option value="<?php echo $row_bien['type_appar']; ?>">F1</option>
                                    <option value="<?php echo $row_bien['type_appar']; ?>">F2</option>
                                    <option value="<?php echo $row_bien['type_appar']; ?>">F3</option>
                                    <option value="<?php echo $row_bien['type_appar']; ?>">F4</option>
                                    <option value="<?php echo $row_bien['type_appar']; ?>">F5</option>
                                    <option value="<?php echo $row_bien['type_appar']; ?>">F5+</option>
                                  </select>
                                  <select name="n_e" id="n_e" style="display:none">
                                    
                                    <option value="<?php echo $row_bien['nbr_etage']; ?>">1 �tage</option>
                                    <option value="<?php echo $row_bien['nbr_etage']; ?>">2 �tages</option>
                                    <option value="<?php echo $row_bien['nbr_etage']; ?>">3 �tages</option>
                                    <option value="<?php echo $row_bien['nbr_etage']; ?>">4 �tages</option>
                                    <option value="<?php echo $row_bien['nbr_etage']; ?>">5 �tage</option>
                                    <option value="<?php echo $row_bien['nbr_etage']; ?>">+ de5 �tages </option>
                                  </select>
                                  <input name="p" type="text" value="" id="p" placeholder="nombre de piece" style="display:none"/>
                                  <input name="h" type="text" value="<?php echo $row_bien['hauteur']; ?>" id="h" placeholder="saisir la hauteur" style="display:none"/>
                                  <input name="lo" type="text" value="<?php echo $row_bien['longueur']; ?>" id="lo" placeholder="saisir la longueur" style="display:none"/>
                                  <input name="la" type="text" value="<?php echo $row_bien['largeur']; ?>" id="la" placeholder="saisir la largeur" style="display:none"/>
                                  <input name="n_f" type="text" value="<?php echo $row_bien['nbr_fa�ade']; ?>" id="n_f" placeholder="saisir le nombre de fa�ade" style="display:none"/>
                                  <input name="n_�" type="text" value="<?php echo $row_bien['num_etage']; ?>" id="n_�" placeholder="saisir le numero d'�tage" style="display:none"/>
                                  <select name="ca" id="ca" style="display:none">
                                    
                                    <option value="<?php echo $row_bien['categorie']; ?>">Terrain urbanisable</option>
                                    <option value="<?php echo $row_bien['categorie']; ?>">Terrain agricol</option>
                                    <option value="<?php echo $row_bien['categorie']; ?>">Terrain industriel</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td><label for="cat�gorie" class="Style40">Type transaction: </label>
                              </td>
                              <td><select name="bi" id="bi" placeholder="Type de bien">
                                 
                                  <option value="achat">Achat</option>
                                  <option value="location">Location</option>
                                  <option value="location">Echange</option>
                                </select>
                              </td>
                            </tr>
                            <tr>
                              <td><label for="lieu" class="Style40">Localisation: </label></td>
                              <td><input type="text" name="loca" id="loca" value="<?php echo $row_bien['localisation']; ?>"/>
                              </td>
                            </tr>
                            <tr>
                              <td><label for="lieu" class="Style40">Lieu: </label></td>
                              <td><input type="text" name="li" id="li" value="<?php echo $row_bien['lieu']; ?>"/>
                              </td>
                            </tr>
                            <tr>
                              <td><label for="superficie" class="Style40">Superficie: </label>
                              </td>
                              <td><input type="number" name="sup" id="sup" value="<?php echo $row_bien['superficie']; ?>"/>
                                  <span class="Style40">m�</span> </td>
                            </tr>
                            <tr>
                              <td><label for="prix" class="Style40">Prix: </label>
                              </td>
                              <td><input type="number" name="pri" id="pri" value="<?php echo $row_bien['prix']; ?>"/>
                                  <span class="Style40">DA</span> </td>
                            </tr>
                            <tr>
                              <td><label for="description" class="Style40">Ajouter image 1: </label>
                              </td>
                              <td><label>
                                <input type="file" name="1" value="<?php echo $row_bien['image1']; ?>"/>
                              </label></td>
                            </tr>
                            <tr>
                              <td><label for="description" class="Style40">Ajouter image 2: </label>
                              </td>
                              <td><label>
                                <input type="file" name="2" value="<?php echo $row_bien['image2']; ?>"/>
                              </label></td>
                            </tr>
                            <tr>
                              <td><label for="description" class="Style40">Ajouter image 3: </label>
                              </td>
                              <td><label>
                                <input type="file" name="3" value="<?php echo $row_bien['image3']; ?>"/>
                              </label></td>
                            </tr>
                            <tr>
                              <td><label for="description" class="Style40">Ajouter image 4: </label>
                              </td>
                              <td><label>
                                <input type="file" name="4" value="<?php echo $row_bien['image4']; ?>"/>
                              </label></td>
                            </tr>
                            <tr>
                              <td><label for="description" class="Style40">Ajouter image 5: </label>
                              </td>
                              <td><label>
                                <input type="file" name="5" value="<?php echo $row_bien['image5']; ?>"/>
                              </label></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td><input type="submit" value="Valider"/>
                              </td>
                            </tr>
                            </ta>
                            <input type="hidden" name="MM_update" value="bien">
      </form>
    <p>&nbsp;</p></th>
  </tr>
</table>
<p>&nbsp;</p>
<table width="1218" height="138" border="0" align="center" bordercolor="#000000" bgcolor="#006666">
  <tr bgcolor="#666666"> <th width="391" height="132" align="center" valign="top" bgcolor="#006699" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#003333" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>







</body>
</html>
<?php
mysql_free_result($bien);
?>

