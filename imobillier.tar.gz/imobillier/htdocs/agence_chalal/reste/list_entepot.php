<?php require_once('../Connections/ag.php'); ?>
<?php
mysql_select_db($database_ag, $ag);
$query_Recordset1 = "SELECT * FROM entrepot";
$Recordset1 = mysql_query($query_Recordset1, $ag) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
.Style47 {color: #FFFFFF; font-size: 14px; }
.Style48 {font-size: 14px}
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><div align="right"><img src="../images/slogan.jpg" width="150" height="153" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/naima3.jpg" width="960" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>







<p>&nbsp;</p>
<table width="1211" height="611" border="0">
  <tr>
    <th width="256" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
<ul id ="menu-accordeon">
<li><a href ="#">Gestion des client </a>
  <ul>
<li> <a href="ajouter client.php"> Ajouter</a></li>
<li><a href="modifie un client.php">Modifie</a> </li>
<li><a href="supprimer un client .php">Supprimer</a> </li>
   </ul>
   </li>
   
   <li><a href ="#">Gestion des bien </a>
     <ul>
<li> <a href="ajout_bien.php">Ajouter</a></li>
<li><a href="modif_bien.php">Modifie</a></li>
<li><a href="sup_bien.php">Supprimer</a></li>
   </ul>
   </li>
   
    
   <li><a href="modifier le mot de passe.php">Modifie login et mot de passe </a>   </li>
   
     
   <li><a href="consulter.php">Consulter les biens  </a>
     <ul>
   </ul>
   </li>
   </ul></th>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>

    <th width="939" align="center" valign="top" class="Style37" scope="col"><p class="Style38">La liste des biens </p>
      <table width="783" border="1" bordercolor="#000000">
        <tr>
		
		
          <th width="79" scope="col"><span class="Style47 Style38 Style48">id bien </span></th>
		    <th width="117" scope="col"><span class="Style47">largeur</span></th>
          <th width="111" scope="col"><span class="Style47">longueur</span></th>
          <th width="79" scope="col"><span class="Style47">hauteur</span></th>
          <th width="117" scope="col"><span class="Style47">description</span></th>
          <th width="111" scope="col"><span class="Style47">superficier</span></th>
          <th width="79" scope="col"><span class="Style47">prix</span></th>
          <th width="59" scope="col"><span class="Style47">lieu</span></th>
          <th width="117" scope="col"><span class="Style47">modifier</span></th>
        </tr>
        <tr>
          
          <?php do { ?>
            <td><span class="Style48"><?php echo $row_Recordset1['id_entrepot']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['largeur']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['longueur']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['hauteur']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['description']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['superficie']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['prix']; ?></span></td>
            <td><span class="Style48"><?php echo $row_Recordset1['lieu']; ?></span></td>
            <td><span class="Style48"><a href="modif_entepot.php?id_entrepot=<?php echo $row_Recordset1['id_entrepot']; ?>"><img src="../ges/images/Modify.png" width="24" height="24" border="0" /></a></span></td>
            <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?></tr>
      </table>
      <p>&nbsp;</p>
</table>

<table width="1218" height="138" border="0" align="center" bordercolor="#000000">
  <tr bgcolor="#666666">
    <th width="391" height="132" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>







</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
