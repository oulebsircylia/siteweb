<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>
<script language="javascript"> 
 
imgPath = new Array; 
 
SiClickGoTo = new Array; 
 
version = navigator.appVersion.substring(0,1); 
 
if (version >= 3) 
 
	{ 
 
	i0 = new Image; 
 
	i0.src = 'url_image0'; 
 
	SiClickGoTo[0] = "Lien0"; 
 
	imgPath[0] = i0.src; 
 
	i1 = new Image; 
 
	i1.src = 'url_image1'; 
 
	SiClickGoTo[1] = "Lien1"; 
 
	imgPath[1] = i1.src; 
 
	i2 = new Image; 
 
	i2.src = 'url_image2'; 
 
	SiClickGoTo[2] = "Lien2"; 
 
	imgPath[2] = i2.src; 
 
	} 
 
a = 0; 
 
function StartAnim() 
 
	{ 
 
	if (version >= 3) 
 
		{ 
 
		document.write('<a href="#" onclick="ImgDest();return(false)"><img src="url_image0" border="0" alt="Menu" name="defil" /></a>'); 
 
		defilimg() 
 
		} 
 
	else 
 
		{ 
 
		document.write('<a href="Lien0"><img src="url_image0" border="0" /></a>') 
 
		} 
 
	} 
 
function ImgDest() 
 
	{ 
 
	document.location.href = SiClickGoTo[a-1]; 
 
	} 
 
function defilimg() 
 
	{ 
 
	if (a == 3) 
 
		{ 
 
		a = 0; 
 
		} 
 
	if (version >= 3) 
 
		{ 
 
		document.defil.src = imgPath[a]; 
 
		tempo3 = setTimeout("defilimg()",5000); 
 
		a++; 
 
		} 
 
	} 
 
</script>
function StartAnim()  
 
	{  
 
	if (version >= 3)  
 
		{  
 
		document.write('<a href="#" onclick="ImgDest();return(false)"><img src="images/slogan.jpg" border="0" alt="Menu" name="defil" /></a>');  
 
		defilimg()  
 
		}  
 
	else  
 
		{  
 
		document.write('<a href="http://www.zonewebmaster.eu"><img src="http://www.zonewebmaster.eu/images/carte_cuisine_g.png" border="0" /></a>')  
 
		}  
 
	}
<body>
</body>
</html>
