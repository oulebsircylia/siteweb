<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="CSS/style.css" />
<title>Document sans titre</title>
 
<script language="javascript"> 
 
imgPath = new Array; 
 
SiClickGoTo = new Array; 
 
version = navigator.appVersion.substring(0,1); 
 
if (version >= 3) 
 
	{ 
 
	i0 = new Image; 
 
	i0.src = 'url_image0'; 
 
	SiClickGoTo[0] = "images/slogan.jpg"; 
 
	imgPath[0] = i0.src; 
 
	i1 = new Image; 
 
	i1.src = 'url_image1'; 
 
	SiClickGoTo[1] = "Lien1"; 
 
	imgPath[1] = i1.src; 
 
	i2 = new Image; 
 
	i2.src = 'url_image2'; 
 
	SiClickGoTo[2] = "Lien2"; 
 
	imgPath[2] = i2.src; 
 
	} 
 
a = 0; 
 
function StartAnim() 
 
	{ 
 
	if (version >= 3) 
 
		{ 
 
		document.write('<a href="#" onclick="ImgDest();return(false)"><img src="agence_immobiliere/images/slogan.jpg" border="0" alt="photo pour les " name="defil" /></a>'); 
 
		defilimg() 
 
		} 
 
	else 
 
		{ 
 
		document.write('<a href="Lien0"><img src="url_image0" border="0" /></a>') 
 
		} 
 
	} 
 
function ImgDest() 
 
	{ 
 
	document.location.href = SiClickGoTo[a-1]; 
 
	} 
 
function defilimg() 
 
	{ 
 
	if (a == 3) 
 
		{ 
 
		a = 0; 
 
		} 
 
	if (version >= 3) 
 
		{ 
 
		document.defil.src = imgPath[a]; 
 
		tempo3 = setTimeout("defilimg()",5000); 
 
		a++; 
 
		} 
 
	} 
 
</script>
<style type="text/css">
<!--
.Style1 {font-size: 12px}
-->
</style>
</head>

<body>
 <table width="995">
  <tr>
    <th width="150" height="150" scope="col"><div align="center"><img src="images/slogan.jpg" width="150" height="150" /></div></th>
    <th width="900" scope="col"><div align="center"><img src="images/entete.jpg" width="900" height="150" /></div></th>
  </tr>
</table>

  <tr>
   
   <div align="center">
     <form id="form1" name="form1" method="post" action="">
       <table width="876">
	  <tr>
	    <th width="151" scope="col"><input name="Submit3" type="submit" class="Style1" value="            Accuiel            " /> </th>
        <th width="188" scope="col"><input type="submit" name="Submit2" value="             Recherche               " /></th>
		 <th width="183" scope="col"><input type="submit" name="Submit" value="               Proposer              " /></th>
		 <th width="159" scope="col">  <input type="submit" name="Submit" value="            Inscrire             " /></th>
		  <th width="171" scope="col"><input type="submit" name="Submit" value="                 Contact           " /></th>
	    </tr>
</table>

     </form>
    </div>
    
   
 
<table width="1107" height="95">
  <tr>
    <th scope="col"><div class="popup">
   <img src="images/slogan.jpg" alt="texte_alternatif" title="Cliquez pour voir en grand !" />
</div></th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
