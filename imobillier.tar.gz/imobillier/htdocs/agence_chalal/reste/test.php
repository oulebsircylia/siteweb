<?php

  $cnx = mysql_connect( "localhost", "root", "" );
  //s�lection de la base de donn�es:
 

  $db  = mysql_select_db("agence_chaalal");
	$requete = mysql_query("SELECT * FROM appartement", $cnx) or die( mysql_error()) ;
		
		  while($rows = mysqli_fetch_array($requete)){
		 echo $rows['id_bien']; 
		  }
?>
