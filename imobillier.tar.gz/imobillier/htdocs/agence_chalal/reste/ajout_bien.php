<?php require_once('../Connections/conn.php'); ?>
<?php
mysql_select_db($database_conn, $conn);
$query_Recordset1 = "SELECT * FROM bien";
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="gestion.css" />
<title>Document sans titre</title>


<style type="text/css">
<!--
.Style2 {color: #F0F0F0}
body {
	background-color: #666666;
	background-image: url(../images/BACKGROUND.jpg);
}
.Style3 {color: #0066ff; }
.Style4 {color: #0066FF; }
-->
</style>
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 300px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
.id_client {color: #000000}
.Style37 {color: #0066ff; font-size: x-large;}
.Style38 {color: #FFFFFF}
.Style44 {color: #FFFFFF; font-size: 14px; }
.Style45 {color: #FFFFFF; font-size: xx-large; }
</style>
</head>

<body>
<span class="Style2"></span>
<table width="1270">
  <tr>
    <th width="225" height="150" bgcolor="#CCCCCC" scope="col"><div align="right"><img src="../images/Capture.JPG" width="149" height="151" /></div></th>
    <th width="987" scope="col"><div align="center"><img src="../images/naima3.jpg" width="960" height="150" /></div></th>
  </tr>
</table>
<table width="1215" border="0" align="center">
   <tr>
     <th width="848" borde="0" rscope="col">
	 <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();"><em><span class="Style38">Agence Immobili�re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</span></em>
	 </marquee>	 </th>
	 
   </tr>
</table>







<table width="1211" height="611" border="0">
  <tr>
    <th width="367" scope="col"><table width="256" height="293" border="0">
      <tr>
        <th width="355" align="center" valign="top" scope="col">&nbsp;
              <ul id ="menu-accordeon">
                <li><a href ="#">Gestion des client </a>
                    <ul>
                      <li> <a href="ajouter client.php"> Ajouter</a></li>
                      <li><a href="modifie un client.php">Modifie</a> </li>
                      <li><a href="supprimer un client .php">Supprimer</a> </li>
                    </ul>
                </li>
                <li><a href ="#">Gestion des bien </a>
                    <ul>
                      <li> <a href="ajout_bien.php">Ajouter</a></li>
                      <li><a href="modif_bien.php">Modifie</a></li>
                      <li><a href="sup_bien.php">Supprimer</a></li>
                    </ul>
                </li>
                <li><a href="modifier le mot de passe.php">Modifie login et mot de passe </a> </li>
                <li><a href="consulter.php">consulter les biens </a>
                    <ul>
                    </ul>
                </li>
              </ul></th>
      </tr>
    </table>
    
	
    </th>
    <th width="834" align="center" valign="top" class="Style37" scope="col"><p class="Style38">&nbsp;</p>
      <p class="Style45">bienvenu a votre espace d'ajout </p>
      <p class="Style38">&nbsp;</p>
      <form method="POST"  name="bien">
         <table width="410" border="1">
           <tr>
             <td width="109"><span class="Style44"><a href="ajout_appar.php">apparetement</a></span></td>
             <td width="94"><span class="Style44"><a href="ajout_villa.php">villa</a></span></td>
             <td width="79"><span class="Style44"><a href="ajout_terrain.php">terrain</a></span></td>
             <td width="100"><span class="Style44"><a href="ajout_entropot.php">entrepot</a></span></td>
           </tr>
         </table>
      </form>
    <p>&nbsp;</p></th>
  </tr>
</table>
<p>&nbsp;</p>
<table width="1218" height="138" border="0" align="center" bordercolor="#000000" bgcolor="#006666">
  <tr bgcolor="#666666"> <th width="391" height="132" align="center" valign="top" bgcolor="#006699" scope="col"><p align="center" class="Style4"><em>Agence immobili&eacute;re CHALAL</em></p>
    <p align="center" class="Style4"><em>Rue Aissat Idir Akbou-B&eacute;jaia-</em></p></th>
    <th width="393" align="center" valign="top" bgcolor="#003333" scope="col"><p align="center" class="Style3"><em>T&eacute;l:07-72-24-62-97</em></p>
    <p align="center" class="Style3"><em>05-51-57-24-99</em></p></th>
    <th width="418" align="center" valign="top" bgcolor="#999999" scope="col"><p align="center" class="Style4"><em>E-mail:</em></p>
      <p align="center" class="Style4"><em>chalal.immobilier@hotmail.fr</em></p></th>
  </tr>
</table>







</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
