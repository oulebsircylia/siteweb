<?php
session_start();
?>
 <?php

require_once('config.php' );

if(isset($_POST['submit'])){
     if(isset($_POST['t']))	$t=  $_POST['t'];  else $t="";
     if(isset($_POST['lieu']))	$lieu=  $_POST['lieu'];else $lieu="";
	 if($_POST['prix_min']!=''){	$prixinf=  $_POST['prix_min'];
	 }else $prixinf="0";
	if($_POST['prix_max']){$prixsup=  $_POST['prix_max'];}else $prixsup="9999999999"; 
 if(isset($_POST['type']))$type_tran=  $_POST['type'];
 //La recherche � partir l'appartement
 if($_POST['t']=="appartement"){

   if ($_POST['type']){

       if ($_POST['lieu']){ 
           //tout le formulaire est rempli
          if  ($_POST['prix_min'] ||$_POST['prix_max']){   
             $sql="SELECT  * FROM  bien,  appartement, transaction WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND             bien.id_bien=appartement.id_bien AND type_bien='$t'      AND type_transaction='$type_tran' AND lieu='$lieu' AND prix > '$prixinf' AND prix             < '$prixsup')";
            $conn =config::connectDB();
            $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
          } 
         //tout le formulaire sauf les zones de prix
		 else    
           {
             $sql="SELECT  * FROM  bien,  appartement, transaction
             WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND 
             bien.id_bien=appartement.id_bien AND type_bien='$t' AND type_transaction='$type_tran'
             AND lieu='$lieu' )";
            $conn =config::connectDB();
            $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
          }
        }
	//Sans les zones des prix et la zone de lieu
     else{
         $sql="SELECT  * FROM  bien,  appartement, transaction
          WHERE(accord=1 AND transaction.id_bien=bien.id_bien  AND 
          bien.id_bien=appartement.id_bien AND type_bien='$t' AND type_transaction='$type_tran')";
         $conn =config::connectDB();
        $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
        }
     }
    //Sans les zonezs des prix, la zone de lieu et la zone de transaction
  else{

     $sql="SELECT  * FROM  bien,  appartement
     WHERE(accord=1  AND bien.id_bien=appartement.id_bien AND type_bien='appartement')";
     $conn =config::connectDB();
      $oRow  = mysqli_query($conn, $sql) or die("Erreur de lecture de la table table");
     }
     }
	}
	//La recherche � partir  le villa
	
	
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
  <link rel="stylesheet"  href="calendrier/calendar.css" type="text/css" media="all" />
 <script type="text/javascript" src="yui/yahoo-dom-event/yahoo-dom-event.js"></script>
<script type="text/javascript" src="calendrier/calendar.js"></script>
<script type="text/javascript" src="calendrier/FrenchCalendar.js"></script>
<script type="text/javascript">
//<![CDATA[

	function init() {
		cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
		YAHOO.ap.calendar.FrenchCalendarSet(cal1);
		cal1.render();
	}

	YAHOO.util.Event.onDOMReady(init);
//]]>
</script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="index.css" />
<link rel="stylesheet" href="index3.css" />
<title>Document sans titre</title>
<script>
var imgs=new Array();
imgs[0]="images/8321_20090110051149img_1150.jpg";
imgs[1]="images/maison-positive.jpg";
imgs[2]="images/img-8222-pour-le-web-7266.jpg";
imgs[3]="images/trisor-interieur-appartement-03.jpg";
imgs[4]="images/images (11).jpg";

var cpt=0;
function changeimages()
{
	document.getElementById("ima").src=imgs[cpt];
	cpt++;
	if(cpt>=imgs.length) cpt=0;
	setTimeout("changeimages()",2500);
}
</script>


<style>
body {
	background-color: #FFFFFF;
	background-image:url(images/imageaa.jpg);
}
#menu, #page ul{
padding:0;
margin:0;
list-style:none;
text-align:center;
}
#menu li{
display:inline-block;
position:relative;
border-radius:8px 8px 0 0;
}
#menu ul li{
display:inherit;
border-radius:0;
}
#menu ul li:hover{
border-radius:0;
}
#menu ul li:last-child{
border-radius:0 0 8px 8px;
}
#menu ul{
position:absolute;
max-height:0;
width:100%;
overflow:hidden;
-moz-transition: .8s all .3s;
-webkit-transition: .8s all .3s;
transition: .8s all .3s;
}
#menu li:hover ul{
max-height:15em;
}
/* background des liens menus */
#menu li:first-child{
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #000066 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000066 0%, #2A2333 100%);
}
#menu li:nth-child(2){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003399 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003399 0%, #2A2333 100%);
}
#menu li:nth-child(3){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000099 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000099 0%, #2A2333 100%);
}
#menu li:nth-child(4){
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #0033FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0033FF 0%, #2A2333 100%);
}
#menu li:nth-child(5){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #0000CC 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0000CC 0%, #2A2333 100%);
}
#menu li:nth-child(6){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #0000FF 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #0000FF 0%, #2A2333 100%);
}

#menu li:nth-child(7){
background-color: #65537A;
background-image:-webkit-linear-gradient(top, #003366 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #003366 0%, #2A2333 100%);
}

#menu li:last-child{
background-color:#65537A ;
background-image:-webkit-linear-gradient(top, #000033 0%, #2A2333 100%);
background-image:linear-gradient(to bottom, #000033 0%, #2A2333 100%);
}
/* background des liens sous menus */
#menu  li:first-child li{
background:#333A40;
}
#menu li:nth-child(2) li{
background:#333A40;
}
#menu li:nth-child(3) li{
background:#9F391A;
}

#menu li:last-child li{
background:#677F35;
}
/* background des liens menus et sous menus au survol */
#menu li:first-child:hover, #menu li:first-child li:hover{
background:#729EBF;
}
#menu li:nth-child(2):hover, #menu li:nth-child(2) li:hover{
background:#729EBF;
}
#menu li:nth-child(3):hover, #menu li:nth-child(3) li:hover{
background:#729EBF;
}
#menu li:nth-child(4):hover, #menu li:nth-child(4) li:hover{
background:#729EBF;
}
#menu li:nth-child(5):hover, #menu li:nth-child(5) li:hover{
background:#729EBF;
}
#menu li:nth-child(6):hover, #menu li:nth-child(6) li:hover{
background:#729EBF;
}
#menu li:nth-child(7):hover, #menu li:nth-child(7) li:hover{
background:#729EBF;
}

#menu li:last-child:hover, #menu li:last-child li:hover{
background:#729EBF;
}
/* les a href */
#menu a{
text-decoration:none;
display:block;
padding:8px 32px;
color:#fff;
font-family:arial;
}
#menu ul a{
padding:8px 0;
}
#menu li:hover li a{
color:#fff;
text-transform:inherit;
}
#menu li:hover a, #menuli li:hover a{
color:#000;
}
div#droite {
	float:left;
	width:270px;
	height:600px;
	border-right: 1px solid black;
	}
div#gauche {
	float:right;
	width:270px;
	height:600px;
	border-left: 1px solid black;
	}	
.Style2 {color: #FFFFFF}
.Style3 {font-size: 24px}
.Style16 {font-family: Georgia, "Times New Roman", Times, serif}
.Style7 {	font-size: 18px;
	font-family: Georgia, "Times New Roman", Times, serif;
	font-style: italic;
	font-weight: bold;
}
</style>

</head>

<body onLoad="changeimages()" >
<div id="conteneur">
<div id="header">
		
			<div id="slogon" align="center"><img src="images/warda.jpg" width="149" height="151" /><span class="Style2"><em><img src="images/naima3.jpg" width="960" height="150" /></em></span></div>
			<div id="text_d�filer">
			<table width="1120" border="0" align="center">
   				<tr>
					<th width="300" borde="0" rscope="col"> <span class="Style2">
				    <marquee behavior="scroll" onmousemove="this.stop();" onmouseout="this.start();">
				      <em>Agence Immobili&eacute;re CHALAL &nbsp; &nbsp; &nbsp;Tous types de transactions  &nbsp; &nbsp; &nbsp;    Ventes-Achats-Echanges-Location  &nbsp;&nbsp;&nbsp;   Appart-Villa-Terrain-Locaux</em>
			        </marquee>
					  </span> </th>
   				</tr>
 			</table>
			</div>
			
	<nobr>
			<ul id="menu" >
	<li><a href="index.php">Acceuil</a>
		
	</li>
	<li><a href="nos_biens.php">Nos biens</a>
		
	</li>
	<li><a href="recherche1.php">Recherche</a>
		
	</li>
	<li><a href="proposer1.php">Proposer</a>
		
	</li>
	<li><a href="inscription3.php">Inscription</a>
		
	</li>	
		<li><a href="mondat.php">Mondat</a>
		
	</li>	
		
		</li>
	<li><a href="apropos.php">A propos</a>
		
	</li>
		
		
		
		<li><a href="contact.php">Contactez-nous</a>
		
	</li>
	
	</ul>
	</nobr></div>
  <div id="corps">
		
		<div id="droite">
	  <br />
		  <br />
		   <br />
		 <center>
		 </center>
		  <form method="POST"  name="bien" action="recherche1.php">
		  </form>
		  <br />
			<?php

if(!isset($_SESSION['pseudo']))
{ ?> 
	<center>      <span class="Style2 Style5"><strong>Connexion</strong></span>
	</center>
		  
		  <br />
		  
		  <form method="POST" name="connexion" action="connection.php">
		<center><fieldset style="border:#FFFFFF 1px black;padding:20px;width:60px;color:#FFFFFF;" >
		<label for="login" ><strong>Login</strong></label>
		<input type="text" name="l_cl" id="l_cl" placeholder="Nom utilisateur" /><br/>
		<label for="mot de passe"><strong>Mot de passe</strong></label>
		<input type="password" name="mdp" id="mdp" placeholder="Mot de passe" />
		<center><input type="submit" name="submit"   value="Connexion" /></center>
		</fieldset></center>
	  </form> 
	  
	  <?php
	  }else{ ?>
	  <a href="deconecter.php"><img src="images/d�connexion.JPG"  /></a>
	 <br/>
	  <br/>
	  <a href="member.php"><img src="images/conte.jpg"  /></a> 
	  <?php }
	  ?>
	  <br />
	  <center>	<P><img src="images/cnep.jpg" width="180" height="116" /></P></center>
	  
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
	
		</div>
		<div id="gauche">
		
 <br />
		 	<p>&nbsp;</P>
		
		<center><p><div id="updates" class="boxed">
			<div class="title">
			<div id="sidebar">
			<div id="div2" class="boxed">
			<div class="title">
				<center>
				  <span class="Style2 Style5"><strong> Calendrier				  </strong></span>
				 
				</center>
				 <br />
			</div>
			<div class="content">
			<div id="div3"></div>
			</div>
			</div>
			</div>
			</div>
			<div class="content">
		<div id="cal1Container" ></div>
	
			</div>
		</div></P></center>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
		<p>&nbsp;</P>
	<center>	<P><img src="images/fnai.jpg" width="180" height="116" /></P></center>
		
	  
	  
		
          	
	
	  

		</div>
		<div id="milieu">
		  <center>
	       
		   <p align="center" class="Style2 Style1 Style3"><strong>chercher un bien:</strong></p>
		  <center>
						<form method="POST"  name="bien" action="recherche1.php">
						<center>
						  <table width="448" height="215" border="0" align="center">
                            <tr>
                              <td width="120" height="24"><input type="hidden" name="id_bien" />
                                  <label for="bien"><span class="Style40">Bien: </span></label>                              </td>
                              <td width="318"><select id="t" name="t" >
                                  <option value="vide"></option>
                                  <option value="appartement">&nbsp;&nbsp;Appartement&nbsp;&nbsp;</option>
                                  <option value="villa">&nbsp;&nbsp;Villa&nbsp;&nbsp;</option>
                                  <option value="terrain">&nbsp;&nbsp;Terrain&nbsp;&nbsp;</option>
                                  <option value="entrepot">&nbsp;&nbsp;Entrepot&nbsp;&nbsp;</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td height="46"><label for="cat&eacute;gorie" class="Style40">Type transaction: </label>                              </td>
                              <td><select name="type" id="type" placeholder="Type de bien">
                                <option value="vide"></option>
                                <option value="achat">&nbsp;&nbsp;&nbsp;&nbsp;Achat&nbsp;&nbsp&nbsp;</option>
                                <option value="location">&nbsp;&nbsp;&nbsp;&nbsp;Location&nbsp;&nbsp;&nbsp;</option>
                                <option value="echange">&nbsp;&nbsp;&nbsp;&nbsp;Echange&nbsp;&nbsp;&nbsp;</option>
								 <option value="vente">&nbsp;&nbsp;&nbsp;&nbsp;Vente&nbsp;&nbsp;&nbsp;</option>
                              </select>                             </td>
                            </tr>
                            <tr>
                              <td height="37"><label for="lieu" class="Style40">Lieu: </label></td>
                              <td><input type="text" name="lieu" id="lieu" /></td>
                            </tr>
                            <tr>
                              <td height="40"><label for="prix" class="Style40">Prix (DA): </label>                              </td>
                              <td><input type="text" name="prix_min" id="pri_min" placeholder="prix min"/> <input type="text" name="prix_max" id="pri_max" placeholder="prix max"/>                              </td>
                            </tr>
                            <tr>
                              <td height="56"></td>
                              <td><input name="submit" type="submit" value="Lancer la recherche"/>                              </td>
                            </tr>
                        </table>
						</center>
            </form>
	 
	  
	  
	 
	 
	    <table width="726" border="0">
		
		<?php if(!empty($oRow)){ ?>
		 <span class="Style1">Les r�sultats de la recherche		  </span>
  <?php  while($rows = mysqli_fetch_array($oRow)){?>
  
  <center>
		 
		</center>
  <tr>
    <td width="250" height="204"><img src="./images/<?php echo $rows['image1'] ;?>"  name="image" width="250px" height="200px"/></td>
    <td width="460"> 
	<strong>Type de bien:</strong>	<?php echo $rows['type_bien'] ;?><strong>.</strong>	<br>
	<strong>Prix:</strong>	<?php echo $rows['prix'] ;?> <strong>DA.</strong>	<br>
	<strong>Superficie:</strong>	<?php echo $rows['superficie']  ;?> <strong>m�.</strong>	<br />
	<br /><br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="voir.php?id=<?php echo $rows['id_bien'] ;?>"> + <em><strong>DE DETAILS</strong> </em></a>	</td>
  </tr>
  <?php }}
  else {
  echo "Aucun R�sultat trouv�";
  }?>
</table>
<br /><br /><br />
<br /><br /><br />
	      </center>
      </div>
    </center> 
	     
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp; </p>
  </div>
	
</div>

 

