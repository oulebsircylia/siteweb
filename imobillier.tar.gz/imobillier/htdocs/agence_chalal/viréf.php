 <?php
 $vars= array("nom","mail","objet","message");
 foreach($vars as $var)
 if(isset($_POST[$var])) $$var=$_POST[$var];
 else $$var='';
 if(strlen($nom)<3) die ("un nom doit avoirplus de 3 caract�re !");
 if(!eregi('^([a-z0-9\._-])+@([^\.]+\.]+)',$mail, $matched))die ("adresse invalide !!");
 else if(!getmxrr($matched[2], $mxrr)) die("serveur de mail invalide");
 $expediteur= "ouazarmila@gmail.com";
 $expediteurIF= $_SERVER['REMOTE_ADDR'];
 $corpsDUMail= "demafe d'information:
 Nom: $nom
 eMail : $mail
 Objet: $objet
 Message:
 $message";
 mail ($expediteur, "Nouveau message...", $corpsDUMmail, "de: $mail");
 echo "mail envoyer...";
 ?>	   