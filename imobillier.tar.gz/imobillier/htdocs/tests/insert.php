<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
<?php
		try
		{
			$bdd = new PDO ('mysql:host=localhost; dbname=tests', 'root', 'mimia');
		}
		catch (Exception $e)
		{
			die('Erreur: '.$e->getMessage());
		}
		$bdd->exec('INSERT INTO jeux_videos (nom, processeur, console, prix, nbre_joueurs_max, commentaires) VALUES (\'Battlefield 1942\', \'patrick\', \'PC\', 45, 50, \'2nde guerre mondiale\')');
		echo 'Le jeu a bien �t� ajout� !';
	?>
</body>
</html>
