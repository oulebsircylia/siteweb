http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
	<head>
		<title>Page progeter par un met de passe</title>
		<meta http-equiv="Content-Tupe" content="text/html;charset=iso-8859-1" />
	</head>
	<body>
		<p>Veuillez enter le mot de passe pour obtenir les codes d'acc�s 
		au serveur central de la NASA :</p>
		<form action="secret.php" method="post">
		<p>
		<input type="password" name="mot_de_passe" />
		<input type="submit" value="valider" />
		</p>
		</form>
		<p>Cette page est r�serv�e au personnel de la NASA. Si 
		 vous ne travaillez pas � la NASA, inutile d'insister vous 
		 ne trouverez jamais le mot de passe !;-)</p>
	</body>
</html>
