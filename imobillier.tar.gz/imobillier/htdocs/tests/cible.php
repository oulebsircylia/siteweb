http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
	<head>
		<title>Codes d'acc�s au serveur central de la NASA</title>
		<meta http-equiv="Content-Tupe" content="text/html;charset=iso-8859-1" />
	</head>
	<body>
	<?php
		if (isset($_POST['mot_de_passe']) AND $_POST['mot_de_passe'] ==
		"kangourou")
		{
		?>
		<h1>Voici les codes d'acc�s :</h1>
		<p><strong>CRD5-GTFT-CK65-JOPM-V29N-24G1-HH28-LLFV
		</strong></p>
		<p>
		  Cette page es r�serv�e au personnel de la NASA. N'oubliez 
		pas de r�guli�rement car les codes d'acc�s sont chang�s toutes
		les semaines.<br/>
		   La NASA vous remercie de votre visite.</p>
		<?php
		}
		else
		{
			echo '<p>mot de passe incorrect</p>';
		}
		?>
	</body>
</html>
		