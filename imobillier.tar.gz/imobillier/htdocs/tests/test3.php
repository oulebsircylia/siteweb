<! DOCTYPEhtml PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
	<head>
		<title>Mon super site</title>
		<meta http-equiv="Content-Tupe" content="text/html;charset=iso-8859-1" />
	</head>
	<body>
		
		<!-- Le menu -->
		<div id="menu">
			<div class="element menu">
				<h3>Titre menu</h3>
				<ul>
					<li><a href="page1.html">Lien</a></li>
					<li><a href="page2.html">Lien</a></li>
					<li><a href="page3.html">Lien</a></li>
				</ul>
			</div>
		</div>
		
	</body>
</html>