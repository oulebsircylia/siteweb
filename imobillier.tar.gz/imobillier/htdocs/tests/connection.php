<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=tests', 'root', 'mimia');
}
catch (Exception $e)
{
	die('Erreur : ' .$e->getmessage());
}	
$reponse = $bdd->query('SELECT * FROM jeux_videos');
while ($donnees = $reponse->fetch())
{
?>
	<p>
	<strong>Jeu</strong> :
	 <?php echo $donnees['nom']; ?><br/>
	Le processeur de ce jeu: 
	<?php echo $donnees['processeur']; ?>
	et il vend � 
	<?php echo $donnees['prix']; ?> euros !<br/>
	Ce jeu fonctionne sur
	<?php echo $donnees['console']; ?> 
	et on peut y jouer �
	<?php echo $donnees['nbr_joueurs_max']; ?> au maximum<br/>
	<?php echo $donnees['processeur']; ?> a laiss� ces commentaires
	sur <?php echo $donnees['nom']; ?>: <em>
	<?php echo $donnees['commentaire']; ?></em>
	</p>
	<?php
	}
	$reponse->closeCursor();
	?>
	