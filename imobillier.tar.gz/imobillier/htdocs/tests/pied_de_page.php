"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
	<head>
		<title>Mon super site</title>
		<meta http-equiv="Content-Tupe" content="text/html;charset=iso-8859-1" />
	</head>
	<body>

		<!-- L epied de la page -->
		<div id="pied_de_page">
			<p>Copyright moi, tous droits r�serv�s</p>
		</div>
	</body>
</html>