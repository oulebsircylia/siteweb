<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Ceci est une page de test avec des balises PHP</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
  <h2> Page de test </h2>
  <p> Cette page contient du code HTML avec des balises PHP.<br/>
  <?php  echo "Ceci est du <strong>texte</strong> ";  ?> <br />
  <?php  echo "Cette ligne a �t� �crite \"uniquement\"en PHP.";  ?> <br />
  Voici quelque petits tests :
  </p>
  <ul>
  <li style="color: blue;">Texte en bleu</li>
  <li style="color: red;">Texte en rouge</li>
  <li style="color: green;">Texte en vert</li>
  </ul>
  
  
</body>
</html>
