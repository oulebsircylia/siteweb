<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
body {
	background-color: #FFCCFF;
}
.Style7 {color: #0000FF; font-weight: bold; }
.Style8 {color: #0000CC; font-weight: bold; }
.Style9 {color: #0000CC}
-->
</style>
</head>

<body>
<table width="1022" height="31" border="0">
  <tr>
    <td width="1016"><div align="center">
      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="219" height="34" align="left">
        <param name="movie" value="text4.swf" />
        <param name="quality" value="high" />
        <embed src="text4.swf" width="219" height="34" align="left" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" ></embed>
      </object>
    </div></td>
  </tr>
</table>
<table width="978" height="28" border="1">
  <tr>
    <td width="161"><div align="center"><span class="Style8"><a href="index.php">Accueil</a></span></div></td>
    <td width="171"><div align="center"><span class="Style8"><a href="pages.php">Activit&eacute;s</a></span></div></td>
    <td width="140"><div align="center"><span class="Style8"><a href="lettre.php">Lettres</a></span></div></td>
    <td width="152"><div align="center"><span class="Style8"><a href="appels.php">Appels</a></span></div></td>
    <td width="185"><div align="center" class="Style8">Photos</div></td>
    <td width="173"><div align="center" class="Style7">Vid&eacute;os</div></td>
  </tr>
</table>
<table width="968" height="282" border="0">
  <tr>
    <td width="493" rowspan="6"><p>&nbsp; </p>
    <p><img src="images/e165e2edc54361613e6d219bd9b7f309.jpg" alt="" width="462" height="147" /></p></td>
    <td width="337" rowspan="6"><p>&Agrave; chaque &eacute;tape, on dispose d&rsquo;un langage interm&eacute;diaire (on parle aussi de repr&eacute;sentation<br />
      interm&eacute;diaire) qui ne diff&egrave;re du pr&eacute;c&eacute;dent qu&rsquo;en un petit nombre de points.<br />
    Chaque langage interm&eacute;diaire dispose de sa propre syntaxe abstraite et (en principe) </p>
    <p> <a href="#">wezna</a> <a href="#">wezna </a></p></td>
    <td width="186" rowspan="6" valign="top"><table width="183" height="218" border="1">
      <tr>
        <td width="173"><span class="Style8"><a href="w">Photos</a></span></td>
      </tr>
      <tr>
        <td><span class="Style8">Videos</span></td>
      </tr>
      <tr>
        <td><span class="Style9"><strong>M&eacute;teo</strong></span></td>
      </tr>
      <tr>
        <td height="32"><span class="Style9"><strong><a href="facebook.xht">Facebook</a></strong></span></td>
      </tr>
      <tr>
        <td><span class="Style9"><strong>Info r&eacute;gionnale </strong></span></td>
      </tr>
      <tr>
        <td><span class="Style9"><strong><a href="facebook.xht">Gmail</a></strong></span></td>
      </tr>
    </table></td>
  </tr>
  <tr></tr>
  <tr></tr>
  <tr></tr>
  <tr></tr>
  <tr></tr>
  <tr>
    <td height="40" colspan="4"> <p>
      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="973" height="297" title="anni">
        <param name="movie" value="anni.swf" />
        <param name="quality" value="high" />
        <embed src="anni.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="973" height="297"></embed>
      </object>
    </p>
    <p>&nbsp;</p></td>
  </tr>
</table>
<table width="1029" height="61" border="0">
  <tr>
    <td width="507">Cela se fait en plusieurs &eacute;tapes :<br />
      1. Analyse syntaxique : permet de v&eacute;rifier que l&rsquo;expression est bien une phras<br />
      langage source syntaxiquement correcte, on dit aussi qu&rsquo;elle est bien form&eacute;e. <br />
      n&eacute;cessite donc une d&eacute;finition formelle du langage source. Exemple en fran&ccedil;ais : <br />
    Le lion mange de la viande &raquo; est syntaxiquement correcte et &laquo; le lion viande &raquo;</td>
    <td width="512">dire l&rsquo;ensemble des expressions valides dans ce langage. Il faut &eacute;galement d&eacute;cri<br />
      s&eacute;mantique, c&rsquo;est-&agrave;-dire comment ces expressions seront interpr&eacute;t&eacute;es. Dans le c<br />
    langage machine, la s&eacute;mantique est clairement d&eacute;finie par le compo</td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
