<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
<?
//fichier add_user.php
//on integre les information de connexion a la bdd ainsi que le fichier ou le librairie fonction.php
include ("conf.php");
include("fonction.php");
//on initialise la connexion a la bdd 
$bdd = new PDO('mysql:host=localhost; dbname=monsite', 'root', 'mimia');
//on r�cupere ce que l'utilisateur � saisi ,si il na rien saisi (login ou mot de passe ) ou le renvoi sur la page de creation de compte 
if ( isset ($_REQUEST ['login']) && isset($_REQUEST ['password']) )
	{
	//le formulaire pr�c�dent a ete bien renpli 
	//on prepare la requete SQL pour enregistrer l'utilisateur 
		$requete = "INSERT INTO 'mon_sit'.'user' ('id','login','password')VALUES (NULL,'".$_REQUEST['login']." ' , ' " . md5 ($_REQUEST ['password'])." ');";
			//ici md5 permet de crypte le mot de passe et le stoker crypt� dans la bdd.
			//on execute la requete grace a la fonction SQL presente  dans le fichier fonction.php
		sql($requete );
		//on pr�vient que le compte � bien �t� cr�e 
		echo "compte ajout� a la base";
		//on pourrait aussi renvoyer vers une page de confirmation  par header("location :conformation.html");
	}	
	else 
		{
			//le formulaire n'est pas complet 
			//on revoi vers la page pr�c�dente 
			header ("localion : add_user.html");
		}
?>
</body>
</html>
