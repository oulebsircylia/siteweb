<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>


<?php 
$hot = "localhost";
$utilisateur="root";
$mot_de_passe="mimia";
$connection= mysql_connect($hot, $utilisateur, $mot_de_passe);
//echo $connection; 
//tapez le nom de la base de donn�e
$nomdelabase="labase";
//tapez la fonction pour selectionner la base
mysql_select_db($nomdelabase, $connection);
//nous allons en fin effectuer une requete sql
$requete="select * from la_table";
//il va falloir l'envoyer au serveur sql, via la fonction
mysql_query($requete, $connection);  
$resultat=mysql_query($requete, $connection);
//echo $resultat;
//il affiche rien car il accede pas directement au resultat du serveur mysql
//on peut retourner le resultat de la requete mysql par la fonction suivante
mysql_fetch_row($resultat);
$test=mysql_fetch_row($resultat);
//print_r affiche le resultat une fois stocker dans une variable
print_r($test);
//echo $test[1];
//echo nl2($test[1]);


?>
</body>
</html>

