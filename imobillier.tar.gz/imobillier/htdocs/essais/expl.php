<html>
<head>
<title> Bonjour tout le monde </title>
</head>
<body>

<?  echo'Bienvenu dans mon premier programme PHP'; ?>


</body>
</html>