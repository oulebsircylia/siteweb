
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link href="images/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<style type="text/css">
.bouton1 {width:150px!important;
	border-radius:3px;
	border:#8c8c8c 1px solid;
	box-shadow:inset 0 5px 3px rgba(0, 0, 0, 0.1);
	padding:3px 8px;
	background-color:#9C0;
	height:30px;
}


.selection {
	width: 180px!important;
	border-radius: 3px;
	border: #8c8c8c 1px solid;
	box-shadow: inset 0 5px 3px rgba(0, 0, 0, 0.1);
	padding-top: 3px;
	padding-right: 8px;
	padding-bottom: 3px;
	padding-left: 8px;
}
.unite {width:170px!important;
	border-radius:3px;
	border:#8c8c8c 1px solid;
	box-shadow:inset 0 5px 3px rgba(0, 0, 0, 0.1);
	padding:3px 8px;
}

.bgtab {	background-image:url(images/bgtab.png);
}
.chiffre1 {	width:65px!important;
	border-radius:3px;
	border:#8c8c8c 1px solid;
	box-shadow:inset 0 5px 3px rgba(0, 0, 0, 0.1);
	padding:5px 8px;
}

.mini {	width:30px!important;
	border-radius:3px;
	border:#8c8c8c 1px solid;
	box-shadow:inset 0 5px 3px rgba(0, 0, 0, 0.1);
	padding:5px 8px;
}
.echogras {	
	color: #333;
	font-size: 22px;
	font-weight: bold;
	font-style: italic;
	text-align: center;
}
#divdefil2 {
	position: absolute;
	left: 0px;
	top: 179px;
	width: 100%;
	height: 22px;
	z-index: 0;
}
</style>
<head>
<link href="images/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" type="text/css" href="JavaS/styles_002.css" media="all">
<link rel="stylesheet" type="text/css" href="JavaS/styles-home.css" media="all">

<script type="text/javascript" src="JavaS/jquery_002.js"></script>
<script type="text/javascript" src="JavaS/jquery-cookie.js"></script>
<script type="text/javascript" src="JavaS/jquery_005.js"></script>
<script type="text/javascript" src="JavaS/jquery_007.js"></script>   
<script type="text/javascript" src="JavaS/jcarousellite_1.js"></script>
<script type="text/javascript" src="JavaS/common.js"></script>
<script type="text/javascript" src="JavaS/jquery_006.js"></script>
<script type="text/javascript" src="JavaS/scripts-home.js"></script>
<script type="text/javascript" src="JavaS/ajout_bien.js"></script>
<script type="text/javascript" src="JavaS/upload_communes-1.js"></script>
<script type="text/javascript" src="JavaS/upload_communes-2.js"></script>
<script type="text/javascript" src="JavaS/ajouter_annonce.js"></script>


<title>Aissat immobilière</title>
<style type="text/css">
body {
	background-image: url();
	background-repeat: no-repeat;
	background-attachment: fixed;
}
#divcarree {
	position: absolute;
	left: 0px;
	top: 180px;
	width: 100%;
	height: 700px;
	z-index: 1;
}


#site #lineTop .mid .content .posL li {
	color: #000000;
}
</style>
<style type="text/css">
#apDiv2 {
	position: absolute;
	left: 162px;
	top: 1061px;
	width: 98px;
	height: 62px;
	z-index: 9;
}
.echorouge {	color: #F00;
}
body,td,th {
	font-family: DINWeb, sans-serif;
}
</style>
</head>

<body onload="fill_commune(document.searchform.location_from.selectedIndex);" >
<div id="divcarree">
  <table width="900" border="0" align="center">
  
      
    <tr>
      <td colspan="2">
    <nav id="navUNIVERS">
      <div class="mid">
            <div class="content">  
                       
             <ul>            
               <li style="background-color: rgba(0, 0, 0, 0.5); background-image:url(images/depotr.png)" class="universACHETER moduleHover first" >
         			 <h2><a class="white bold" href="ajout_annonce.php" >Déposer un  <br />
		        bien</a></h2> </li>
                
               <li style="background-color: rgb(0, 0, 0); background-image:url(images/recherche.png)" class="universLOUER moduleHover ">
                  <h2><a class="white bold" href="">Recherche Rapide</a></h2></li>
               
               <li style="background-color: rgba(0, 0, 0, 0.5); background-image:url(images/vendre.png)" class="universVENDRE moduleHover">
                  <h2><a class="white bold" href="liste_promo.php">Ventes sur plan</a></h2></li>           
               
              <li style="background-color: rgba(0, 0, 0, 0.5); background-image:url(images/echange.png)" class="universGESTION moduleHover ">
        		  <h2><a class="white bold" href="annonces_vente.php">Ventes</a></h2></li>
                
              <li style="background-color: rgba(0, 0, 0, 0.5); background-image:url(images/louer.png)" class="universREJOINDRE moduleHover">
                  <h2><a class="white bold" href="annonces_location.php">Locations</a></h2></li>
                 
              <li style="background-color: rgba(0, 0, 0, 0.5);" class="universACTU multipleEvent relative last">			
            	<div style="visibility: visible; overflow: hidden; position: relative; z-index: 2; left: 0px; 					width: 125px;" class="zoneCarouselEventHome">
                
  					<ul style="margin: 0px; padding: 0px; position: relative; list-style-type: none; z-index: 1; width: 500px; left: -250px;">
  						<li class="multipleEvent" style="background-image: url(images/mais.jpg); overflow: hidden; float: left; width: 125px; height: 125px; background-color: rgba(0, 0, 0, 0.5);"></li>          
          
        			  <li class="multipleEvent relative" style="background-image:url(images/soja.jpg);  overflow: hidden; float: left; width: 125px; height: 125px; background-color: rgba(0, 0, 0, 0.5);"></li>
                     
             	 </ul>
            </div> 
            </li>
          </ul>
         </div>           
      </div>
     </nav> 
      
      </td>
    </tr>
  
  
  
  
    
    <tr>
      <td width="570" align="left" >
      
      
      
      <div  id="sliderHOME">
      
      
   <section style="display: block; opacity: 1;" id="contentACHETER" class="slide">
        <div class="bloc1 bloc">   
        
        
        
<form name="searchform2" method="POST" action="depot_annonce.php" id="searchform2">
      <table width="500" height="180" border="0" bgcolor="">
  <tr>
    <td height="41" colspan="6" align="left"><label>Nom<span class="echorouge">*</span>
      <input name="nom" type="text" required="required" class="chapms"  id="nom" />
      Prénom<span class="echorouge">*</span></label>
      <label>
        <input name="prenom" type="text" class="chapms" id="prenom" required="required" />
        Tél</label>
      <span class="echorouge">*</span> <span id="sprytextfield2">
      <label>
        <input name="tel" type="text" required="required" class="chapms" id="tel" />
      </label>
    <span class="textfieldRequiredMsg"></span><span class="textfieldInvalidFormatMsg"></span><span class="textfieldMinCharsMsg"></span></span></td>
  </tr>
  <tr>
    <td width="65" height="41" align="right">Transaction</td>
    <td colspan="3"><select name="transaction" class="selection" id="transaction">
      <option value="vente">Recherche d'achat</option>
      <option value="location">Recherche de location</option>
    </select></td>
    <td width="142" align="right">Type de bien </td>
    <td width="210"><select name="souscategorie1" class="selection" id="souscategorie1" onchange="modifier_formulaire()">
      <option selected="selected" value="appartement">Appartement</option>
      <option value="studio">Studio</option>
      <option value="villa">Villa</option>
      <option value="niveau-de-villa">Niveau De Villa</option>
      <option value="local">Local</option
                    >
      <option value="usine">Usine</option>
      <option value="terrain">Terrain</option>
      <option value="carcasse">Carcasse</option>
      <option value="bungalow">Bungalow</option>
      <option value="duplex">Duplex</option>
      <option value="hangar">Hangar</option>
      <option value="immeuble">Immeuble</option>
      <option value="autre">Autre</option>
    </select></td>
  </tr>
  <tr>
    <td width="65" height="40" align="right">Wilaya<span class="echorouge">*</span></td>
    <td colspan="3"><select name="wilaya" class="selection" id="wilaya" onchange="fil_commune(document.searchform2.wilaya.selectedIndex);" required="required">
      <option selected="selected" value="">--- Selectionner ---</option>
      <option value="Adrar">01 - Adrar</option>
      <option value="Chlef">02 - Chlef</option>
      <option value="Laghouat">03 - Laghouat</option>
      <option value="Oum-El-Bouaghi">04 - Oum-El-Bouaghi</option>
      <option value="Batna">05 - Batna</option>
      <option value="Bejaia">06 - Bejaia</option>
      <option value="Biskra">07 - Biskra</option>
      <option value="Bechar">08 - Bechar</option>
      <option value="Blida">09 - Blida</option>
      <option value="Bouira">10 - Bouira</option>
      <option value="Tamanrasset">11 - Tamanrasset</option>
      <option value="Tebessa">12 - Tebessa</option>
      <option value="Tlemcen">13 - Tlemcen</option>
      <option value="Tiaret">14 - Tiaret</option>
      <option value="Tizi-Ouzou">15 - Tizi-Ouzou</option>
      <option value="Alger">16 - Alger</option>
      <option value="Djelfa">17 - Djelfa</option>
      <option value="Jijel">18 - Jijel</option>
      <option value="Setif">19 - Setif</option>
      <option value="Saida">20 - Saida</option>
      <option value="Skikda">21 - Skikda</option>
      <option value="Sidi-Bel-Abbes">22 - Sidi-Bel-Abbes</option>
      <option value="Annaba">23 - Annaba</option>
      <option value="Guelma">24 - Guelma</option>
      <option value="Constantine">25 - Constantine</option>
      <option value="Medea">26 - Medea</option>
      <option value="Mostaganem">27 - Mostaganem</option>
      <option value="MSila">28 - MSila</option>
      <option value="Mascara">29 - Mascara</option>
      <option value="Ouargla">30 - Ouargla</option>
      <option value="Oran">31 - Oran</option>
      <option value="El-Bayadh">32 - El-Bayadh</option>
      <option value="Illizi">33 - Illizi</option>
      <option value="Bordj-Bou-Arreridj">34 - Bordj-Bou-Arreridj</option>
      <option value="Boumerdes">35 - Boumerdes</option>
      <option value="El-Taref">36 - El-Taref</option>
      <option value="Tindouf">37 - Tindouf</option>
      <option value="Tissemsilt">38 - Tissemsilt</option>
      <option value="El-Oued">39 - El-Oued</option>
      <option value="Khenchela">40 - Khenchela</option>
      <option value="Souk-Ahras">41 - Souk-Ahras</option>
      <option value="Tipaza">42 - Tipaza</option>
      <option value="Mila">43 - Mila</option>
      <option value="Ain-Defla">44 - Ain-Defla</option>
      <option value="Naama">45 - Naama</option>
      <option value="Ain-Temouchent">46 - Ain-Temouchent</option>
      <option value="Ghardaia">47 - Ghardaia</option>
      <option value="Relizane">48 - Relizane</option>
    </select></td>
    <td align="right">Commune<span class="echorouge">*</span></td>
    <td><select name="commune" class="selection" id="commune" required="required">
      <option selected="selected" value="">--- Selectionner ---</option>
    </select></td>
  </tr>
  <tr>
    <td height="38" rowspan="2" align="right" valign="top">Prix entre</td>
    <td width="175" valign="top"> <input onkeyup="ConvNumberLetter_fr(true)" class="inputs" name="prix" id="prix" value=""  type="text" />
      </span>
        <label><br />
      </label>
    
      <br /></td>
    <td colspan="4" valign="top"><select name="prix_unite" class="unite" id="prix_unite" onchange="ConvNumberLetter_fr(true)">
      <option value="2">Millions Centimes</option>
      <option value="1" selected="selected">DA</option>
      <option value="3">Milliards</option>
      <option value="4">DA / M²</option>
      <option value="5">Millions Centimes / M²</option>
      </select>
      <input type="hidden" name="date" id="date" />
      <input name="user" type="hidden" id="user" value="-1" />
      <input name="id_bien" type="hidden" id="id_bien" value="-1" />
      <input name="etat_ann" type="hidden" id="etat_ann" value="en attente" /></td>
    </tr>
  <tr>
    <td colspan="2">  <div style="color: rgb(119, 119, 119);" id="prix_lettres"></div></td>
    <td colspan="2" valign="middle">&nbsp;</td>
    <td valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td width="65">&nbsp;</td>
    <td colspan="3" align="right">&nbsp;</td>
    <td colspan="2"><input name="button" type="submit" class="bouton1" id="button" value="Continuer" /></td>
    </tr>
</table>
</form>
        
        
        
        
        
        </div>
        
        
       
   </section>
     
      
   <section class="slide" id="contentLOUER" style="display: block; opacity: 1;" name="contentLOUER">
        <div class="bloc1 bloc"> 
        
        <form name="searchform" method="post" action="resultat_rech.php" id="searchform">
        
                <table width="550" height="180" border="0">
                  <tr>
                    <td width="65" height="41" align="right">Transaction</td>
                    <td colspan="2"><select name="transaction" class="selection" id="transaction">
                      <option value="Vente" selected="selected">Vente</option>
                      <option value="Location">Location</option>
                      <option value="Echange">Echange</option>
                      </select></td>
                    <td width="75" align="right">Type de bien </td>
                    <td width="180"><select name="souscategorie1" class="selection" id="souscategorie1" onchange="modifier_formulaire()">
                      <option selected="selected" value="appartement">Appartement</option>
                      <option value="studio">Studio</option>
                      <option value="villa">Villa</option>
                      <option value="niveau-de-villa">Niveau De Villa</option>
                      <option value="local">Local</option
                    >
                      <option value="usine">Usine</option>
                      <option value="terrain">Terrain</option>
                      <option value="carcasse">Carcasse</option>
                      <option value="bungalow">Bungalow</option>
                      <option value="duplex">Duplex</option>
                      <option value="hangar">Hangar</option>
                      <option value="immeuble">Immeuble</option>
                      <option value="autre">Autre</option>
                      </select></td>
                  </tr>
                  <tr>
                    <td width="65" height="40" align="right">Wilaya</td>
                    <td colspan="2"><select name="wilaya" class="selection" id="wilaya" onchange="fill_commune(document.searchform.wilaya.selectedIndex);">
                      <option selected="selected" value="">--- Selectionner ---</option>
                      <option value="Adrar">01 - Adrar</option>
                      <option value="Chlef">02 - Chlef</option>
                      <option value="Laghouat">03 - Laghouat</option>
                      <option value="Oum-El-Bouaghi">04 - Oum-El-Bouaghi</option>
                      <option value="Batna">05 - Batna</option>
                      <option value="Bejaia">06 - Bejaia</option>
                      <option value="Biskra">07 - Biskra</option>
                      <option value="Bechar">08 - Bechar</option>
                      <option value="Blida">09 - Blida</option>
                      <option value="Bouira">10 - Bouira</option>
                      <option value="Tamanrasset">11 - Tamanrasset</option>
                      <option value="Tebessa">12 - Tebessa</option>
                      <option value="Tlemcen">13 - Tlemcen</option>
                      <option value="Tiaret">14 - Tiaret</option>
                      <option value="Tizi-Ouzou">15 - Tizi-Ouzou</option>
                      <option value="Alger">16 - Alger</option>
                      <option value="Djelfa">17 - Djelfa</option>
                      <option value="Jijel">18 - Jijel</option>
                      <option value="Setif">19 - Setif</option>
                      <option value="Saida">20 - Saida</option>
                      <option value="Skikda">21 - Skikda</option>
                      <option value="Sidi-Bel-Abbes">22 - Sidi-Bel-Abbes</option>
                      <option value="Annaba">23 - Annaba</option>
                      <option value="Guelma">24 - Guelma</option>
                      <option value="Constantine">25 - Constantine</option>
                      <option value="Medea">26 - Medea</option>
                      <option value="Mostaganem">27 - Mostaganem</option>
                      <option value="MSila">28 - MSila</option>
                      <option value="Mascara">29 - Mascara</option>
                      <option value="Ouargla">30 - Ouargla</option>
                      <option value="Oran">31 - Oran</option>
                      <option value="El-Bayadh">32 - El-Bayadh</option>
                      <option value="Illizi">33 - Illizi</option>
                      <option value="Bordj-Bou-Arreridj">34 - Bordj-Bou-Arreridj</option>
                      <option value="Boumerdes">35 - Boumerdes</option>
                      <option value="El-Taref">36 - El-Taref</option>
                      <option value="Tindouf">37 - Tindouf</option>
                      <option value="Tissemsilt">38 - Tissemsilt</option>
                      <option value="El-Oued">39 - El-Oued</option>
                      <option value="Khenchela">40 - Khenchela</option>
                      <option value="Souk-Ahras">41 - Souk-Ahras</option>
                      <option value="Tipaza">42 - Tipaza</option>
                      <option value="Mila">43 - Mila</option>
                      <option value="Ain-Defla">44 - Ain-Defla</option>
                      <option value="Naama">45 - Naama</option>
                      <option value="Ain-Temouchent">46 - Ain-Temouchent</option>
                      <option value="Ghardaia">47 - Ghardaia</option>
                      <option value="Relizane">48 - Relizane</option>
                      </select></td>
                    <td align="right">Commune</td>
                    <td><select name="commune" class="selection" id="">
                      <option selected="selected" value="">--- Selectionner ---</option>
                      </select></td>
                  </tr>
                  <tr>
                    <td height="38" align="right">Prix entre</td>
                    <td width="109" valign="middle"><input onkeyup="ConvNumberLetter_fr(true)" class="chiffre1" name="prix_min" id="prix_min" value=""  type="text" />
                      et</td>
                    <td width="69" valign="middle"><input onkeyup="ConvNumberLetter_fr(true)" class="chiffre1" name="prix_max" id="prix_max" value=""  type="text" /></td>
                    <td colspan="2" valign="middle"><select name="prix_unite" class="unite" id="prix_unite" onchange="ConvNumberLetter_fr(true)">
                        <option value="2">Millions Centimes</option>
                        <option value="1" selected="selected">DA</option>
                        <option value="3">Milliards</option>
                        <option value="4">DA / M²</option>
                        <option value="5">Millions Centimes / M²</option>
                      </select>
                      <br /></td>
                  </tr>
                  <tr>
                    <td width="65">&nbsp;</td>
                    <td colspan="2" align="right"><input name="button2" type="submit" class="bouton1" id="button2" value="Rechercher" /></td>
                    <td colspan="2"><input class="chiffre1" name="pieces_min" id="pieces_min" type="hidden"/>
                      <input class="chiffre1" name="pieces_max" id="pieces_max" type="hidden"/>
                      <input class="chiffre1" name="etages_max" id="etages_max" type="hidden"/>
                      <input class="chiffre1" name="super_max" id="super_max" type="hidden" />
                      <input class="chiffre1" name="super_min" id="super_min" type="hidden" />
                      <input class="chiffre1" name="etages_min" id="etages_min" type="hidden"/>
                    <a href="rech_avancee.php">Recherche avancée</a></td>
                  </tr>
                </table>
                
        </form>
        
       
        </div>
        
        
        
  </section>



    <section style="display: none; opacity: 1;" id="contentVENDRE" class="slide">
        <div class="bloc1 bloc">  
        
        <form id="form1" name="form1" method="post" action="resultat_promo.php">
  <table width="500" border="0" align="left">
    <tr>
      <td width="141" height="38" align="right" >Type de bien&nbsp;</td>
      <td height="38" colspan="3"><select name="souscategorie1" id="souscategorie1" onchange="modifier_formulaire()">
					<option value="appartement">Appartement</option><option value="studio">Studio</option><option value="local">Local</option><option value="duplex">Duplex</option>
</select>      </td>
      <td width="72" height="38">Transaction</td>
      <td width="100"><select name="transaction" id="transaction" onchange="modifier_formulaire()">
        <option value="vente">Vente</option>
        <option value="location">Location</option>
      </select></td>
    </tr>
    <tr>
      <td width="141" height="30" align="right" valign="middle">Où&nbsp;&nbsp;</td>
      <td height="30" colspan="5"><select name="wilaya" id="wilaya"  class=""><option selected="selected" value="">Choisissez</option>
      <option value="Adrar">01 - Adrar</option><option value="Chlef">02 - Chlef</option><option value="Laghouat">03 - Laghouat</option><option value="Oum-El-Bouaghi">04 - Oum-El-Bouaghi</option><option value="Batna">05 - Batna</option><option  value="Bejaia">06 - Bejaia</option><option value="Biskra">07 - Biskra</option><option value="Bechar">08 - Bechar</option><option value="Blida">09 - Blida</option><option value="Bouira">10 - Bouira</option><option value="Tamanrasset">11 - Tamanrasset</option><option value="Tebessa">12 - Tebessa</option><option value="Tlemcen">13 - Tlemcen</option><option value="Tiaret">14 - Tiaret</option><option value="Tizi-Ouzou">15 - Tizi-Ouzou</option><option value="Alger">16 - Alger</option><option value="Djelfa">17 - Djelfa</option><option value="Jijel">18 - Jijel</option><option value="Setif">19 - Setif</option><option value="Saida">20 - Saida</option><option value="Skikda">21 - Skikda</option><option value="Sidi-Bel-Abbes">22 - Sidi-Bel-Abbes</option><option value="Annaba">23 - Annaba</option><option value="Guelma">24 - Guelma</option><option value="Constantine">25 - Constantine</option><option value="Medea">26 - Medea</option><option value="Mostaganem">27 - Mostaganem</option><option value="MSila">28 - MSila</option><option value="Mascara">29 - Mascara</option><option value="Ouargla">30 - Ouargla</option><option value="Oran">31 - Oran</option><option value="El-Bayadh">32 - El-Bayadh</option><option value="Illizi">33 - Illizi</option><option value="Bordj-Bou-Arreridj">34 - Bordj-Bou-Arreridj</option><option value="Boumerdes">35 - Boumerdes</option><option value="El-Taref">36 - El-Taref</option><option value="Tindouf">37 - Tindouf</option><option value="Tissemsilt">38 - Tissemsilt</option><option value="El-Oued">39 - El-Oued</option><option value="Khenchela">40 - Khenchela</option><option value="Souk-Ahras">41 - Souk-Ahras</option><option value="Tipaza">42 - Tipaza</option><option value="Mila">43 - Mila</option><option value="Ain-Defla">44 - Ain-Defla</option><option value="Naama">45 - Naama</option><option value="Ain-Temouchent">46 - Ain-Temouchent</option><option value="Ghardaia">47 - Ghardaia</option><option value="Relizane">48 - Relizane</option></select>
      </td>
    </tr>
    <tr>
      <td width="141" align="right" valign="middle"> Prix entre&nbsp; </td>
      <td width="105"><input name="prix_min" type="text" id="prix_min" size="15" /></td>
      <td width="57" align="center">et </td>
      <td height="30" colspan="3" valign="middle">
        <input name="prix_max" type="text" id="prix_max" size="15" />
        DA/ M²     </td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td height="46" colspan="5" align="left" valign="middle"><input type="submit" name="button" id="button" value="Recherche" /></td>
    </tr>
  </table>
  <input name="commune" type="hidden" value="" />
</form>
        

        
        
        
        
         </div>
        
       
        
       
        
       
   </section>
      
 
 
       <section style="display: none; opacity: 1;" id="contentGESTION" class="slide">
        <div class="bloc1 bloc">   
        
       <form id="form1" name="form1" method="post" action="recherche_vente.php">
  <table width="438" border="0" align="left">
    <tr>
      <td width="90" height="38" align="right" >Votre recherche&nbsp;</td>
      <td height="30" colspan="3"><select name="souscategorie1" id="souscategorie1" onchange="modifier_formulaire()">
					<option selected="selected" value="appartement">Appartement</option><option value="studio">Studio</option><option value="villa">Villa</option><option value="niveau-de-villa">Niveau De Villa</option><option value="local">Local</option><option value="usine">Usine</option><option value="terrain">Terrain</option><option value="carcasse">Carcasse</option><option value="bungalow">Bungalow</option><option value="duplex">Duplex</option><option value="hangar">Hangar</option><option value="immeuble">Immeuble</option><option value="autre">Autre</option>	
				</select>      </td>
    </tr>
    <tr>
      <td width="90" height="29" align="right" valign="middle">Où&nbsp;&nbsp;</td>
      <td height="30" colspan="3"><select name="wilaya" id="wilaya"  class=""><option selected="selected" value="">Choisissez</option>
      <option value="Adrar">01 - Adrar</option><option value="Chlef">02 - Chlef</option><option value="Laghouat">03 - Laghouat</option><option value="Oum-El-Bouaghi">04 - Oum-El-Bouaghi</option><option value="Batna">05 - Batna</option><option  value="Bejaia">06 - Bejaia</option><option value="Biskra">07 - Biskra</option><option value="Bechar">08 - Bechar</option><option value="Blida">09 - Blida</option><option value="Bouira">10 - Bouira</option><option value="Tamanrasset">11 - Tamanrasset</option><option value="Tebessa">12 - Tebessa</option><option value="Tlemcen">13 - Tlemcen</option><option value="Tiaret">14 - Tiaret</option><option value="Tizi-Ouzou">15 - Tizi-Ouzou</option><option value="Alger">16 - Alger</option><option value="Djelfa">17 - Djelfa</option><option value="Jijel">18 - Jijel</option><option value="Setif">19 - Setif</option><option value="Saida">20 - Saida</option><option value="Skikda">21 - Skikda</option><option value="Sidi-Bel-Abbes">22 - Sidi-Bel-Abbes</option><option value="Annaba">23 - Annaba</option><option value="Guelma">24 - Guelma</option><option value="Constantine">25 - Constantine</option><option value="Medea">26 - Medea</option><option value="Mostaganem">27 - Mostaganem</option><option value="MSila">28 - MSila</option><option value="Mascara">29 - Mascara</option><option value="Ouargla">30 - Ouargla</option><option value="Oran">31 - Oran</option><option value="El-Bayadh">32 - El-Bayadh</option><option value="Illizi">33 - Illizi</option><option value="Bordj-Bou-Arreridj">34 - Bordj-Bou-Arreridj</option><option value="Boumerdes">35 - Boumerdes</option><option value="El-Taref">36 - El-Taref</option><option value="Tindouf">37 - Tindouf</option><option value="Tissemsilt">38 - Tissemsilt</option><option value="El-Oued">39 - El-Oued</option><option value="Khenchela">40 - Khenchela</option><option value="Souk-Ahras">41 - Souk-Ahras</option><option value="Tipaza">42 - Tipaza</option><option value="Mila">43 - Mila</option><option value="Ain-Defla">44 - Ain-Defla</option><option value="Naama">45 - Naama</option><option value="Ain-Temouchent">46 - Ain-Temouchent</option><option value="Ghardaia">47 - Ghardaia</option><option value="Relizane">48 - Relizane</option></select>
      </td>
    </tr>
    <tr>
      <td width="90" align="right" valign="middle"> Prix entre&nbsp; </td>
      <td width="141"><input name="prix_min" type="text" id="prix_min" size="15" />
     </td>
      <td width="13" valign="middle">et </td>
      <td width="176" height="30">
        <input name="prix_max" type="text" id="prix_max" size="15" />
        DA 
      </td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td height="46" colspan="3" align="left" valign="middle"><input type="submit" name="button" id="button" value="Recherche" /></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td height="46" colspan="3" align="right" valign="middle"><a href="rech_avancee.php">Recherche avancée</a></td>
    </tr>
  </table>
  
</form>
        

        
        
        
        
          
        
        
            </div>
        
        
        
        
      
      </section>
 
 
 



	<section style="display: none; opacity: 1;" id="contentREJOINDRE" class="slide">

        <div class="bloc1 bloc">    
        
        <form id="form1" name="form1" method="post" action="recherche_loc.php">
<table width="438" border="0" align="left">
    <tr>
      <td width="90" height="38" align="right" >Votre recherche&nbsp;</td>
      <td height="30" colspan="3"><select name="souscategorie1" id="souscategorie1" onchange="modifier_formulaire()">
					<option selected="selected" value="appartement">Appartement</option><option value="studio">Studio</option><option value="villa">Villa</option><option value="niveau-de-villa">Niveau De Villa</option><option value="local">Local</option><option value="usine">Usine</option><option value="terrain">Terrain</option><option value="carcasse">Carcasse</option><option value="bungalow">Bungalow</option><option value="duplex">Duplex</option><option value="hangar">Hangar</option><option value="immeuble">Immeuble</option><option value="autre">Autre</option>	
				</select>      </td>
    </tr>
    <tr>
      <td width="90" height="29" align="right" valign="middle">Où&nbsp;&nbsp;</td>
      <td height="30" colspan="3"><select name="wilaya" id="wilaya" onchange="SetWilaya()" class=""><option selected="selected" value="">Choisissez</option>
      <option value="Adrar">01 - Adrar</option><option value="Chlef">02 - Chlef</option><option value="Laghouat">03 - Laghouat</option><option value="Oum-El-Bouaghi">04 - Oum-El-Bouaghi</option><option value="Batna">05 - Batna</option><option value="Bejaia" >06 - Bejaia</option><option value="Biskra">07 - Biskra</option><option value="Bechar">08 - Bechar</option><option value="Blida">09 - Blida</option><option value="Bouira">10 - Bouira</option><option value="Tamanrasset">11 - Tamanrasset</option><option value="Tebessa">12 - Tebessa</option><option value="Tlemcen">13 - Tlemcen</option><option value="Tiaret">14 - Tiaret</option><option value="Tizi-Ouzou">15 - Tizi-Ouzou</option><option value="Alger">16 - Alger</option><option value="Djelfa">17 - Djelfa</option><option value="Jijel">18 - Jijel</option><option value="Setif">19 - Setif</option><option value="Saida">20 - Saida</option><option value="Skikda">21 - Skikda</option><option value="Sidi-Bel-Abbes">22 - Sidi-Bel-Abbes</option><option value="Annaba">23 - Annaba</option><option value="Guelma">24 - Guelma</option><option value="Constantine">25 - Constantine</option><option value="Medea">26 - Medea</option><option value="Mostaganem">27 - Mostaganem</option><option value="MSila">28 - MSila</option><option value="Mascara">29 - Mascara</option><option value="Ouargla">30 - Ouargla</option><option value="Oran">31 - Oran</option><option value="El-Bayadh">32 - El-Bayadh</option><option value="Illizi">33 - Illizi</option><option value="Bordj-Bou-Arreridj">34 - Bordj-Bou-Arreridj</option><option value="Boumerdes">35 - Boumerdes</option><option value="El-Taref">36 - El-Taref</option><option value="Tindouf">37 - Tindouf</option><option value="Tissemsilt">38 - Tissemsilt</option><option value="El-Oued">39 - El-Oued</option><option value="Khenchela">40 - Khenchela</option><option value="Souk-Ahras">41 - Souk-Ahras</option><option value="Tipaza">42 - Tipaza</option><option value="Mila">43 - Mila</option><option value="Ain-Defla">44 - Ain-Defla</option><option value="Naama">45 - Naama</option><option value="Ain-Temouchent">46 - Ain-Temouchent</option><option value="Ghardaia">47 - Ghardaia</option><option value="Relizane">48 - Relizane</option></select>
      </td>
    </tr>
    <tr>
      <td width="90" align="right" valign="middle"> Prix entre&nbsp; </td>
      <td width="141"><input name="prix_min" type="text" id="prix_min" size="15" />
     </td>
      <td width="13" valign="middle">et </td>
      <td width="176" height="30">
        <input name="prix_max" type="text" id="prix_max" size="15" />
        DA 
      </td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td height="46" colspan="3" align="left" valign="middle"><input type="submit" name="button" id="button" value="Recherche" /></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td height="46" colspan="3" align="right" valign="middle"><a href="rech_avancee.php">Recherche avancée</a></td>
    </tr>
  </table>
  
</form>
                  
        
   </div>
   
   
  
      </section>
 </div>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<style type="text/css">
#video {
	position: absolute;
	left: 0px;
	
	height: 267px;
	z-index: 1;
	width: 100%;
}
</style>
</head>

<body>
<div id="video"><table width="900" border="0" align="center">
  <tr>
    <td width="496"><img src="images/partiefondentet.png" width="575" height="260" /></td>
    <td width="394"><iframe width="350" height="260" src="" frameborder="0" allowfullscreen style="z-index:100"></iframe></td>
  </tr>
</table>
</div>
</body>
</html>
     </td>
      
    </tr>

  </table>
</div>
<div id="divdefil2">
  <marquee id="id2">
    <span class="echorouge" onmouseover="getElementById('id1').stop();" onmouseout="getElementById('id1').start();"> L'agence immobilière AISSAT vous souhaite la bienvenue sur son site web, vous pouvez profiter de toutes nos annonces et nous contacter en cas de besoin, nous restons à votre entière disposition. </span>
  </marquee>
</div>
</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0022)http://www.adjlia.com/ -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">







<style type="text/css">
<!--
body {
	background-image: url(images/fondentete.jpg);
	background-repeat: no-repeat;
	background-attachment: fixed;
}


#an {
	position: absolute;
	left: 0px;
	top: 30px;
	width: 100%;
	height: auto;
	z-index: 1;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFF;
}
a:hover {
	text-decoration: none;
	color: #FFF;
}
a:active {
	text-decoration: none;
	color: #FFF;
}
</style>



</head><body>





<div id="an">

<table width="900" align="center" cellspacing="0" cellpadding="0" >
  
  <tr>
    <td width="" valign="top">
    
                  
               
                  
                 
                  <link rel="stylesheet" type="text/css" href="test/skin.css">
                  
                  
                  
                  <script type="text/javascript" src="test/jquery.jcarousel.min.js"></script>
                  
                  <script type="text/javascript">

function mycarousel_initCallback(carousel)
{
 
   // pour le temps chichier jquery142
 //speeds:{slow:400,fast:200,_default:1500}
 
    // Désactiver le défilement automatique si l'utilisateur clique sur le bouton suivant ou diff.
    carousel.buttonNext.bind('click', function() {
        carousel.startAuto(1);
		
    });

    carousel.buttonPrev.bind('click', function() {
        carousel.startAuto(1);
    });

    // Pause autoscrolling if the user moves with the cursor over the clip.
    carousel.clip.hover(function() {
        carousel.stopAuto();
    }, function() {
        carousel.startAuto(1);  

   
    });
};

jQuery(document).ready(function() {
    jQuery('#mycarousel').jcarousel({
        auto: 0,// pour l"arret de l'annimation mettre 1.

		wrap: 'last',
        
		
		initCallback: mycarousel_initCallback
    });
});

</script>
                  
                        
                        
                        
                     
                        
<div id="wrap">
      <div class=" jcarousel-skin-tango">
      <div class="jcarousel-container jcarousel-container-horizontal" style="position: relative; display: block;">
      <div class="jcarousel-clip jcarousel-clip-horizontal" style="position: relative;">
                          
                          
                          <ul class="jcarousel-list jcarousel-list-horizontal" id="mycarousel" style="overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: -1898px; width: 900px;" name="mycarousel">
                            
                           
                                                              <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00059">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00063/prommotion_ZIZI_cherif.jpg"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;appartement  Bejaia</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00055">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00059/tala_ouriene_terrain.jpg"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;terrain  Bejaia</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00053">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00057/DSCF1094.jpg"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;appartement  Bejaia</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00051">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00055/DSCF3773.JPG"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;terrain  Toudja</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00050">
                                  
                                  
                                  
<img src="images/logo1.png" />

   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;terrain  Bejaia</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00049">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00053/DSC00322.JPG"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;appartement  Melbou</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00043">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00047/Photo2.jpg"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;autre  Bejaia</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00038">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00042/DSC00287.JPG"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Location&nbsp;villa  Aokas</span>
</a>
                                </li>
                                                                <li  style="float: left; list-style: none; width:120px;   margin:5px; height:120px; border-radius:5px; text-align:center; z-index:1;  background:#6CF;
                                
                               background-image:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0, rgba(255, 255, 255, 0.7)), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.5, transparent), to(rgba(255, 255, 255, 0.3)));
background-image:-moz-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-ms-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:-o-linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
background-image:linear-gradient(top, rgba(255, 255, 255, 0.7) 0, rgba(255, 255, 255, 0.2) 50%, transparent 50%, rgba(255, 255, 255, 0.3) 100%);
-webkit-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
-moz-box-shadow:inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
box-shadow: inset -1px 0 1px rgba(255, 255, 255, 0.4), inset 1px 0 1px rgba(255, 255, 255, 0.4), inset 0 0 10px rgba(255, 255, 255, 0.4);
 text-shadow: 0 1px 1px #6CF;               
                                
                                ">
                                  
                                  <a href="detail_ann.php?id_annonce=00003">
                                  
                                  
                                  <img style="float:left; width: 120px; height:80px; " alt="image" src="admin/photo_annonce/annonce-00003/7.jpg"/>
   
   <span style="line-height:20px; font-family:Arial, Helvetica, sans-serif; color:#000;">
   
                                  
 Vente&nbsp;appartement  Bejaia</span>
</a>
                                </li>
                                                             
                              
                              
                              
                              
                                                          </ul></div><div class="jcarousel-prev jcarousel-prev-horizontal" style="display: block;"></div>
                                                          
                              <div class="jcarousel-next jcarousel-next-horizontal" style="display: block;"></div></div></div></div></td>
                      </tr>
                      </table></div>
</body></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="aissat immobilière,agence aissat immobilière, agence immobilière béjaia, agences immobilières algérie, agence immobilière dz, agence immobilière ALG, agence immobilière bougie, location, vente, echange, achat, location immobilière, immobilière, gestion des biens, nouvelle maisons, site des agenges immobilière, yekhlef, aissat, yekhelf aissat, bejaia, gouraya, saison estivale, appartements locatifs, villa, studio, niveau de villa, duplex, hangar, usine, terrain, immeuble, logements, transaction immobilière, recherche des biens, recherche d'achat, recherche de location, propriètés à louer, propriètes à vendre, fnai, axxam, site immobilier dz, site immobilier béjaia, site immobilier algerie, promotions, promotions immobilières, fédération nationnale des agences immobilières, ayimmo, site ayimmo "/>
<meta name="robots" content="All,Index,Follow" />
<meta name="copyright" content="Aissat immobilière" />
<meta name="language" content="FR" />
<meta name="abstract" content="Aissat immobilière pour toutes vos transactions immobilières (vente, achat, Echange, location)" />
<meta name="description" content="Créée par Aïssat Yekhlef, jeune dynamique possédant une grande expérience dans le domaine, l’agence immobilière Aïssat est présenté sur le marché immobilier depuis 2006, et ambitionne de répondre aux besoins actuels et futurs du marché. 
Ses multiples services proposés à sa clientèle durant et après chaque transaction se basent sur une politique très bien étudiée, consolidée par des études du marché qui donnent une bonne orientation à nos clients.
Nous avons réalisé à ce jour de nombreuses solutions sur mesure pour nos clients, ce qui nous a permis de gagner la confiance d’une armada importante de clients sur le territoire national et à l’étranger. 
Ce qui caractérise l’esprit professionnel de l’agence immobilière Aissat, c’est la qualité des services qu’elle offre aux clients, en assurant un suivi ainsi qu’un accompagnement de grande qualité, une assistance juridique pendant et après chaque transaction, et une collaboration avec des bureaux d’études techniques et notariales ainsi que les banques et les administrations concernées.
Enfin, et dans le but d’élargir ses activités et améliorer ses services, l’agence Aissat a créé un partenariat avec un groupe de sociétés d’une grande réputation, afin de satisfaire les besoins de sa clientèle.
L’agence immobilière Aissat vous propose une série de services :
- Transactions nationales et internationales (vente, achat, location, assistance pour les investisseurs…)
- Conseils juridiques et orientation administrative.
- Gérance des biens immobiliers.
- Recouvrement des loyers.
Les partenaires del’agence immobilière Aissat offre les services suivants :
- Alimentations en matériaux de construction (locaux et d’importation) 
- Mains d’œuvre pour tous travaux de construction ;
- Etude technique (étude de sol, dossier pour permis de construction) - Etude technico-économique ; 
- Services d’avocat et notaire.
 " />
<meta name="rating" content="Aissat immobilière, conseiller en gestion de biens immobiliers" />
<meta name="subject" content="informations, services et conseils sur toutes les transactions immobilières (vente, achat, echange, location)" />
<meta name="owner" content="contact@ayimmo.com" />
<!-- Stu Nicholls | CSSplay -->
<!-- traduit et adapté par outils-web.com -->
<!-- chargement des feuilles de style -->
<link href="css0/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#divbarre {
	position: absolute;
	left: 0px;
	top: -30px;
	width: 100%;
	height: 85px;
	z-index: 12;
	background-image: url(images/1.png);
	background-repeat: repeat-x;
	background-position: center;
}

</style>
</head>
<body>
<div id="divbarre" >
  <table width="900" border="0" align="center">
    <tr>
      <td>
        <div class="stretchHolder">
          <div class="stretchMenu">
            <ul class="stretchDrop">
              <!-- item 1 -->
              <li class="slid p1"><a href="index.php">Accueil</a>
                
              </li>
              <!-- item 2 -->
              <li class="slid p2"><a href="presentation.php">Pr&eacute;sentation</a>
                
              </li>
              <!-- item 3 -->
               <li class="slid p3"><a href="ajout_annonce.php">D&eacute;poser un bien</a>
               
              </li>
                <!-- item 4 -->
              <li class="slid p4"><a href="liste_annonces.php">Annonces</a>
                <div><b></b>
                  <dl>
                    <dt>Vente</dt>
                    <dd><a href="vente_apprt.php">Appartement</a></dd>
                    <dd><a href="vente_villa.php">Villa</a></dd>
                    <dd><a href="vente_local.php">Local</a></dd>
                    <dd><a href="vente_terrain.php">Terrain</a></dd>
                 
                    <dd><a href="vente_autre.php">Autre</a></dd>
                
                  </dl>
                  <dl>
                    <dt>Location</dt>
                    <dd><a href="location_apprt.php">Appartement</a></dd>
                    <dd><a href="location_villa.php">Villa</a></dd>
                    <dd><a href="location_local.php">Local</a></dd>
                    <dd><a href="location_studio.php">Studio</a></dd>
                  
                    <dd><a href="location_autre.php">Autre</a></dd>
                  </dl>
                 <dl>
                  <dt>Echange</dt>
                    <dd><a href="echange_apprt.php">Appartement</a></dd>
                    <dd><a href="echange_villa.php">Villa</a></dd>
                    <dd><a href="echange_local.php">Local</a></dd>
                    <dd><a href="echange_terrain.php">Terrain</a></dd>
                
                    <dd><a href="echange_autre.php">Autre</a></dd>
                  </dl>
                </div>
              </li>
            
             
              <!-- item 5 -->
              <li class="last p5"><a href="contact.php"> Contact</a>
                
              </li>
            </ul>
          </div>
      
      </div></td>
    </tr>
  </table>
</div>
