<html>
<head>
<title>Titre de la page</title>
</head>
<body bgcolor="blue" vlin="red">
Bienvenue sur mon site web !
<? echo("Vous �tes le visiteur n�". $nbre_visiteurs); ?> <br>
Cliquez <a href="http://www.sitedusero.com">ici</a>pour entrer !
</body>
</html>
