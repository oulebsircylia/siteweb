<?
	phpinfo();
?>
